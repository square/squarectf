# Challenge name

Out Of Cash

## Challenge points

300

## Challenge description

After complaints of stolen credit card info, the EMV parser
has been updated to allow for deleting records.
Show them thats not enough

nc challenges.2021.squarectf.com XXXX

## Included files

`dist/out-of-cash`
`dist/libc-2.31.so`

## Challenge solution

Solution at: `solve.py`
