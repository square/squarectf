## Unicode Problems

# Challenge points
200

# Challenge description
We are having trouble with unauthorized access to our systems. Our login page is hosted at {SERVER IP + PORT HERE}. Can you take a look at it and the included source file to figure out what is wrong?

# Included files
./app.js (the one in the root dir, not in src-do-not-share)

# How to host

`node app.js` in the src-do-not-share root dir. App will listen on port 8080

# Challenge solution
This challenge abuses a hidden unicode character in the environment check if statement. Based very tightly on this writeup: https://certitude.consulting/blog/en/invisible-backdoor/

Essentially we unpack three variables from req.params: username, password, and \u3164. Then later in the check we see if `+ENV_DEV_WEST ==ㅤ+ENVIRONMENT`. This looks like using the unary plus to convert a string to a number, but it's really `+ENV_DEV_WEST ==\u3164+ENVIRONMENT`. So if you make a request setting `\u3164=3`, you get `32 == '3'+2` which validates and skips the username / password check, dumping the flag.

So the request is to `http://localhost:8080/login?%E3%85%A4=3` to beat the chal.