# Challenge name

Gil Triangle

## Challenge points

200

## Challenge description

Looks look they have a new way of storing customer information.
There's a credit card we want and we think it went through
their machine. It ends in 4855.

Flag would be flag{credit-card}

nc challenges.2021.squarectf.com XXXX

## Included files

`dist/gil-triangle`

## Challenge solution

Solution at: `solve.py`
