# Challenge name

Card Theft

## Challenge points

100

## Challenge description

We found an EMV parser in the wild reading credit card information.
Looks like someone just processed their credit card.
We've got an obfuscated binary for you to take a look at, but we
think you should be able to get their credit card.
Flag would be flag{credit-card}

nc challenges.2021.squarectf.com XXXX

## Included files

`dist/card-theft`

## Challenge solution

Basic challenge, the credit cards are stored in a special array that is reused.
Premise is that we want to censor credit cards, so you'd see XXXX XXXX XXXX 9810.
The last 4 digits are visible but the rest are obscured. You also get the
first 4 digits as part of the ICC (competitors will need to know that ICC == first 4 digits)
Then you can leak out 4 bytes at a time by shortening the credit card numbers you submit.
This is because the shared array is not cleared and the EMV parser stops writing when there
the input ends. If you tell it the credit card info is 6 bytes long but don't actually
submit 6 bytes, you leak credit card.

Solution at: `solve.py`
