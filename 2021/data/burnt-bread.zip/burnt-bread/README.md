# Challenge name

Burnt Bread

## Challenge points

200

## Challenge description

The EMV parser we found no longer has credit card info in memory, but
we think you might be able to find something if you can pwn it

nc challenges.2021.squarectf.com XXXX

## Included files

`dist/burnt-bread`
`dist/libc-2.31.so`

## Challenge solution

Solution at: `solve.py`
