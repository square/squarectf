# Memory Safe Hex Decode 

## Challenge Description

Since this is not a binary exploitation challenge, this binary was written in a memory safe language - Rust! This binary takes in an input on stdin and outputs either "Valid flag!" or "Invalid flag!".

## Points

200

# Solution

[Solution](./src-do-not-share/SOLUTION.md)
