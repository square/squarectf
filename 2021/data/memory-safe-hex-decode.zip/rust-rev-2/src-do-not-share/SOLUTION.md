# Internal Square Only Description

This challenge is written in Rust with the following code:
```
extern crate nom;
use nom::{
  IResult,
  Err,
  error::ErrorKind,
  error::Error,
  bytes::complete::{tag, take_while_m_n},
  combinator::map_res,
  sequence::tuple,
  number::complete::hex_u32
};
use std::io::{self, Write};

fn check_flag(input: &[u8]) -> IResult<&[u8], bool> {
    let (input, _) = tag("flag{")(input)?;
    let (input, num) = hex_u32(input)?;
    if num != 0x56b21bba {
        return Err(Err::Error(Error::new(input, ErrorKind::IsA)));
    }
    let (input, num) = hex_u32(input)?;
    if num != 0x72b9f906 {
        return Err(Err::Error(Error::new(input, ErrorKind::IsA)));
    }
    let (input, _) = tag("}")(input)?;
    return Ok((input, true));
}

fn main() {
    let mut input = String::new();
    print!("Enter the flag >> ");
    let _ = io::stdout().flush();
    io::stdin().read_line(&mut input).expect("Error reading from STDIN");
    match check_flag(input.strip_suffix("\n").expect("Error stripping newline").as_bytes()) {
        Ok(_) => println!("Valid Flag!"),
        Err(_) => println!("Invalid Flag!"),
    };

}

```

It is compiled for linux x86_64 on `Linux 5.14.14-arch1-1` with glibc 2.33 and release optimizations.

It looks like this in binja:
![image](./binja1.jpg)

The strcmp for matching "flag{56b21bba72b9f906}" is split into four parts with two optimized hex decode steps. The first checks look to see if `str[0] == 0x66`, `str[1] == 0x6c`, `str[2] == 0x61`, `str[1] == 0x67`, and `str[1] == 0x7b` to check for `flag{`.

Then it calls a func `find_token` to pull hex chars `0123456789abcdefABCDEF` from the string.

![image](./binja2.jpg)

Then it does some voodoo to turn the hex string to a uint32, and compares with `0x56b21bba` to check the first half of the flag:

![image](./binja3.jpg)

It does this again for the second half of the string against the uint32 `0x72b9f906`.

## Flag

`flag{56b21bba72b9f906}`