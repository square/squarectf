stupid_box = [99, 171, 124, 123, 89, 76, 120, 89, 26, 91, 136, 26, 37, 190, 27, 59, 91, 123, 155, 91, 11, 19, 153, 11, 225, 27, 139, 155, 27, 155, 19, 147]

# zip file password, its kinda cheating to include this rather than actually try to unzip the file but I was too lazy to write that out
# this means the check is a little faster here but it should be in the right order of magnitude
password = '0320006000040000000000000048000000000040000000000000000000000800'
def ben_seq(starter):
    sequence = []
    current_step = starter
    max_steps = 11
    steps = 0
    while current_step > 1:
        sequence.append(current_step)
        current_step = ben_step(current_step)
        steps += 1
    return sequence[1:]

def ben_step(inp):
    if inp % 2 == 0:
        return inp / 2
    return (inp * 3) + 1

def find_longest(start, stop):
    largest_seq = []
    for i in range(start, stop):
        curr_seq = ben_seq(i)
        if len(curr_seq) > len(largest_seq):
            largest_seq = curr_seq

#exactly the same but only iterates through the first 5 known bytes for the input, 'flag{'
def derive_mask(flag_str):
    final_hash = [0] * 32
    shadow_map = [0 for i in range(32)]
    doesnt_matter_map = [0 for i in range(32)]

    final_touched_set = []

    for i, c in enumerate(flag_str):
        final_hash[i % len(final_hash)] = ord(c) ^ final_hash[i % len(final_hash)]

    for i in range(5):
        seq = ben_seq(final_hash[i])
        indexes = [step % len(final_hash) for step in seq]
        final_touched_set += indexes
        for j in indexes:
            if j != i:
                shadow_map[j] = shadow_map[j] + 1
                final_hash[j] = (final_hash[i] ^ stupid_box[j]) & final_hash[j]
                if final_hash[j] == 0 or final_hash[j] == 1:
                    # if we hit this condition, the flag byte at this index can be anything because it'll be zeroed out anyways
                    doesnt_matter_map[j] = 1

    return final_hash

def bad_hash(flag_str):
    final_hash = [0] * 32
    shadow_map = [0 for i in range(32)]
    doesnt_matter_map = [0 for i in range(32)]

    final_touched_set = []

    for i, c in enumerate(flag_str):
        final_hash[i % len(final_hash)] = ord(c) ^ final_hash[i % len(final_hash)]

    for i in range(32):
        seq = ben_seq(final_hash[i])
        indexes = [step % len(final_hash) for step in seq]
        final_touched_set += indexes
        for j in indexes:
            if j != i:
                shadow_map[j] = shadow_map[j] + 1
                final_hash[j] = (final_hash[i] ^ stupid_box[j]) & final_hash[j]
    return final_hash

def to_hex_encoded(byte_array):
    return "".join([chr(b).encode('hex') for b in byte_array])

def to_byte_array(string):
    return [ord(c) for c in string]

print_ticker = 69
def check_solution(byte_array):
    guess = to_hex_encoded(byte_array)
    if password == guess:
        print 'password is ', guess
        exit(0)
    else:
        global print_ticker
        print_ticker += 1
        if print_ticker % 1000 == 0:
            print 'wrong (print #', print_ticker / 1000, '):\n\t', guess, '\n\t', password

def possible_chars(bits, all_possibilities, prev_bits):
    if len(bits) == 0:
        all_possibilities.append(prev_bits)
        return
    if bits[0] == '1':
        possible_chars(bits[1:], all_possibilities, prev_bits + '1')
        possible_chars(bits[1:], all_possibilities, prev_bits + '0')
    else:
        possible_chars(bits[1:], all_possibilities, prev_bits + '0')

def brute_flag(mask, guess):
    possibilities = mask[0]
    if len(mask) == 1:
        all_possibilities = []
        possible_chars(bin(possibilities)[2:], all_possibilities, '')
        for possible_char in all_possibilities:
            check_solution(bad_hash(guess + chr((0b1000000 ^ int(possible_char, 2))) + '}'))
        return

    all_possibilities = []
    possible_chars(bin(possibilities)[2:], all_possibilities, '')
    for possible_char in all_possibilities:
        brute_flag(mask[1:], guess + chr(0b1000000 ^ int(possible_char, 2)))
        


# 'worst case' flag guess, we're given the flag length
guess_str = "flag{\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f}"
mask = derive_mask(guess_str) #[0x7f ^ b for b in derive_mask(guess_str)] #invert the mask such that if a byte has no impact its just 0
print bad_hash(guess_str)
guess_bytes = bad_hash(guess_str)
print mask[5:]
print "total entropy: ", len("".join([bin(b)[2:] for b in mask[5:]]).replace('0', '')), "bits"
brute_flag(mask[5:], "flag{")
