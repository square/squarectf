# Challenge points
200
# Challenge description
I wrote this sick new hashing algorithm that I'm so confident in, i've used it to protect my shiny new flag. I hashed the flag using this script, and stored the flag in an encrypted zip file with the password set as the flag's hash. Good luck trying to break my bulletproof cryptography! I'll even give you a hint - the flag is 33 bytes long.
# Included files
include collatzeral-damage.py and flag.zip in the challenge description for competitors to download. do NOT include solver.py

# Challenge solution
This challenge is a poorly implemented hashing algorithm that essentially uses each byte in the input to seed a series of transformations on the rest of the hash. The competitor needs to realize that since the first 5 bytes and the last byte of the plaintext are known (flag{...}) they can determine that the majority of bits in the input don't actually factor into the hash, resulting in a much smaller search space necessary in order to find an input that collides with the flag hash. Naively, this search space should at most be 2^24 = ~15 million, but its very likely that this can be constrained much further. The solver.py script iterates through the 2^24 search space until it finds a hash that matches the zip password. It cheats a bit in that I am comparing directly to the password rather than attempting to actually unzip the zip file, but processing speed should still be in the same order of magnitude and it ended up taking me ~2 minutes to find a colliding input.

