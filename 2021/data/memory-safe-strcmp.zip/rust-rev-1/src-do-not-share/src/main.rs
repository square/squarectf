use std::io::{self, Write};

fn check_flag(input: String) {
    let flag = &input[..5];
    let contents = &input[5..(input.len() - 1)];
    let end = &input[(input.len() - 1)..];
    if flag.eq("flag{") && end.eq("}") && contents.eq("396e4dc9691577d73210a2a") {
        println!("Correct flag!");
    } else {
        println!("Invalid flag!");
    }
}

fn main() {
    let mut input = String::new();
    print!("Enter the flag >> ");
    let _ = io::stdout().flush();
    io::stdin().read_line(&mut input).expect("Error reading from STDIN");
    check_flag(input.strip_suffix("\n").expect("Error stripping newline").to_string());
}