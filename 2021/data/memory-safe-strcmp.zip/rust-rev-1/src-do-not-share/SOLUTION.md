# Internal Square Only Description

This challenge is written in Rust with the following code:
```
use std::io::{self, Write};

fn check_flag(input: String) {
    let flag = &input[..5];
    let contents = &input[5..(input.len() - 1)];
    let end = &input[(input.len() - 1)..];
    if flag.eq("flag{") && end.eq("}") && contents.eq("396e4dc9691577d73210a2a") {
        println!("Correct flag!");
    } else {
        println!("Invalid flag!");
    }
}

fn main() {
    let mut input = String::new();
    print!("Enter the flag >> ");
    let _ = io::stdout().flush();
    io::stdin().read_line(&mut input).expect("Error reading from STDIN");
    check_flag(input.strip_suffix("\n").expect("Error stripping newline").to_string());
}
```

It is compiled for linux x86_64 on `Linux 5.14.14-arch1-1` with glibc 2.33 and release optimizations.

It looks like this in binja:
![image](./binja.jpg)

The strcmp for matching "flag{396e4dc9691577d73210a2a}" is split into four parts with two different vector instructions. The first check looks to see if `str[4] == 0x7b` (`{`) and `str[0..3] == 0x67616c66` (`flag`).

Then it checks that `str[len-1] == 0x7d` (`}`).

Then the vector instructons match str[5..] to "396e4dc9691577" and str[12..] to "9691577d73210a2a396e4dc9691577d7". In memory, this is stored as the single string "9691577d73210a2a396e4dc9691577d7", so it cannot be dumped simply looking at memory or using strings.

## Flag

`flag{396e4dc9691577d73210a2a}`