Oh Sheet!

## Description
Someone very cheeky decided to encrypt their secret message in Google Sheets. What could they be hiding in plain sight?

Curious! Click on the link below to find out more:

https://docs.google.com/spreadsheets/d/15PFb_fd6xKVIJCF0b0XiiNeilFb-L4jm2uErip1woOM/edit#gid=0
