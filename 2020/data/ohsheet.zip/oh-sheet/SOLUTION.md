See the Google Sheet below for a solution:
https://docs.google.com/spreadsheets/d/1e5p2pJfCIDUAQcohQwPUXglUC5Q5m8fbdq95j52G22w/edit#gid=0
