See the Google Sheet below for a solution:
https://docs.google.com/spreadsheets/d/1PgEU2L2ZmhmwzHPzfv1I9eYaEFor0fUoRzotBAuhUVc/edit?usp=sharing
