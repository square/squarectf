# Deep web blog

NoSQL Blind data exfiltration

The query parameters sent to the API are naively sent to MongoDB, so the Mongo query syntax can be used:
{
 title: {
    $regex: "^flag$"
 }
}

One of the posts on the blog contain a "flag" field, but is redacted the a fake firewall. We can leak it using the regex syntax
one character at a time.

See `solver/solve.py`.

## Running

`docker-compose up -d`

The web challenge will be running on localhost:3000

