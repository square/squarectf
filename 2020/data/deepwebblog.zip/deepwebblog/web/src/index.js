import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import { ThemeProvider, createTheme, Arwes } from 'arwes';

const Root = () => (
  <ThemeProvider theme={createTheme()}>
    <Arwes animate background='/images/background.jpg' pattern='/images/glow.png'>
      <App />
    </Arwes>
  </ThemeProvider>
);

ReactDOM.render(<Root />, document.querySelector('#root'));
