# Square CTF NoSQLi Challenge

Unfiltered input being sent to mongoDB
