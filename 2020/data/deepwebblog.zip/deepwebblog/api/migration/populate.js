const { MongoClient } = require('mongodb')
const uri = "mongodb://mongo:27017"
const client = new MongoClient(uri, { useUnifiedTopology: true })

async function populate() {
    client.connect()
    const secretDataDb = client.db("secretData")
    const postsCollection = secretDataDb.collection('posts')

    try {
        await postsCollection.drop()
    } catch (e) {}

    await postsCollection.insertMany([
        {
        title: "Blockchain for dummies",
        content: `Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits. Dramatically visualize customer directed convergence without revolutionary ROI.

Efficiently unleash cross-media information without cross-media value. Quickly maximize timely deliverables for real-time schemas. Dramatically maintain clicks-and-mortar solutions without functional solutions.`
        },
        {
        title: "How to get free bitcoins",
        content: `Bring to the table win-win survival strategies to ensure proactive domination. At the end of the day, going forward, a new normal that has evolved from generation X is on the runway heading towards a streamlined cloud solution. User generated content in real-time will have multiple touchpoints for offshoring.`
        },
        {
        title: "My Favorite Tool: cipsum.com",
        content: `Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate strategy foster collaborative thinking to further the overall value proposition. Organically grow the holistic world view of disruptive innovation via workplace diversity and empowerment. Bring to the table win-win survival strategies to ensure proactive domination. At the end of the day, going forward, a new normal that has evolved from generation X is on the runway heading towards a streamlined cloud solution. User generated content in real-time will have multiple touchpoints for offshoring. Capitalize on low hanging fruit to identify a ballpark value added activity to beta test. Override the digital divide with additional clickthroughs from DevOps. Nanotechnology immersion along the information highway will close the loop on focusing solely on the bottom line.`
        },
        {
            title: "manifesto",
            content: `Another one got caught today, it's all over the papers.  "Teenager
Arrested in Computer Crime Scandal", "Hacker Arrested after Bank Tampering"...
        Damn kids.  They're all alike.

        But did you, in your three-piece psychology and 1950's technobrain,
ever take a look behind the eyes of the hacker?  Did you ever wonder what
made him tick, what forces shaped him, what may have molded him?
        I am a hacker, enter my world...
        Mine is a world that begins with school... I'm smarter than most of
the other kids, this crap they teach us bores me...
        Damn underachiever.  They're all alike.`
        },
        {
            title: "test",
            content: "It works!"
        },
        {
            title: "flag",
            content: "Looking for a flag? You won't find it here. Maybe this can help: https://www.youtube.com/watch?v=Jbix9y8iV38",
            flag: "flag{n0SQLn0Vulns}"
        },
        {
            title: "...",
            content: "You are ready. Search where the eyes can't see"
        }

    ])
    process.exit(0)

}

populate()
