#!/bin/bash

mkdir release/

docker build . -t jimi-jamming

docker kill jimi-jamming
docker run -dit --name=jimi-jamming --rm jimi-jamming
docker cp jimi-jamming:/home/jimi-jamming/jimi-jamming ./release/

libc_location=$(docker exec -it jimi-jamming ldd jimi-jamming | grep libc.so.6 | awk '{ print $3 }')
echo $libc_location
docker cp -L jimi-jamming:$libc_location release/

docker kill jimi-jamming

