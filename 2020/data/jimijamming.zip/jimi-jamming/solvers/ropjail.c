#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/mman.h>

#define ROP_JAIL_SIZE 0x1000

char ROPJAIL[ROP_JAIL_SIZE];

void init_jail() {
  srand(80085); // NOTE: its a static number so they can replicate it

  for (int i = 0; i < ROP_JAIL_SIZE; ++i) {
    if (i % 16 == 0) {
      ROPJAIL[i] = '\xc3';
    } else {
      ROPJAIL[i] = rand();
    }
  }

  mprotect(&ROPJAIL, ROP_JAIL_SIZE, PROT_READ | PROT_EXEC);
}

int main() {
  init_jail();

  int f = open("./buf", O_RDWR | O_CREAT);
  for (int i = 0; i < ROP_JAIL_SIZE; ++i) {
    write(f, &ROPJAIL[i], 1);
  }

  close(f);

  return 1;
}