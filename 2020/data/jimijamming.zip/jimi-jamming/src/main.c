#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <errno.h>

#define ROP_JAIL_SIZE 0x1000

char* ROPJAIL;

void init_jail() {
  srand(80085); // NOTE: its a static number so they can replicate it

  posix_memalign(&ROPJAIL, 0x1000, ROP_JAIL_SIZE);

  for (int i = 0; i < ROP_JAIL_SIZE; ++i) {
    if (i % 16 == 0) {
      ROPJAIL[i] = '\xc3';
    } else {
      ROPJAIL[i] = rand();
    }
  }

  puts("PSSt, I'll let you leave a key somewhere");
  char buf[10];
  read(0, buf, 10);
  puts("where do you need the key?");
  char where[32];
  read(0, where, 31);
  where[31] = 0;
  int offset = atoi(where);
  if (offset < 0 || offset > ROP_JAIL_SIZE) {
    puts("You want me to put your key OUTSIDE of jail?");
    exit(1);
  }

  for (int i = 0; i < 10; ++i) {
    ROPJAIL[offset + i] = buf[i];
  }

  int err = mprotect(ROPJAIL, ROP_JAIL_SIZE, PROT_READ | PROT_EXEC);
}

void vuln() {
  char buf[8];

  puts("Hey there! You're now in JIMI JAM JAIL");

  read(0, buf, 128);

  // Check that everything in the buf fits into ROPJAIL
  for (int i = 0; i < 128 / 16; ++i) {
    void* val = ((void**) buf)[i];
    if (val <= 0x200000000) {
      continue;
    }

    if (val < ROPJAIL || val > (ROPJAIL + ROP_JAIL_SIZE)) {
      puts("Out of bounds");
      exit(1);
    }
  }
}

int main() {
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);
  init_jail();

  puts("Hey there jimi jammer! Welcome to the jimmi jammiest jammerino!");
  printf("The tour center is right here! %p\n", ROPJAIL);

  vuln();

  return 0;
}