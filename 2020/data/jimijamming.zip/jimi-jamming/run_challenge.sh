#!/bin/bash

docker kill jimi-jamming
docker run --rm -d -p 9000:9000 --name=jimi-jamming jimi-jamming