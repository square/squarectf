#!/bin/bash

mkdir release/

docker build . -t jimi-jam

docker kill jimi-jam
docker run -dit --name=jimi-jam --rm jimi-jam
docker cp jimi-jam:/home/jimi-jam/jimi-jam ./release/

libc_location=$(docker exec -it jimi-jam ldd jimi-jam | grep libc.so.6 | awk '{ print $3 }')
echo $libc_location
docker cp -L jimi-jam:$libc_location release/

docker kill jimi-jam

