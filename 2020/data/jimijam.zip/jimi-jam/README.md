# This is a multi-part ROP centered challenge

The first part is basic ROP - we give you binary base and you need to leak libc and then get shell


# Solvers

All solvers assume you have pwntools



Dockerfile is for jimi-jam

Will have more dockerfiles for more challenges

helper scripts for faster iteration