#!/bin/bash

docker kill jimi-jam
docker run --rm -d -p 9000:9000 --name=jimi-jam jimi-jam