#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

int main() {
  srand(1337);

  int f = open("./buf", O_RDWR | O_CREAT);
  char buf[sizeof(int)];
  for (int i = 0; i < 4096; i += (sizeof(int))) {
    int x = rand();
    memcpy(buf, &x, sizeof(int));
    write(f, buf, sizeof(int));
  }

  close(f);

  return 1;
}