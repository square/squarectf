#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/mman.h>

#define ROP_JAIL_SIZE 8192

// TODO: setup the ROP buffer here

char ROPJAIL[ROP_JAIL_SIZE];

void init_jail() {
  srand(1337); // NOTE: its a static number so they can replicate it

  for (int i = 0; i < ROP_JAIL_SIZE; i += sizeof(int)) {
    ROPJAIL[i] = rand();
  }

  mprotect(&ROPJAIL, ROP_JAIL_SIZE, PROT_READ | PROT_EXEC);
}

void vuln() {
  char buf[8];

  puts("Hey there! You're now in JIMI JAM JAIL");

  // NOTE: we read 64, so you have 56 words of ROP addresses
  read(0, buf, 64);
}


int main() {
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);
  init_jail();

  puts("Hey there jimi jammer! Welcome to the jimmi jammiest jammerino!");
  printf("The tour center is right here! %p\n", &ROPJAIL);

  vuln();

  return 0;
}