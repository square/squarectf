# Hash My Awesome Commands

HMAC can be vulnerable to timing attacks because of short-circuiting in string comparison. This is a very 
exaggerated version to make it easier to attack. User can ask the server for a flag by sending `flag|hmac(key, flag)`
where the key is unknown to the player. A debug mode can be enabled with the given command
`debug|9W5iVNkvnM6igjQaWlcN0JJgH+7pComiQZYdkhycKjs=`. Debug mode provides info about how long in nanoseconds the 
server is taking to compare the HMACs. Users can brute force character by character to find the valid HMAC for the 
flag command.

## Distribute
- main.go

## Description
I found this strange server that only has two commands. Looks like there's a command to get the
flag, but I can't figure out how to get it to work. It did come with a strange note that had
**9W5iVNkvnM6igjQaWlcN0JJgH+7pComiQZYdkhycKjs=** written on it. Maybe that's important?

## Hint
If server is flaky/taking a really long time for users to solve we can give out a hint

Progressively release more of the valid flag hmac

partial hmac of the flag command:

`flag|#################################9i7SawgTKE=`

full hmac of the flag command:

`flag|ndAoSzx/CbizTqNBB5cz3t6XGFEGbQwIc9i7SawgTKE=`

## Sample Solver
Solver can run against either local binary or server

Go into `solve.py` and modify the following section:
```
# p = process(['./hmac'])
p = remote('localhost', 8000)
```
To run:
```
source solve/venv/bin/activate
python3 -m pip install pwn
python3 solve/solve.py
```
Solver kinda takes a while especially against the server
## Flag
flag{d1d_u_tAk3_thE_71me_t0_apPr3c14t3_my_cOmm4nD$}