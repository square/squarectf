from pwn import *

def search(start, expected_len):
    print('start search', start)
    prev_time = 0
    for i in range(len(start), expected_len):
        guess = 0
        max_time = 0
        for j in range(256):
            p.recvuntil('command: ')

            attempt = start + [j] + [0 for _ in range(expected_len - i - 1)]
            attempt = base64.b64encode(bytes(attempt))
            p.sendline(b'flag|' + attempt)
            p.recvuntil('took ')
            curr_time = int(p.recvuntil(' nano').split(b' nano')[0])

            if curr_time > max_time:
                guess = j
                max_time = curr_time

            # print('guess', j, 'time', curr_time)
        if max_time <= prev_time:
            return start[:-1]

        prev_time = max_time
        start.append(guess)
        print(start)
    return start

p = process(['./hmac'])
# p = remote('challenges.2020.squarectf.com', 9020)
# context.log_level = 'debug'

check = []
p.recvuntil(': ')
p.sendline('debug|9W5iVNkvnM6igjQaWlcN0JJgH+7pComiQZYdkhycKjs=')

check = search(check, 32)
while len(check) < 32:
    check = search(check, 32)

check = check[:-1]
for i in range(256):
    p.recvuntil('command: ')
    attempt = check + [i]
    attempt = base64.b64encode(bytes(attempt))
    p.sendline(b'flag|' + attempt)
    p.recvuntil('hmac\n')
    hope = p.recvline()
    if b'flag' in hope:
        print(hope)
        break