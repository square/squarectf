# Aspirations

Use some url parsing stuff to bypass an admin check (using /../ basically). Admin panel gives you the root
bundle for the SPIRE server and lets you add your own bundle. Create some fake CA and sign some certs. Make
sure to sign a cert for `spiffe://square.ctf.chal/flag`. Use that to authenticate to the flag endpoint.

## Distribute
 - distribute/chal.zip
 
## Description
We all have aspirations, but not all of us live up to them. I'm pretty certain that
you'll be able to though. Let's see how you do.

## Solver
Build the binary in `/solve` and run it. 

Might have to change the `serverUrl` const in `main.go`

## Flag
flag{4r3_u_CERTain_ab0u7-uR-aSPIRE-Ati0n5}