# Xark
A node.js CTF puzzle by Alok Menghrajani.

## Running in dev

    yarn install
    yarn dev
    > open http://localhost:3001/init?token=secret in your browser

## Running in prod

    > Setup a mysql database. Give the SQL user limited permissions.
    > Check your config/prod.json. You'll want to set:
    > - the SQL user's password
    > - the random token
    > - the desired flag
    yarn install
    yarn prod
    > open http://localhost:3001/init?token=<your random token> in your browser
    to initialize the mysql table and insert the flag.
    > ensure the /debug endpoint isn't leaking anything sensitive!

_⚠️ make sure the SQL user has limited permissions (insert + select). Otherwise,
there's a risk someone figures out how to update or delete the flag._

## Puzzle
1. Setup a mysql database.
2. Run the node.js app in one or more nodes.
3. Uncomment the /init endpoint, call it, comment it back.
4. Give all the participants access to the same node.js instance (i.e. no need
   to run one app per team in a container).
5. Give all the participants access to the source code. They will need:
   - [index.js](https://github.com/alokmenghrajani/xark/blob/main/index.js)
   - [yarn.lock](https://github.com/alokmenghrajani/xark/blob/main/yarn.lock)
   - [package.json](https://github.com/alokmenghrajani/xark/blob/main/package.json)
   - [config/dev.json](https://github.com/alokmenghrajani/xark/blob/main/config.dev.json)
   - [config/prod.json](https://github.com/alokmenghrajani/xark/blob/main/config.prod.json)
   It's probably easier for everyone to also give them the html files so they
   can just type "yarn dev" or "yarn prod" and get started.

   ⚠️⚠️⚠️ ATTENTION ⚠️⚠️⚠️
   - Don't give them the git history!
   - Don't give them this README.
   - Don't accidentally give them your actual production database password!
   - Don't accidentally give them your flag!

## Solution
Ask Alok.

## Todo
- Once the CTF is done: go poke https://github.com/knex/knex/issues/1227 and
  remind the Knex folks that the SQLi which was reported in 2016 still isn't
  fixed...
