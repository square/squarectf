document.addEventListener("DOMContentLoaded", () => {
    record.onsubmit = ev => {
      $('#recordSpinner').show();
      $.post("/record", $(record).serialize(), () => {
        $(main).empty();
        $('<p>').text("Saved!").appendTo(main);
      })
      .fail((jqXHR) => {
        console.error(jqXHR);
        $(main).empty();
        $('<code>').text("error: " + jqXHR.responseJSON.error).appendTo(main);
      });
      return false;
    }

    view.onsubmit = ev => {
      $('#viewSpinner').show();
      $.post("/data", $(view).serialize(), (data) => {
        if (data.length == 0) {
          $(main).empty();
          $('<i>').text("Sorry, no crushes :(").appendTo(main);
        } else {
          $(main).empty();
          $('<p>').html("<p>You have " + data.length + " crushes :)</p>").appendTo(main);
          const d = $('<ul>').appendTo(main);
          data.map(e => $('<li>').text(e.message).appendTo(d));
        }
      })
      .fail((jqXHR) => {
        console.error(jqXHR);
        $(main).empty();
        $('<code>').text("error: " + jqXHR.responseJSON.error).appendTo(main);
      });
      return false;
    };
});
