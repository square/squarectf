# Its right there

## Point Value
100

## Challenge Description
I couldn't come up with an interesting android challenge, so I kinda just stuck the flag in a textbox. It's right there, <a href='/static/files/its-right-there/freeflag.apk'>just take it</a>.

## Description
The apk is just a very simple minified kotlin app that decrypts a static blob of AES ECB encrypted data using an 8 byte key generated from random seeded with 0. it prints the decrypted flag on screen, but sets the text size of the flag to ~1/3rd of the screen per character, so the majority of the flag is cut off. Players will need to either use a rooted device to debug it, or repackage it with a debug permission, or just statically RE the flag out (note that simply unzipping the APK and running strings is not sufficient here).

To sign the app, first build it, then:
zipalign  -v -p 4 its-right-there-app/app/release/app-release.apk release-aligned.apk
apksigner sign --ks itsrighttherekeystore --out freeflag.apk release-aligned.apk

## Deployment
players just need access to freeflag.apk