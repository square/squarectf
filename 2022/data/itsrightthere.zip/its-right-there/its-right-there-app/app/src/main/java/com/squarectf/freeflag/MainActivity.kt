package com.squarectf.freeflag

import android.os.Bundle
import android.util.DisplayMetrics
import android.util.TypedValue.COMPLEX_UNIT_PX
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.lang.Integer.max
import java.util.Random
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

class MainActivity : AppCompatActivity() {
  fun getFlag() : String { // "flag{ctfs_just_give_you_flags_these_days_its_ridicul0us}"
    val cipherText = byteArrayOf(-31, -55, -103, -22, 106, -109, 34, -12, 111, -26, 1, -77, 9, -40, 118, -58, 98, 46, -88, 17, 66, -105, -78, -20, 40, 123, 2, -65, 3, 59, 6, 101, 83, -80, 72, 71, -114, 77, -57, -106, -12, 34, 124, 42, -96, -54, 103, 19, 20, -56, 31, 22, -52, 110, 28, -28, -105, -107, 96, 32, -17, 28, -119, -120)
    val cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
    val generator = Random(0)
    val keyArr = ByteArray(16)
    generator.nextBytes(keyArr)
    val key = SecretKeySpec(keyArr, "AES")
    cipher.init(Cipher.DECRYPT_MODE, key)
    return String(cipher.doFinal(cipherText))
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)
    val flag: TextView = findViewById(R.id.flag)
    val displayMetrics = DisplayMetrics()
    windowManager.defaultDisplay.getMetrics(displayMetrics)
    val height = displayMetrics.heightPixels
    val width = displayMetrics.widthPixels
    flag.setTextSize(COMPLEX_UNIT_PX, (max(height, width) / 3).toFloat())
    flag.setText(getFlag())
  }
}