package config

const (
	SESSION_NAME = "sessid"
	LOGIN_KEY    = "user-login-session"
)
