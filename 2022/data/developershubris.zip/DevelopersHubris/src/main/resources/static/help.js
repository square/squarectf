let stompClient = null;
let subId = null;

function setConnected(connected) {
  $("#connect").prop("disabled", connected);
  $("#disconnect").prop("disabled", !connected);
  if (connected) {
    $("#conversation").show();
  }
  else {
    $("#conversation").hide();
  }
  $("#assistance").html("");
}

function connect() {
  const socket = new SockJS('/gs-guide-websocket');
  stompClient = Stomp.over(socket);
  stompClient.connect({}, function (frame) {
    setConnected(true);
    console.log('Connected: ' + frame);
    subId = Math.floor(Math.random() * 100000000).toString() +
        Math.floor(Math.random() * 100000000).toString() +
        Math.floor(Math.random() * 100000000).toString() +
        Math.floor(Math.random() * 100000000).toString();
    stompClient.subscribe('/queue/' + subId, function (assistance) {
      showAssistance(JSON.parse(assistance.body).content);
    });
  });
}

function disconnect() {
  if (stompClient !== null) {
    stompClient.disconnect();
  }
  setConnected(false);
  console.log("Disconnected");
}

function sendHelpRequest() {
  stompClient.send("/app/help", {}, JSON.stringify({'module': $("input[name='module']:checked").val(), 'subId': subId}));
}

function showAssistance(content) {
  //TODO: Display assistance pushed from the server
}

$(function () {
  $("form").on('submit', function (e) {
    e.preventDefault();
  });
  $( "#connect" ).click(function() { connect(); });
  $( "#disconnect" ).click(function() { disconnect(); });
  $( "#send" ).click(function() { sendHelpRequest(); });
});
