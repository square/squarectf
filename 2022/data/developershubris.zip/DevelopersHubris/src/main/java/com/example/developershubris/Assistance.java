package com.example.developershubris;

public class Assistance {
  private String content;

  public Assistance() {
  }

  public Assistance(String content) {
    this.content = content;
  }

  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }
}
