package com.example.developershubris;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;

public class PathSecurityUtil {

    private static final Path applicationPath;

    static {
        applicationPath = Path.of("").toAbsolutePath();
    }
    public static Path GetSafePath(String pathStr) throws IOException {
        return GetSafePath(Path.of(pathStr));
    }

    public static Path GetSafePath(Path path, String other) throws IOException {
        return GetSafePath(path.resolve(other));
    }

    private static Path GetSafePath(Path path) throws IOException {
        Path realPath = path.toAbsolutePath().normalize();

        if(!realPath.startsWith(applicationPath))
            throw new PathSecurityException("Cannot access files outside of the application directory");

        return realPath;
    }

    public static class PathSecurityException extends IOException {

        public PathSecurityException(String message) {
            super(message);
        }
    }
}
