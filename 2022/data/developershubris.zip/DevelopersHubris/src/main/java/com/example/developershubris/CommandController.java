package com.example.developershubris;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Base64;
//import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

// AppSec team doesn't want us implementing hidden Command endpoints for remote administration
// They said to delete it altogether, but I don't see why commenting out just this Controller
// would be any less secure
//@Controller
public class CommandController {

  @GetMapping("/command")
  @ResponseBody
  public String getCommand (@RequestParam() String command) throws IOException {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    ObjectOutputStream oos = new ObjectOutputStream(byteArrayOutputStream);
    oos.writeObject(new Command(command));
    oos.close();
    return Base64.getEncoder().encodeToString(byteArrayOutputStream.toByteArray());
  }

  @PostMapping("/command")
  @ResponseBody
  public String postCommand (@RequestParam() String commandObjectSerializedEncoded)
      throws IOException, ClassNotFoundException {

    String fileName = java.util.UUID.randomUUID().toString();
    byte[] commandObjectSerialized = Base64.getDecoder().decode(commandObjectSerializedEncoded);
    try (ByteArrayInputStream commandIn = new ByteArrayInputStream(commandObjectSerialized);
         ObjectInputStream in = new ObjectInputStream(commandIn);) {
      Command commandObject = (Command)in.readObject();

      try (FileOutputStream fileOut = new FileOutputStream(PathSecurityUtil.GetSafePath("Errors/" + fileName).toFile());
           ObjectOutputStream out = new ObjectOutputStream(fileOut);) {
        out.writeObject(commandObject);
      }
    }

    return fileName;
  }
}
