package com.example.developershubris;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevelopersHubrisApplication {

  public static void main(String[] args) {
    SpringApplication.run(DevelopersHubrisApplication.class, args);
  }
}
