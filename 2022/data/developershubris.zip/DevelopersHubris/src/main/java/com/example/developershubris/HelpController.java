package com.example.developershubris;

import java.io.IOException;
import java.nio.file.Files;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

@Controller
public class HelpController {

  @Autowired
  private SimpMessagingTemplate simpMessagingTemplate;

  @MessageMapping("/help")
  public void assistance(HelpRequest request) throws IOException {

    try {
      simpMessagingTemplate.convertAndSend("/queue/" + request.getSubId(), new Assistance(new String(Files.readAllBytes(PathSecurityUtil.GetSafePath("./Help/" + request.getModule())))));
    } catch (Exception ex)
    {
      simpMessagingTemplate.convertAndSend("/queue/" + request.getSubId(), new Assistance(ex.toString()));
    }
  }
}
