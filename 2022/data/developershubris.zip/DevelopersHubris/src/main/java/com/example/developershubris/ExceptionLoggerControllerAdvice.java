package com.example.developershubris;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.apache.commons.codec.binary.Base64OutputStream;

@ControllerAdvice
public class ExceptionLoggerControllerAdvice {

  @ExceptionHandler(Exception.class)
  @ResponseBody
  public String handleGeneralError(Exception ex) throws Exception {

    ex.printStackTrace();
    String errorID = java.util.UUID.randomUUID().toString();
    try (FileOutputStream fileOut = new FileOutputStream("Errors/." + errorID);
         Base64OutputStream base64Out = new Base64OutputStream(fileOut);
         ObjectOutputStream out = new ObjectOutputStream(base64Out)) {
      out.writeObject(ex);
    } catch (IOException i) {
      i.printStackTrace();
    }

    //throw ex;

    return "An error has occurred on the server. Error information has been captured and stored locally with ID " + errorID + ", so please contact an administrator if this continues to happen";
  }
}
