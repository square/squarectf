package com.example.developershubris;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ReportsController {

  @GetMapping("/reports")
  public String getReports (@RequestParam() String name, Model model) throws IOException {

    Path reportsPath = PathSecurityUtil.GetSafePath("Reports/" + name);
    File reportsDirectory = reportsPath.toFile();
    List<String> reportsNames = new ArrayList<>();
    if(reportsDirectory.exists()) {
      File[] reportFiles = reportsDirectory.listFiles((reportFile) -> !reportFile.isHidden());
      if(reportFiles != null)
        reportsNames = Arrays.stream(reportFiles).
            map(File::getName).
            collect(Collectors.toList());
    }

    model.addAttribute("name", name);
    model.addAttribute("reports", reportsNames);
    return "reports";
  }

  @GetMapping("/reports/submit")
  public String getReportsSubmit (){

    return "index";
  }

  @PostMapping("/reports/submit")
  @ResponseBody
  public String postReportsSubmit (@RequestParam() String name,
      @RequestParam() String subject,
      @RequestParam() String message) throws IOException {

    // TODO: Encrypt reports using key stored in env variable
    // String key = System.getenv("FLAG");

    Path reportsDirectoryPath = PathSecurityUtil.GetSafePath("Reports/" + name);
    File reportsDirectory = reportsDirectoryPath.toFile();
    if(!reportsDirectory.exists() && !reportsDirectory.mkdir())
      return "Sorry, a new folder couldn't be created for your reports";
    File reportFile = PathSecurityUtil.GetSafePath(reportsDirectoryPath, subject).toFile();
    if(!reportFile.exists())
    {
      if(!reportFile.createNewFile())
        return "Sorry, the new report could not be saved";
    }
    try (FileWriter reportFileWriter = new FileWriter(reportFile)) {
      reportFileWriter.write(message);
    }

    return "Thank you for your submission!";
  }
}
