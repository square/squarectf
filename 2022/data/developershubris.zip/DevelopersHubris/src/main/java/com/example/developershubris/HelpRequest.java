package com.example.developershubris;

public class HelpRequest {

  private String module;
  private String subId;

  public HelpRequest() {
  }

  public HelpRequest(String module, String destinationQueue) {
    this.module = module;
    this.subId = destinationQueue;
  }

  public String getModule() {
    return module;
  }

  public void setModule(String module) {
    this.module = module;
  }

  public String getSubId() {
    return subId;
  }

  public void setSubId(String subId) {
    this.subId = subId;
  }
}
