package com.example.developershubris;

import java.io.IOException;
import java.nio.file.Path;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.Assert;

import com.example.developershubris.PathSecurityUtil.PathSecurityException;

import static com.example.developershubris.PathSecurityUtil.GetSafePath;

@SpringBootTest
class DevelopersHubrisApplicationTests {

  @Test
  void contextLoads() {
  }

  @Test
  void pathSecurityUtil_AppDir_success() throws IOException {
    GetSafePath(".");
  }

  @Test
  void pathSecurityUtil_ParentDir_fail() throws AssertException {
    AssertThrowsException(() -> GetSafePath(".."), PathSecurityException.class);
  }

  @Test
  void pathSecurityUtil_ReportsFile_success() throws IOException {
    GetSafePath("Reports/example");
  }

  @Test
  void pathSecurityUtil_HelpFile_success() throws IOException {
    GetSafePath("Help/example");
  }

  @Test
  void pathSecurityUtil_HelpToErrorsFile_success() throws IOException {
    GetSafePath("Help/../Error/example");
  }

  @Test
  void pathSecurityUtil_HelpToAppFile_success() throws IOException {
    GetSafePath("Help/../example");
  }

  @Test
  void pathSecurityUtil_HelpToParentFile_fail() throws AssertException {
    AssertThrowsException(() -> GetSafePath("Help/../../example"), PathSecurityException.class);
  }

  @Test
  void pathSecurityUtil_ReportsToAppDir_success() throws IOException {
    GetSafePath("Reports/..");
  }

  @Test
  void pathSecurityUtil_ReportsToParentDir_fail() throws AssertException {
    AssertThrowsException(() -> GetSafePath("Reports/../.."), PathSecurityException.class);
  }

  @Test
  void pathSecurityUtil_HomeDir_fail() throws IOException {
    Path path = GetSafePath("~");
    Assert.isTrue(path.endsWith("~"), "The safe path should end with '~', but it got resolved: " + path);
  }

  @Test
  void pathSecurityUtil_PasswdFile_fail() throws AssertException {
    AssertThrowsException(() -> GetSafePath("/etc/passwd"), PathSecurityException.class);
  }

  @Test
  void pathSecurityUtil_EnvFile_fail() throws AssertException {
    AssertThrowsException(() -> GetSafePath("/proc/53/env"), PathSecurityException.class);
  }

  private void AssertThrowsException(ThrowingFunction<? extends Exception> testFunc, Class<? extends Exception> expectedExceptionClass ) throws AssertException{

    try{
      testFunc.apply();
    }
    catch(Exception ex){
      Class<? extends Exception> exClass = ex.getClass();
      if(ex.getClass().isAssignableFrom(exClass))
        return;
      else
        throw new AssertException("Expected exception " +
          expectedExceptionClass.getName() +
          ", actual was " +
          exClass.getName());
    }

    throw new AssertException("Expected exception " +
      expectedExceptionClass.getName() +
      ", no exception thrown");
  }

  @FunctionalInterface
  public interface ThrowingFunction<E extends Exception> {

    void apply() throws E;
  }

  public class AssertException extends Exception {

    public AssertException(String message) {
        super(message);
    }
}
}
