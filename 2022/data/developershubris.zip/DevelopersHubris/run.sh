docker build -t developershubris:latest .
docker run --rm -d -p ${HOST_PORT}:8080 -e FLAG=flag{8db7145f70954219ba589a54586710da} developershubris:latest
