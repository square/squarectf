# Yet Another Reversing Activity

## Description
> Supposedly [this file](./dist/flag.yarc) can recognize a flag. But what could it be?

## Solution
The file is a compiled YARA rule. Typically YARA rules are just distributed as text:
```
rule example
{
    strings:
        $a = {6A 40 68 00 30 00 00 6A 14 8D 91}
        $b = {8D 4D B0 2B C1 83 C0 27 99 6A 4E 59 F7 F9}
        $c = "UVODFRYSIHLNWPEJXQZAKCBGMT"

    condition:
        $a or $b or $c
}
```
At evaluation time, yara compiles this rule into bytecode and executes it on a simple VM. You can also perform the compilation step ahead of time to make evaluation a bit more efficient - and, helpfully for us, obfuscate the rule a bit.

To make it a bit trickier, the compiled rule used in this challenge contains no metadata or strings; the only non-bytecode data is the rule name, `flag`. The rule is along these lines:
```
rule flag {
    condition:
        int8(0) == 0x59 ^ 0x3f and int8(1) == ...
}
```

While there are a couple of Yara decompilers out there, they all seem to be pretty out-of-date and can't handle even this simple rule. As an extra gotcha, the Yara developers keep changing the opcode values between releases - e.g., `OP_PUSH_8` is opcode `60` in [yara 4.2.3](https://github.com/VirusTotal/yara/blob/v4.2.3/libyara/include/yara/exec.h#L108), but opcode `63` in the [current tip-of-tree](https://github.com/VirusTotal/yara/blob/master/libyara/include/yara/exec.h#L111).

### Enabling verbose output from `yara`
One approach to this challenge is to check out [the Yara source code](https://github.com/VirusTotal/yara/tree/v4.2.3), build it with
```
./bootstrap.sh
./configure  --with-debug-verbose=2`, build, 
make
```
then use the debug-enabled `yara` to test the compiled rule against a file. The `--with-debug-verbose=2` option causes Yara to print every bytecode instruction it evaluates:
```
[... snip ...]
0.001150 018517     + yr_execute_code() {
0.001259 018517       - case OP_INIT_RULE: // yr_execute_code()
0.001292 018517       - case OP_PUSH_8: r1.i=0 // yr_execute_code()
0.001308 018517       - case OP_INT8: // yr_execute_code()
0.001319 018517       - _yr_get_first_block() {} = 0x16afd1fc0 // default iterator; single memory block, blocking
0.001330 018517       - case OP_PUSH_8: r1.i=213 // yr_execute_code()
0.001343 018517       - case OP_PUSH_8: r1.i=179 // yr_execute_code()
0.001354 018517       - case OP_BITWISE_XOR: // yr_execute_code()
0.001366 018517       - case OP_INT_EQ: // yr_execute_code()
0.001376 018517       - case OP_JFALSE: // yr_execute_code()
[... snip ...]
```
It's not _too_ hard to believe that this is testing the rule
```
int8(0) = 213 ^ 179
```
which implies that the first byte of the flag should be `chr(213 ^ 179) = chr(102) = 'f'`. Yara stops evaluating when a rule can no longer match, so this doesn't immediately dump the flag in its entirety, but it's straightforward to extract the flag one byte at a time.


### Reversing the rule directly
The "hardcore" approach to solving is to make educated guesses about the structure of the compiled rule. Some patterns are immediately evident when looking at the bytes:
```
00000130: 0000 0000 3c00 f03c 7a3c 1c07 642f 0f00  ....<..<z<..d/..
00000140: 0000 3c01 f03c 123c 7e07 6401 2f0f 0000  ..<..<.<~.d./...
00000150: 003c 02f0 3cbe 3cdf 0764 012f 0f00 0000  .<..<.<..d./....
00000160: 3c03 f03c 4c3c 2b07 6401 2f0f 0000 003c  <..<L<+.d./....<
00000170: 04f0 3cdf 3ca4 0764 012f 0f00 0000 3c05  ..<.<..d./....<.
```
There's an obvious repeated pattern:
```
00000134: 3c00 f03c 593c 3f07 64   2f0f 0000 00  <..<Y<?.d /....
00000142: 3c01 f03c 963c fa07 6401 2f0f 0000 00  <..<.<..d./....
00000151: 3c02 f03c 683c 0907 6401 2f0f 0000 00  <..<h<..d./....
00000160: 3c03 f03c 1e3c 7907 6401 2f0f 0000 00  <..<.<y.d./....
0000016f: 3c04 f03c b63c cd07 6401 2f0f 0000 00  <..<.<..d./....
```
Byte 2 is a counter, and bytes 5 and 7 change each line. As soon as a participant notices that `0x59 ^ 0x3f = 'f'` they'll immediately recognize how to extract the remaining flag bytes.

