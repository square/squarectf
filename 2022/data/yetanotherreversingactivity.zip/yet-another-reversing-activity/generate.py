import secrets
import subprocess
import os

with open('flag.txt', 'rb') as f:
    flag = f.read()

mask = secrets.token_bytes(len(flag))

# Generate a list of pairs which, when XORed, generate the flag bytes
pairs = [
    (mask[i], flag[i] ^ mask[i]) for i in range(len(flag))
]

conditions = [
    f"int8({i}) == {hex(pair[0])} ^ {hex(pair[1])}"
    for (i, pair) in enumerate(pairs)
]

yara_file = f"""
rule flag {{
    condition:
        {' and '.join(conditions)}
}}
"""

with open('flag.yar', 'w') as f:
    f.write(yara_file)

subprocess.run([
    'yarac', 'flag.yar', 'flag.yarc'
])

os.remove('flag.yar')