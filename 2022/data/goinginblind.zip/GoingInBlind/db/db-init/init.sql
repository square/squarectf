DROP TABLE IF EXISTS `user`;
DROP TABLE IF EXISTS `flag`;

CREATE TABLE `user` (
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `flag` (
    `flag` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

LOCK TABLES `user` WRITE;
INSERT INTO `user` VALUES ('admin','password'),('ahanlon',NULL);
UNLOCK TABLES;

LOCK TABLES `flag` WRITE;
INSERT INTO `flag` VALUES ('flag{a7a7add7dd9a4eb3a8d2e9ce0ab39872}');
UNLOCK TABLES;