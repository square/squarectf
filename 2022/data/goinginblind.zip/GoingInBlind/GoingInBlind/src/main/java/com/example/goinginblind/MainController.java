package com.example.goinginblind;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MainController {

  @GetMapping()
  public String getLogin (@RequestParam(defaultValue="", required=false) String username,
      @RequestParam(defaultValue="", required=false) String password,
      Model model){
    model.addAttribute("message", login(username, password));
    return "main";
  }

  @PostMapping()
  public String postLogin (@RequestParam(defaultValue="", required=false) String username,
      @RequestParam(defaultValue="", required=false) String password,
      Model model){
    if(!username.chars().allMatch(Character::isLetterOrDigit))
      throw new RuntimeException("username must contain alphanumeric characters only");
      if(!password.chars().allMatch(Character::isLetterOrDigit))
      throw new RuntimeException("password must contain alphanumeric characters only");
    model.addAttribute("message", login(username, password));
    return "main";
  }

  private String login (String username,
      String password) {

    if (username.equals("") && password.equals(""))
      return null;

    String myUrl = "jdbc:mysql://"+
        System.getProperty("DB_HOST", "db")+
        ":3306/"+
        System.getProperty("DB_NAME", "appdb")+
        "?allowPublicKeyRetrieval=true&useSSL=false";

    String db_user = System.getProperty("DB_USER", "app");
    String db_password = System.getProperty("DB_PASSWORD", "password");
    try (Connection connection = DriverManager.getConnection(myUrl,
        db_user,
        db_password))
    {
      Statement statement = connection.createStatement();
      ResultSet resultSet = statement.executeQuery("SELECT username FROM user WHERE username='"+username+"' AND password='"+password+"'");

      if(resultSet.next())
      {
        String dbUserName = resultSet.getString("username");
        if(dbUserName.equals("ahanlon"))
          return "Great! You logged in, but you'll have to dig around for the flag";
        else
          return "Sorry, "+dbUserName+" is the wrong user";
      }
    }
    catch (SQLException e) {
    }

    return "Nope, try again";
  }
}
