package com.example.goinginblind;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoingInBlindApplication {

  public static void main(String[] args) {
    SpringApplication.run(GoingInBlindApplication.class, args);
  }
}
