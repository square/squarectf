# Going In Blind

Square 2022 Web CTF challenge

## Description

Ok, the developers got smart, and figured out a way to prevent SQLi in the login page. Plus, they decided the flag shouldn't be hardcoded in the web application anymore. How could anyone get to it now?


## Hints

1. Wait, did we make sure the input sanitization will run on every codepath?
2. Being blind doesn't mean you can't find what you're looking for


## Notes

This application used for this challenge consists of 2 containers (web and DB), and the flag is stored in a DB initialization script, so participants will not get access to the source.

Also, Alex's user is stored in the DB as `('ahanlon', NULL)`, and the web application requires login requests to have a non-null username and password, so it is literally impossible to enter the valid password in a request, so no brute forcing.

## Solution

This time, participants will notice that if a non-alphanumeric character is included in the username and/or password, they'll get an error message of `username must contain alphanumeric characters only` with a stack trace, showing that exception is thrown in a method called `MainController.postLogin`, which implies that the input validation logic was written directly into that method that handles POST requests. So if the participants provide the username and password in a GET request instead, they'll bypass the input validation and be able to login as ***ahanlon*** again. Unfortunately for them, they'll receive a message saying `Great! You logged in, but you'll have to dig around for the flag`.

From here, they'll need to use a Boolean-based Blind SQL Injection technique to extract data from the database. Using a tool like sqlmap will do the trick, or they can do this manually by trying to login with the following usernames and seeing if the login is successful or not:

```
/?username=ahanlon'+AND+EXISTS(SELECT+table_name+FROM+information_schema.tables+WHERE+table_name+%3d+'flag')%3b%23
/?username=ahanlon'+AND+EXISTS(SELECT+flag+FROM+flag+WHERE+flag+LIKE+'flag%7b%25%7d')%3b%23
```