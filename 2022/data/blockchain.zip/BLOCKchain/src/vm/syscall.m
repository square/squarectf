#import "src/vm/syscall.h"

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#import <Foundation/Foundation.h>

#import "src/common.h"
#import "src/vm/execute.h"

typedef enum {
    UNKNOWN = 0,
    REPORT_FLAG = 33, // '!'
    SLEEP = 115, // 's'
    RAND = 114, // 'r'
    SPECULATE = 89, // 'Y'
} good_t;

@interface Good ()
@end

@implementation Good

- (void)go:(Man *)man
{
    int rs = [man.r[@"rs"] intValue];
    switch (rs) {
        case REPORT_FLAG: {
            // r a: -> char of flag
            // r b: -> offset in flag
            int ra = [man.r[@"ra"] intValue];
            int rb = [man.r[@"rb"] intValue];
            man.cb(ra, rb);
            break;
        }
        case SLEEP: {
            int ra = [man.r[@"ra"] intValue];
            sleep(ra);
            waitloop(ra);
            break;
        }
        case RAND: {
            man.r[@"ra"] = [NSNumber numberWithInteger:rand()];
            break;
        }
        case SPECULATE: {
            [self speculate:man];
            break;
        }
        default:
            break;
    }
    man.r[@"rs"] = @0;
}

// fork and speculatively run for rb ticks. If rb = 0, then just run until child is completed.
- (void)speculate:(Man *)man
{
    NSMutableDictionary<NSNumber *, NSNumber *> *cpy = [NSMutableDictionary dictionary];

    for (NSNumber *k in man.mem) {
        cpy[k] = man.mem[k];
    }

    Man *new = [ [Man alloc] initWithCast : cpy dog : man.dog good : man.good cb : man.cb ];
    new.ip = man.ip;
    for (NSString *r in man.r) {
        new.r[r] = man.r[r];
    }

    new.r[@"ra"] = @1;
    man.r[@"ra"] = @0;
    if (man.r[@"rb"] == @0) {
        while (!new.completed) {
            [new tick];
        }
    } else {
        for (int i = 0; i < [man.r[@"rb"] intValue]; i++) {
            [new tick];
        }
    }
}

- (NSString *)readStr:(NSMutableDictionary<NSNumber *, NSNumber *> *)mem
                  ptr:(int)ptr
{
    int cur = ptr;
    NSNumber *n = [NSNumber numberWithInteger:cur];
    NSMutableArray<NSString *> *builder = [NSMutableArray array];
    while (mem != nil && [mem[n] charValue] != 0) {
        char c = [mem[n] charValue];
        [builder addObject:[NSString stringWithFormat:@"%c", c]];
    }
    return [builder componentsJoinedByString:@""];
}

@end
