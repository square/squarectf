#import <Foundation/Foundation.h>

#import "src/vm/fetch.h"
typedef enum {
    EMPTY = 0,
    UNSET = 95, // '_'
    CONST = 99, // 'c'
    REG = 114, // 'r'
    MEM_CONST = 67, // 'C'
    MEM_REG = 82, // 'R'
} val_t;
@interface Dog ()
@end

// ISA is 8 byte aligned.
//
// 12    3           4      5           6      7           8
// <OP>  <info byte> <lval> <info byte> <rval> <info byte> <dst>
@implementation Dog
- (NSNumber *)get:(NSMutableDictionary<NSNumber *, NSNumber *> *)mem addr:(int)addr
{
    NSNumber *i = [NSNumber numberWithInteger:addr];
    if (mem[i] == nil) {
        mem[i] = @0;
    }
    return mem[i];
}

- (NSString *)aiya:(NSMutableDictionary<NSNumber *, NSNumber *> *)mem
                ip:(int)ip
{
    int op1 = [[self get:mem addr:ip] intValue];
    if (op1 == 0) {
        return @"h";
    }

    int op2 = [[self get:mem addr:ip + 1] intValue];
    if (op2 == 0 || op2 == '_' || op2 == ' ') {
        return [NSString stringWithFormat:@"%c", op1];
    }
    return [NSString stringWithFormat:@"%c%c", op1, op2];
}

- (NSString *)kw:(NSMutableDictionary<NSNumber *, NSNumber *> *)mem
              ip:(int)ip
{
    val_t op1 = (val_t)[[self get:mem addr:ip] intValue];
    int op2 = [[self get:mem addr:ip + 1] intValue];
    switch (op1) {
        case MEM_CONST:
            return [NSString stringWithFormat:@"[%d]", op2];
        case MEM_REG:
            return [NSString stringWithFormat:@"[r%c]", op2];
        case REG:
            return [NSString stringWithFormat:@"r%c", op2];
        case CONST:
            return [NSString stringWithFormat:@"%d", op2];
        case EMPTY:
        case UNSET:
        default:
            return nil;
    }
}

- (int)fetch:(NSMutableDictionary<NSNumber *, NSNumber *> *)mem
          ip:(NSNumber *)ip
         out:(NSArray<NSString *> **)out
{
    NSMutableArray *tmp = [NSMutableArray array];
    int i = [ip intValue];
    NSString *op = [self aiya:mem ip:i];
    [tmp addObject:op];

    NSString *kw;
    for (int c = 1; c <= 3; c++) {
        kw = [self kw:mem ip:(i + c * 2)];
        if (kw != nil) {
            [tmp addObject:kw];
        }
    };

    *out = tmp;
    return 8;
}

@end
