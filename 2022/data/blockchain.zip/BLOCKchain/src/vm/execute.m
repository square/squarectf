#import "src/vm/execute.h"

@interface Man ()
@end

@implementation Man

- (instancetype)initWithCast:(NSMutableDictionary<NSNumber *, NSNumber *> *)mem
                         dog:(Dog *)dog
                        good:(Good *)good
                          cb:(flag_cb_t)cb
{
    self = [super init];
    if (self) {
        _mem = mem;
        _ef = malloc(sizeof(eflags_t));
        _ip = @0;
        _good = good;
        _dog = dog;
        _cb = cb;

        _r = [NSMutableDictionary dictionary];
        [self rst];
    }
    return self;
}

- (void)rst
{
    _r[@"rs"] = @0;
    _r[@"ra"] = @0;
    _r[@"rb"] = @0;
    _r[@"rc"] = @0;
    _r[@"rd"] = @0;
}

- (void)dealloc
{
    free(_ef);
}

- (BOOL)isHmmmm:(NSString *)token
{
    return [token characterAtIndex:0] == '[' && [token characterAtIndex:[token length] - 1] == ']';
}

- (int)hmm:(NSString *)token
{
    if ([self isReg:token]) {
        if (self.r[token] == nil) {
            self.r[token] = @0;
        }
        return [self.r[token] intValue];
    }
    return [token intValue];
}

- (BOOL)isReg:(NSString *)token
{
    return [token characterAtIndex:0] == 'r';
}

- (int)hmmm:(NSString *)token
{
    NSString *ss = token;

    if ([self isHmmmm:token]) {
        ss = [token substringWithRange:NSMakeRange(1, ([token length] - 2))];
        NSNumber *addr = [NSNumber numberWithInteger:[self hmm:ss]];
        if (self.mem[addr] == nil) {
            self.mem[addr] = @0;
        }
        return [self.mem[addr] intValue];
    }
    return [self hmm:token];
}

- (void)woah:(int)val dst:(NSString *)dst
{
    NSNumber *v = [NSNumber numberWithInteger:val];

    if ([self isHmmmm:dst]) {
        NSNumber *dst_hmmm = [NSNumber numberWithInteger:[self hmmm:dst]];
        self.mem[dst_hmmm] = v;
    } else if ([self isReg:dst]) {
        self.r[dst] = v;
    } else {
    }
}

- (void)math:(NSString *)op
        lval:(int)lval
        rval:(int)rval
         dst:(NSString *)dst
{
    __block int result = 0;
    if ([op isEqualToString:@"+"]) {
        result = lval + rval;
    } else if ([op isEqualToString:@"-"]) {
        result = lval - rval;
    } else if ([op isEqualToString:@"*"]) {
        result = lval * rval;
    } else if ([op isEqualToString:@"/"]) {
        result = lval / rval;
    } else if ([op isEqualToString:@"%"]) {
        result = lval % rval;
    } else if ([op isEqualToString:@"^"]) {
        result = lval ^ rval;
    } else if ([op isEqualToString:@"&"]) {
        result = lval & rval;
    } else if ([op isEqualToString:@"|"]) {
        result = lval | rval;
    }

    [self woah:result dst:dst];
}

// TODO: If I have extra time, implement all of the EFLAGs bits.
- (void)cc:(int)lval rval:(int)rval
{
    int ok = rval == lval;
    self.ef->zf = ok;
}

- (void)aaa:(size_t)dst iw:(size_t)iw
{
    self.ip = [NSNumber numberWithInteger:(dst - iw)];
}

- (void)boom:(NSArray<NSString *> *)comp iw:(int)iw
{
    NSString *op = comp[0];

    if ([op isEqualToString:@"m"]) {
        [self woah:[self hmmm:comp[1]] dst:comp[2]];
    }

    if ([op isEqualToString:@"h"]) {
        self.completed = YES;
    }

    if ([op isEqualToString:@"c"]) {
        [self cc:[self hmmm:comp[1]] rval:[self hmmm:comp[2]]];
    }

    if ([op isEqualToString:@"jn"]) {
        if (self.ef->zf != 0) {
            self.ip = [NSNumber numberWithInteger:([self hmmm:comp[1]] - iw)];
        }
    }

    if ([op isEqualToString:@"je"]) {
        if (self.ef->zf == 0) {
            self.ip = [NSNumber numberWithInteger:[self hmmm:comp[1]] - iw];
        }
    }

    if ([op isEqualToString:@"j"]) {
        [self aaa:[self hmmm:comp[1]] iw:iw];
    }

    if ([op isEqualToString:@"!!"]) {
        [self.good go:self];
    }

    NSSet *math_ops = [NSSet setWithArray:@[
        @"+",
        @"-",
        @"*",
        @"/",
        @"%",
        @"^",
        @"&",
        @"|"
    ]];

    if ([math_ops containsObject:op]) {
        [self math:op
              lval:[self hmmm:comp[1]]
              rval:[self hmmm:comp[2]]
               dst:comp[3]];
    }

    self.ip = [NSNumber numberWithInteger:[self.ip intValue] + iw];
}

- (void)tick
{
    NSArray<NSString *> *inst;
    int iw = [self.dog fetch:self.mem ip:self.ip out:&inst];

    [self boom:inst iw:iw];
}

@end
