#pragma once
#import <Foundation/Foundation.h>

#import "src/vm/execute.h"

@class Man;

@interface Good : NSObject
- (void)go:(Man*)man;
@end
