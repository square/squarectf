#import <Foundation/Foundation.h>

// Fetcher + decoder implementation
@interface Dog : NSObject
- (int)fetch:(NSMutableDictionary<NSNumber *, NSNumber *> *)mem
          ip:(NSNumber *)ip
         out:(NSArray<NSString *> **)out;
@end
