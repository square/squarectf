#pragma once
#import <Foundation/Foundation.h>

#import "src/common.h"
#import "src/vm/syscall.h"
#import "src/vm/fetch.h"

typedef struct {
    BOOL of;
    BOOL zf;
    BOOL sf;
} eflags_t;

@class Good;

// Executer implementation.
@interface Man : NSObject
@property(nonatomic, readwrite) BOOL completed;
@property(nonatomic, readwrite) NSMutableDictionary<NSString *, NSNumber *> *r;
@property(nonatomic, readwrite) NSMutableDictionary<NSNumber *, NSNumber *> *mem;
@property(nonatomic, readwrite) eflags_t *ef;
@property(nonatomic, readwrite) Good *good;
@property(nonatomic, readwrite) Dog *dog;
@property(nonatomic, readonly) flag_cb_t cb;
@property NSNumber *ip;

- (instancetype)initWithCast:(NSMutableDictionary<NSNumber *, NSNumber *> *)mem
                         dog:(Dog *)dog
                        good:(Good *)good
                          cb:(flag_cb_t)cb;

- (void)tick;
- (BOOL)completed;
- (void)rst;
- (void)boom:(NSArray<NSString *> *)comp iw:(int)iw;

@end
