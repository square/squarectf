#import "src/worker.h"

#import <Foundation/Foundation.h>

#import "src/common.h"
#import "src/vm/execute.h"
#import "src/vm/syscall.h"
#import "src/vm/fetch.h"

@interface Worker ()
@property(nonatomic, readonly) Man *man;
@end

@implementation Worker

- (instancetype)initWithCast:(NSMutableDictionary<NSNumber *, NSNumber *> *)mem
                         dog:(Dog *)dog
                        good:(Good *)good
                          cb:(flag_cb_t)cb
{
    self = [super init];
    if (self) {
        _man = [[Man alloc] initWithCast:mem dog:dog good:good cb:cb];
    }

    return self;
}

- (void)tick
{
    if (self.man.completed) {
        self.completed = self.man.completed;
        return;
    }
    [self.man tick];
    [NSThread sleepForTimeInterval:1.0f];
}

@end
