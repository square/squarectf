#include <unistd.h>
typedef void (^flag_cb_t)(char got, size_t index);

#define waitloop(s)            \
    time_t t = time(NULL);     \
    while (time(NULL) - t < s) \
        ;
