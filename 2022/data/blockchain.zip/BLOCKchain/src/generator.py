import random


def tmpl(prog, i):
    k2 = random.randint(0, 255)

    encoded = [i ^ k2 for i in prog]
    return """
- (NSMutableDictionary<NSNumber*, NSNumber*>*)hmm%s
{
    NSMutableDictionary<NSNumber*, NSNumber*>* m = [NSMutableDictionary dictionary];
    int k = %s;
    NSArray *test = %s;
    for (size_t i = 0; i < [test count]; i++) {
        m[[NSNumber numberWithInteger:i]] = [NSNumber numberWithInteger:[test[i] intValue] ^ k];

    }
    return m;
};
    """ % (i, k2, formatted(encoded))


class Assembler(object):

    def __init__(self, sym):
        self.reloc = {}
        self.lines = []
        self.sym = sym

    def parse_code(self, raw_code):
        p = [i for i in raw_code.split("\n") if i != ""]

        comp = []
        tokens = []

        for i in range(len(p)):
            comp = p[i].split(" ")

            # catch tags by line number
            if comp[0][0] == ":":
                self.reloc[comp[0]] = i
                comp = comp[1:]
            if len(comp) < 8:
                for pad in range(8 - len(comp)):
                    comp.append("_")

            for token in range(len(comp)):
                if comp[token][0] == "$":
                    comp[token] = self.sym[comp[token]]

            tokens.append(comp)

        assembled = [j for i in tokens for j in i]
        for i in range(len(assembled)):
            if str(assembled[i])[0] == ":":
                ln = self.reloc[assembled[i]]
                assembled[i] = ln * 8

        return assembled


with open("flag.txt", "r") as FILE:
    flag = FILE.read()

with open("simple_prog", "r") as FILE:
    prog1 = FILE.read()

with open("simple_prog2", "r") as FILE:
    prog2 = FILE.read()


def formatted(encoded):
    return '@[' + ", ".join("@%s" % (i) for i in encoded) + ']'


def gen_prog1(i):
    c = flag[i]

    key = random.randint(0, 255)
    a = Assembler({
        "$obf_char": ord(c) ^ key,
        "$xor_k": key,
        "$obf_off": i,
    })
    prog = a.parse_code(prog1)
    for c in range(len(prog)):
        if type(prog[c]) == str:
            if (prog[c].isnumeric()):
                prog[c] = int(prog[c])
            else:
                prog[c] = ord(prog[c])
    return tmpl(prog, i)


def gen_prog2(p, k, j):
    f = flag[k:j]

    padding = 300
    key = random.randint(0, 255)
    a = Assembler({
        "$xor_k": key,
        "$padding": padding,
    })
    prog = a.parse_code(p)

    for c in range(len(prog)):
        if type(prog[c]) == str:
            if (prog[c].isnumeric()):
                prog[c] = int(prog[c])
            else:
                prog[c] = ord(prog[c])

    for i in range(len(prog), padding):
        prog.append(0)

    for i in f:
        prog.append(ord(i) ^ key)
        prog.append(random.randint(100, 200) ^ key)

    return tmpl(prog, k)


for i in range(5, len(flag)):
    print(gen_prog1(i))

#print(gen_prog2(prog2, 40, len(flag)))
