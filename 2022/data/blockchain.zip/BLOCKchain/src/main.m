
#import <Foundation/Foundation.h>
#import <dispatch/dispatch.h>

#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>

#include <dlfcn.h>
#include <mach/mach_init.h>
#include <mach/task.h>
#include <mach-o/getsect.h>
#include <mach-o/dyld.h>

#include <sys/mman.h>
#include <sys/sysctl.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/types.h>

#import "src/common.h"
#import "src/calculator.h"

// AmIBeingDebugged from https://developer.apple.com/library/archive/qa/qa1361/_index.html
static inline BOOL huh(void)
{
    int junk;
    int mib[4];
    struct kinfo_proc info;
    size_t size;

    info.kp_proc.p_flag = 0;

    mib[0] = CTL_KERN;
    mib[1] = KERN_PROC;
    mib[2] = KERN_PROC_PID;
    mib[3] = getpid();

    size = sizeof(info);
    junk = sysctl(mib, sizeof(mib) / sizeof(*mib), &info, &size, NULL, 0);
    assert(junk == 0);

    return ((info.kp_proc.p_flag & P_TRACED) != 0);
}

static inline void dyld_insert(void)
{
    if ([[[NSProcessInfo processInfo] environment] objectForKey:@"DYLD_INSERT_LIBRARIES"] != nil) {
        exit(1);
    }
}

static inline BOOL deboog(void)
{
    dyld_insert();
    ptrace(PT_DENY_ATTACH, 0, 0, 0);
    syscall(26, 31, 0, 0);

    if (huh()) {
        exit(1);
        return YES;
    }

    if (!ioctl(1, TIOCGWINSZ)) {
        exit(1);
        return YES;
    }

    return NO;
}

@interface Assembly : NSObject
@property(nonatomic, readwrite) NSMutableArray<NSString *> *known;
@end

@implementation Assembly
- (instancetype)init
{
    self = [super init];
    if (self) {
        _known = [NSMutableArray array];
    }
    return self;
}

- (void)extend:(size_t)n
{
    for (size_t i = [self.known count]; i <= n; i++) {
        [self.known addObject:@"?"];
    }
}

- (void)gotChar:(char)c i:(size_t)i
{
    if (i > [self.known count]) {
        [self extend:i];
    }
    self.known[i] = [NSString stringWithFormat:@"%c", c];
}

- (NSString *)f
{
    return [self.known componentsJoinedByString:@""];
}
@end

__attribute__((constructor)) static void init(int argc, const char **argv, const char **envp, const char **apple, struct ProgramVars *pvars)
{
    if (deboog()) {
        exit(1);
    }
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(queue, ^{
      while (true) {
          if (deboog()) {
              exit(1);
          }
          waitloop(10);
      }
    });
}

int main(int argc, const char *argv[])
{
    Calculator *calculator = [[Calculator alloc] init];

    NSLog(@"Calculating the flag...");

    __block Assembly *a = [[Assembly alloc] init];
    [calculator subscribe:^(char got, size_t index) {
      [a gotChar:got i:index];
      NSLog(@"%@", [a f]);
    }];
    [calculator freebies];

    while (![calculator completed]) {
        [calculator tick];
    }

    return 0;
}
