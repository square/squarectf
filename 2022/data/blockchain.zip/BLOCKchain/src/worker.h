#pragma once
#import <Foundation/Foundation.h>

#import "common.h"
#import "src/vm/execute.h"
#import "src/vm/syscall.h"
#import "src/vm/fetch.h"

@interface Worker : NSObject
@property(nonatomic, readwrite) BOOL completed;
- (instancetype)initWithCast:(NSMutableDictionary<NSNumber *, NSNumber *> *)mem
                         dog:(Dog *)dog
                        good:(Good *)good
                          cb:(flag_cb_t)cb;
- (void)tick;
@end
