#pragma once
#import <Foundation/Foundation.h>

#import "src/common.h"
#import "src/vm/execute.h"

@interface Calculator : NSObject
@property(nonatomic, readwrite) BOOL completed;
- (instancetype)init;
- (void)tick;
- (void)subscribe:(flag_cb_t)cb;
- (void)freebies;
- (void)phone:(char)chr i:(size_t)i;
@end
