# ez-re-1

## Point Value
50

## Challenge Description
all that cryptography stuff is real confusing. how hard could it REALLY be? 
<br>Required Reading:
<br>- intro to x86 https://www.cs.virginia.edu/~evans/cs216/guides/x86.html
<br>- basic documentation for a disassembler of your choosing (try Ghidra, Binary Ninja Cloud, or IDA Freeware)

<br><br><a href='/static/files/ez-re-1/ez-re-1_elf'>elf binary</a>, <a href='/static/files/ez-re-1/ez-re-1_macho'>macho binary</a> 

## Description
Very simple RE challenge, theres a hardcoded byte string thats just an xored flag with a 5 byte key. the 5 byte part is hardcoded, and the ciphertext can be assumed to start with "flag{" (the binary even checks if the first 5 bytes are "flag{") so no brute forcing is even required), so players should pretty easily derive the key "lolxd", which the program will take as input and attempt to "decrypt" the ciphertext with.
I also included a hardcoded byte array of ascii art of the "is this a butterfly" meme with the text "is this cryptography" xored with the same key just for funsies.

## Deployment
Players need access to the static ez-pwn-1_elf and ez-pwn-1_macho binary.