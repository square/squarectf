package main

import (
	"bytes"
	"crypto/tls"
	"fmt"
	"net/http"
	"os"
	"strconv"

	"github.com/OpenPrinting/goipp"
)

const printerURI = "https://192.168.56.1:8631/ipp/print"

var client = &http.Client{
	Transport: &http.Transport{
		TLSClientConfig: &tls.Config{
			MinVersion: tls.VersionTLS12,
			MaxVersion: tls.VersionTLS12,
			CipherSuites: []uint16{
				tls.TLS_RSA_WITH_AES_256_GCM_SHA384,
			},
			InsecureSkipVerify: true,
		},
	},
}

var requestID uint32 = 0

func ippDefaultRequest() *goipp.Message {
	requestID++

	m := &goipp.Message{
		Version:   goipp.DefaultVersion,
		RequestID: requestID,
	}
	m.Operation.Add(goipp.MakeAttribute("attributes-charset", goipp.TagCharset, goipp.String("utf-8")))
	m.Operation.Add(goipp.MakeAttribute("attributes-natural-language", goipp.TagLanguage, goipp.String("en-US")))
	m.Operation.Add(goipp.MakeAttribute("printer-uri", goipp.TagURI, goipp.String(printerURI)))
	m.Operation.Add(goipp.MakeAttribute("requesting-user-name", goipp.TagName, goipp.String("vboxuser")))

	return m
}

func ippGetPrinterAttributesRequest() *goipp.Message {
	m := ippDefaultRequest()
	m.Code = goipp.Code(goipp.OpGetPrinterAttributes)

	requestedAttributes := goipp.Attribute{Name: "requested-attributes"}
	requestedAttributes.Values.Add(goipp.TagKeyword, goipp.String("printer-name"))
	requestedAttributes.Values.Add(goipp.TagKeyword, goipp.String("printer-state"))
	requestedAttributes.Values.Add(goipp.TagKeyword, goipp.String("printer-state-reasons"))
	requestedAttributes.Values.Add(goipp.TagKeyword, goipp.String("printer-is-accepting-jobs"))
	requestedAttributes.Values.Add(goipp.TagKeyword, goipp.String("operations-supported"))
	requestedAttributes.Values.Add(goipp.TagKeyword, goipp.String("document-format-supported"))
	m.Operation.Add(requestedAttributes)

	return m
}

func ippPrintJobRequest() *goipp.Message {
	m := ippDefaultRequest()
	m.Code = goipp.Code(goipp.OpPrintJob)
	m.Operation.Add(goipp.MakeAttribute("job-name", goipp.TagName, goipp.String("Untitled.pdf")))

	return m
}

func ippValidateJobRequest() *goipp.Message {
	m := ippPrintJobRequest()
	m.Code = goipp.Code(goipp.OpValidateJob)

	return m
}

func ippGetJobAttributesRequest(jobID int) *goipp.Message {
	m := ippDefaultRequest()
	m.Code = goipp.Code(goipp.OpGetJobAttributes)
	m.Operation.Add(goipp.MakeAttribute("job-id", goipp.TagInteger, goipp.Integer(jobID)))

	requestedAttributes := goipp.Attribute{Name: "requested-attributes"}
	requestedAttributes.Values.Add(goipp.TagKeyword, goipp.String("job-state"))
	requestedAttributes.Values.Add(goipp.TagKeyword, goipp.String("job-state-reasons"))
	m.Operation.Add(requestedAttributes)

	return m
}

func check(err error) {
	if err != nil {
		panic(err)
	}
}

func sendRequestWithBody(request *goipp.Message, body []byte) (response *goipp.Message) {
	fmt.Println("---- IPP REQUEST ----")
	request.Print(os.Stdout, true)

	requestBytes, err := request.EncodeBytes()
	check(err)

	httpRequestBody := bytes.NewBuffer(requestBytes)

	if len(body) != 0 {
		_, err = httpRequestBody.Write(body)
		check(err)
	}

	httpResponse, err := client.Post(printerURI, goipp.ContentType, httpRequestBody)
	check(err)

	response = &goipp.Message{}
	err = response.Decode(httpResponse.Body)
	check(err)

	fmt.Println("---- IPP RESPONSE ----")
	response.Print(os.Stdout, false)

	return response
}

func sendRequest(request *goipp.Message) (response *goipp.Message) {
	return sendRequestWithBody(request, nil)
}

func parseJobID(response *goipp.Message) int {
	for _, jobAttr := range response.Job {
		if jobAttr.Name == "job-id" {
			jobID, err := strconv.Atoi(jobAttr.Values.String())
			check(err)
			return jobID
		}
	}
	panic("Failed parsing jobID")
}

func main() {
	flagBytes, err := os.ReadFile("./flag")
	check(err)

	sendRequest(ippGetPrinterAttributesRequest())
	sendRequest(ippValidateJobRequest())

	printJobResponse := sendRequestWithBody(ippPrintJobRequest(), flagBytes)
	jobID := parseJobID(printJobResponse)

	sendRequest(ippGetJobAttributesRequest(jobID))
	sendRequest(ippGetPrinterAttributesRequest())
}
