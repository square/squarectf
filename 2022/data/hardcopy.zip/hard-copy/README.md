# Hard Copy

## Description

> I printed a hard copy of the flag, but then I lost it. Will you help me recover it? Here's the [source code](./dist/printer.go) for my printer and a recent [network traffic dump](./dist/capture.pcap).

## Setup

Participants should be given [`./dist/printer.go`](./dist/printer.go) and [`./dist/capture.pcap`](./dist/capture.pcap).

## Solution

At a high level, the participant needs to exploit two vulnerabilities:

1. Weak RSA prime generation in `printer.go`, and
2. Weak cipher chosen in TLS traffic.

The printer's source code reveals a custom RSA key generation function. This function essentially

- Chooses a random 1028-bit prime for `p`,
- To find `q`, it starts with the value of `p`, flips the third most significant bit, and then finds the next prime in ascending or descending order depending on whether `q` is greater than or less than `p`.
- Takes the usual approach to constructing a private key from `p` and `q`.

This method of generating RSA primes is not secure because the approximate difference between `p` and `q` can be easily guessed. This difference can be used to factor the public key modulus, `N`, into `p` and `q`. There are two methods of doing this that I'm aware of: Fermat's factorization method and a method based on the quadratic formula. Both of these approaches are implemented in the solver script at [`./solver/solver.go`](./solver/solver.go).

Additionally, the packet capture file reveals that the TLS session is using [`TLS_RSA_WITH_AES_256_GCM_SHA384`](https://ciphersuite.info/cs/TLS_RSA_WITH_AES_256_GCM_SHA384/) which is weak cipher suite. This key exchange algorithm does not provide forward secrecy, which means an attacker can decrypt the entire communication stream given the private key.

The rest of this section describes the steps to exploit the weak prime and weak cipher suite vulnerabilities to recover the flag:

1. [Extract the printer's certificate from the packet capture file](#extract-the-printers-certificate-from-the-packet-capture-file)
2. [Factor the RSA modulus and recover the private key](#factor-the-rsa-modulus-and-recover-the-private-key)
3. [Decrypt the TLS traffic and recover the flag](#decrypt-the-tls-traffic-and-recover-the-flag)

### Extract the printer's certificate from the packet capture file

1. Open `capture.pcap` in Wireshark.
2. Select the packet with a label that begins with, "Server Hello, Certificate, "
    - This is the part of the TLS handshake that contains the server's certificate.
3. Find the certificate and right-click -> Export Packet Bytes...
    ![export-cert.png](./screenshots/export-cert.png)
4. Save the certificate as `cert-recovered.der`.
5. Run the following command to convert the certificate to PEM format: `openssl x509 -inform der -in cert-recovered.der -out cert-recovered.pem`

### Factor the RSA modulus and recover the private key

1. Run `go run ./solver`. This will generate `key-recovered.pem`.
    - This actually uses two different methods to factor the RSA modulus and recover the private key, one involving Fermat's factorization method, and other using the quadratic formula.
    - For a detailed description of how this works, see the comments in the solver source code.

### Decrypt the TLS traffic and recover the flag

1. In Wireshark, go to Preferences -> RSA Keys.
2. Select "Add new keyfile..." and select `key-recovered.pem`.
3. Restart Wireshark, and re-open `capture.pcap`.
4. Now, decrypted traffic should be visible. In the display filter menu, type "ipp" and press Enter. This will filter to just the IPP traffic.
5. Select the packet with label "IPP Request (Print-Job)"
    - This is the request containing the actual file to print.
6. Find the data and right-click -> Export Packet Bytes...
    ![export-data.png](./screenshots/export-data.png)
7. Save the file as `flag-recovered.pdf`.
    - This is actually a "HP Printer Job Language data" file, but on macOS the Preview app will recognize it as a PDF. On other platforms you might have to edit the file and delete the `@PJL` headers.
8. The PDF contains the flag!

## Re-Generate `flag` and `capture.pcap`

In case you need to re-generate `flag` and/or `capture.pcap`, (i.e. to change the flag), here are the high-level steps I used to generate it:

- Run an Ubuntu VM inside VirtualBox with a Host-Only network set to `192.168.56.1` (lower bound) and `192.168.56.199` (upper bound).
- Run the fake printer server on the host machine: `go run ./dist`
- Generate `flag`
    - Add the fake printer as a system printer.
    - Create a document in LibreOffice and type the flag into the document.
    - Print the document to the fake printer.
    - Grab the file written by the fake printer and rename as `flag`.
- Generate `capture.pcap`
    - Start Wireshark traffic capture inside the VM.
    - Run `go run ./client` to generate the traffic.
    - Stop the Wireshark capture and save the file as `capture.pcap`.

## References

- [Fermat Attack on RSA](https://fermatattack.secvuln.info/): This challenge was loosely based on this real-world vulnerability.
- [Breaking RSA - Computerphile - YouTube](https://www.youtube.com/watch?v=-ShwJqAalOk): Good video for understanding RSA and Fermat's factorization method.
- [Wireshark TLS Decryption](https://wiki.wireshark.org/TLS#tls-decryption): How to decrypt TLS traffic with Wireshark.
- [How to Use the Internet Printing Protocol](https://www.pwg.org/ipp/ippguide.html): Good resource for understanding the basics of IPP.
