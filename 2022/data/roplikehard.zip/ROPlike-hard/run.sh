#!/bin/bash

docker build . -t roplikehard
docker run -d -p ${HOST_PORT}:8000 roplikehard
