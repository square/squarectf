# ROPlike v1.0.2

## Point Value
400

## Challenge Description
<a href='https://{{ .Domain }}/static/files/ROPlike-hard/roplike-hard'>v1.0.2</a> balance changes
<br>- reduce number of rounds to make game more fun and interesting
<br>- add some anti-hacking mitigations because its come to my attention that SOME of you are cheating >:(

<br><br>v1.0.1 hotfix
<br>- remove overpowered syscall gadget
<br>- minor backend changes (does not impact gameplay)


## Description
the final flag is now in the_final_flag_is_here, and control flow for the binary has generally been flattened to give people less usable gadgets in the binary itself. Number of rounds has been reduced from 20 to 8 to require people to set up the game state a little more first.

## Deployment
players need the roplike binary, otherwise this should be deployed like a typical pwnable with the dockerfile in this directory.
