# sqUARe paymenT terminal pt 1

## Description
We found [this file](./dist/Terminal_Cap.sal) laying around on one of our hardware developer's old machines. Supposedly it contains a flag.

## Solution
Open the file in Logic 2 and add an `Async Serial` analyzer to channel 1. Set the baud rate to 38400 and then view the output in the data view.
