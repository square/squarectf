#!/bin/bash

docker build . -t roplikemedium
docker run -d -p ${HOST_PORT}:8000 roplikemedium
