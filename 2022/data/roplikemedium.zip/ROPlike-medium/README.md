# ROPlike v1.0.1

## Point Value
300

## Challenge Description
<a href='https://{{ .Domain }}/static/files/ROPlike-medium/roplike-medium'>v1.0.1</a> hotfix
<br>- remove overpowered syscall gadget
<br>- minor backend changes (does not impact gameplay)


## Description
The real flag is now contained in the_flag_is_actually_in_here.txt to prevent people from just using readfile to leak it. Gadget id #61 which contains the syscall gadget was removed entirely since it provides an easy execve exploit. A viable exploit should require an actual memory leak now via the print_buf gadget, or quite a bit of stack math and creativity.

## Deployment
players need the roplike binary, otherwise this should be deployed like a typical pwnable with the dockerfile in this directory.
