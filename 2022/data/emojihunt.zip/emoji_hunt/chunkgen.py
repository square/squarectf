import zlib

flag = "flag{emojis_more_like_free_cloud_storage}"
bytes_per_chunk = 2

def split_string_by_n(string, n):
    for i in range(0, len(string), n):
        yield(string[i:i +n])

def assemble_text_chunk(keyword, string):
    string_bytes = bytes(string, 'ascii') # zlib.compress(bytes(flag_chars, 'ascii'))
    separator = b'\x00'
    final_bytes = b''
    chunk_sz = len(keyword) + len(separator) + len(string_bytes)
    final_bytes += chunk_sz.to_bytes(4, "big")
    final_bytes += b'tEXt'
    final_bytes += bytes(keyword, 'ascii') + separator + string_bytes
    final_bytes += zlib.crc32(final_bytes[4:]).to_bytes(4, "big")
    return final_bytes

flag_chunks = list(split_string_by_n(flag, bytes_per_chunk))

for index, flag_chars in enumerate(flag_chunks):
    print(index, ": ", assemble_text_chunk("fl_" + str(index), flag_chars).hex())

print(assemble_text_chunk("flag", "flag{you_say_profile_picture_I_hear_free_cloud_storage_solution}").hex())