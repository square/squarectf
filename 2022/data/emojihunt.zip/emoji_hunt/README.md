# Emoji hunt

## Point Value
100

## Challenge Description
I was looking at some slack emojis the other day and it seemed like they had a bit more data than they were supposed to... In fact, it even looked like there were bits of flag floating around in them.

## Description
each of the 21 images have 2 bytes of a flag in a png tEXt chunk embedded in them, with a keyword denoting the index of the 2 bytes in the final flag string. Slack re-arranges the chunks on upload, but does not remove them. The intent is that contestants will need to recognize the flag chunks to begin with, then scrape all recent slack emojis and write a script to find the flag chunks in them. This works better on an active slack where there are lots of emojis being uploaded daily, or if a large amount of emojis are uploaded with these 21 interspersed.

## Deployment
This challenge is all hosted on slack, no deployment required.