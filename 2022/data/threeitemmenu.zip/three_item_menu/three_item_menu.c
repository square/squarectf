#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>
#include <stdbool.h>
#include <time.h>
#include <math.h>

uint64_t seed;

uint64_t next_seed()
{
    seed = (seed * 25214903917 + 11) % (uint64_t)(pow(2, 48));
    return seed;
}

int read_num()
{
    char buf[2];
    read(0, buf, 2);
    return atoi(buf);
}

void order(void)
{
    printf("We come with complementary serving of 32 bytes. How many extra bytes would you like to nibble on?\n");
    int len = read_num();

    printf("What would you like to eat?\n");
    printf("> ");

    char buf[32];
    read(0, buf, 32 + len);

    printf("One '%s', coming right up\n", buf);
}

void sample(void)
{
    printf("Where would you like to eat today?\n");
    printf("1. libc\n");
    printf("2. Stack shack\n");
    printf("3. ???\n");
    printf("> ");

    int choice = read_num();

    switch (choice) {
        case 1: {
            printf("One random sampling of libc coming right up: %x\n", (printf + next_seed()));
            break;
        }
        case 2: {
            printf("One random sampling of the stack coming right up: %x\n", (&choice + next_seed()));
            break;
        }
        case 3:
        default: {
            printf("One order of pure randomness: %llx\n", next_seed());
            break;
        }
    }
}

int main(int argc, char *argv[])
{
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);

    time_t t;
    seed = time(&t);

    while (true) {
        printf("Hello! Welcome to Square CTF, introducing everyone's favorite introductory three-item menu!\n");
        printf("1. Sample\n");
        printf("2. Order\n");
        printf("3. Goodbye\n");
        printf("> ");
        int choice = read_num();
        switch (choice) {
            case 1: {
                sample();
                break;
            }
            case 2: {
                order();
                return;
            }

            case 3:
            default: {
                printf("Good bye.");
                return 0;
            }
        }
    }
}
