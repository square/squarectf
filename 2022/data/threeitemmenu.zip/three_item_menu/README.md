# three_item_menu

## Description
Hello! Welcome to Square CTF, introducing everyone's favorite CTF three-item menu! <a href='/static/files/three_item_menu'>three_item_menu</a>; <a href='/static/files/libc.so.6'>libc.so.6</a>"

## Notes

Pwnable with a few extra constraints. These constraints are also knobs we can turn to change the difficulty of the problem. 

1. The read_num implementation gives you an overflow by up to 9 bytes, which constraints you to needing to set up a onegadget to fit an exploit. Edit: I realized that my implementation unintentionally actually made it possible to make it read 99 bytes.
2. Random values get added to the leak function that you get. Since the leak function uses an LCG, you'll have to implement an attack on it: See [https://jazzy.id.au/2010/09/21/cracking_random_number_generators_part_2.html](https://jazzy.id.au/2010/09/21/cracking_random_number_generators_part_2.html).
3. Due to the difference in integer precision, you end up not being able to recover the full address of printf. Instead, the stack leak lets you write to the printf libc address left on the stack. Use that + the pseudo-libc leak of printf you get to overwrite the end of printf to be a one_gadget.
