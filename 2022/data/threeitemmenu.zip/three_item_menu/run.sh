#!/bin/bash

docker build . -t three_item_menu
docker run --restart=always -d -p ${HOST_PORT}:8000 three_item_menu
