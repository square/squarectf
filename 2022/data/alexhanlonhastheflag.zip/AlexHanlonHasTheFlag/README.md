# Alex Hanlon Has The Flag!

Square 2022 Web CTF challenge

## Description

Alex Hanlon has saved the flag in his account! See if you can figure out his username and then login as him. But just know that it will be impossible to brute force his password.


## Hints

You don't need to figure out his password


## Notes

This application used for this challenge consists of 2 containers (web and DB), and the flag is stored in the web source code, so participants will not get access to the source.

Also, Alex's user is stored in the DB as `('ahanlon', NULL)`, and the web application requires login requests to have a non-null username and password, so it is literally impossible to enter the valid password in a request, so no brute forcing.

## Solution

Through intuition or just trial-and-error, participants will notice that if a single quote (`'`) is included in the username and/or password, they'll see a SQLSyntaxErrorException in the response, which should confirm that there's a SQL injection vulnerability. If they realize that my Block username is ***ahanlon***, and they try to login with a username of `ahanlon';#`, they'll be given the flag in the response.

Even if they don't figure out my username, they can try something like `' OR 1=1;#` so that the resulting query returns all users, but the web application will only look at the first user in the user table, which is ***admin***, so they'll get a message saying "Sorry, admin is the wrong user". From here, they can just change the payload to something like `' OR 1=1 AND username != 'admin';#` so that the admin user is skipped and ***ahanlon*** is returned first