package com.example.alexhanlonhastheflag;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller // This means that this class is a Controller
public class MainController {

  @PostMapping()
  public String postLogin (@RequestParam String username,
      @RequestParam String password,
      Model model) {

    model.addAttribute("message", "Nope, try again!");
    String myUrl = "jdbc:mysql://"+
        System.getProperty("DB_HOST", "db")+
        ":3306/"+
        System.getProperty("DB_NAME", "appdb")+
        "?allowPublicKeyRetrieval=true&useSSL=false";

    String db_user = System.getProperty("DB_USER", "app");
    String db_password = System.getProperty("DB_PASSWORD", "password");
    try (Connection connection = DriverManager.getConnection(myUrl,
        db_user,
        db_password))
    {
      Statement statement = connection.createStatement();
      ResultSet resultSet = statement.executeQuery("SELECT username FROM user WHERE username='"+username+"' AND password='"+password+"'");

      if(resultSet.next())
      {
        String dbUserName = resultSet.getString("username");
        if(dbUserName.equals("ahanlon"))
          model.addAttribute("message", "flag{470bbbc0519e4bc6987bb00bef24a97a}");
        else
          model.addAttribute("message", "Sorry, "+dbUserName+" is the wrong user" );
      }
    }
    catch (SQLException e) {
      StringBuilder stringBuilder = new StringBuilder("Exceptions:");
      Throwable currentException = e;
      while(currentException != null) {
        stringBuilder.append("\n\n" + currentException);
        currentException = currentException.getCause();
      }
      model.addAttribute("message", stringBuilder.toString());
    }

    return "main";
  }

  @GetMapping()
  public String getLogin() {
    return "main";
  }
}
