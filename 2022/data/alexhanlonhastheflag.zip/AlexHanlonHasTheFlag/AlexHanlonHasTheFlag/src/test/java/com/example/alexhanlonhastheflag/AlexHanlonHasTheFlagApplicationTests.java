package com.example.alexhanlonhastheflag;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlexHanlonHasTheFlagApplicationTests {

  @Test
  void contextLoads() {
  }
}
