#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/aes.h>
#include <openssl/rand.h>
#include <sys/stat.h>  // For stat to get file modification time
#include <time.h>

// Function to generate random bytes
void generate_random_bytes(unsigned char *buffer, int num_bytes, unsigned int seed) {
    srand(seed);
    for (int i = 0; i < num_bytes; i++) {
        buffer[i] = rand() % 256;
    }
}

// Function to decrypt the file using AES-256-CBC
void decrypt_file(const char *input_file, const char *output_file, unsigned char *key, unsigned char *iv) {
    FILE *fin = fopen(input_file, "rb");
    FILE *fout = fopen(output_file, "wb");

    if (!fin || !fout) {
        perror("File error");
        exit(1);
    }

    AES_KEY dec_key;
    AES_set_decrypt_key(key, 256, &dec_key);

    unsigned char inbuf[16];  // AES block size is 16 bytes
    unsigned char outbuf[16];
    int num_bytes_read;

    while ((num_bytes_read = fread(inbuf, 1, 16, fin)) > 0) {
        AES_cbc_encrypt(inbuf, outbuf, num_bytes_read, &dec_key, iv, AES_DECRYPT);
        fwrite(outbuf, 1, num_bytes_read, fout);
    }

    fclose(fin);
    fclose(fout);
}

int main() {
    struct stat file_stat;
    const char *file_path = "flag.txt.enc";

    // Retrieve file metadata
    if (stat(file_path, &file_stat) != 0) {
        perror("Could not retrieve file information");
        exit(1);
    }

    // Use the modification timestamp as the seed for srand
    time_t file_mod_time = file_stat.st_mtime;
    printf("Using file modification timestamp as srand seed: %ld\n", file_mod_time);

    // Generate 32 bytes for AES key
    unsigned char key[32];
    generate_random_bytes(key, 32, file_mod_time);

    // Generate 16 bytes for AES IV
    unsigned char iv[16];
    generate_random_bytes(iv, 16, file_mod_time);

    // Decrypt the file
    decrypt_file("flag.txt.enc", "decrypted_flag.txt", key, iv);

    printf("Decryption complete. Check decrypted_flag.txt\n");
    
    return 0;
}
