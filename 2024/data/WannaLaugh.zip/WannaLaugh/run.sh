docker load -i ransom-image.tar
docker run -it --name my-solution-container ransom-image /bin/bash
