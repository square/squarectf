#include "timer.h"
#include <time.h>

static int remaining_seconds = 0;

void calculate_time_difference() {
    time_t now = time(NULL);
    struct tm *target_time = localtime(&now);
    target_time->tm_mday += 7;  // Set target time 1 week ahead
    time_t target = mktime(target_time);
    remaining_seconds = difftime(target, now);
}

gboolean update_timer(gpointer data) {
    GtkWidget *time_label = (GtkWidget *)data;
    if (remaining_seconds <= 0) {
        // Time is up, stop the timer
        gtk_label_set_text(GTK_LABEL(time_label), "Time left:\n00:00:00");
        return FALSE; // Stop the timer
    }

    // Calculate hours, minutes, and seconds
    int hours = remaining_seconds / 3600;
    int minutes = (remaining_seconds % 3600) / 60;
    int seconds = remaining_seconds % 60;

    // Update the label with the current time
    char buffer[64];
    snprintf(buffer, sizeof(buffer), "Time left:\n%02d:%02d:%02d", hours, minutes, seconds);
    gtk_label_set_text(GTK_LABEL(time_label), buffer);
  
    gtk_widget_queue_draw(time_label);  // Force redraw

    // Decrease the remaining seconds
    remaining_seconds--;

    return TRUE; // Keep the timer running
}

void start_timer(GtkWidget *window) {
    GtkWidget *time_label = g_object_get_data(G_OBJECT(window), "time_label");
    calculate_time_difference();
    g_timeout_add(1000, update_timer, time_label);  // Call update_timer every second
}
