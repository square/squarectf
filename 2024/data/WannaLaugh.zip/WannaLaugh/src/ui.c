#include "ui.h"
#include "timer.h"

GtkWidget* create_main_window() {
    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "WannaCry - Your files are encrypted!");
    gtk_window_set_default_size(GTK_WINDOW(window), 400, 200);
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
    gtk_container_set_border_width(GTK_CONTAINER(window), 10);

    GtkWidget *grid = gtk_grid_new();
    gtk_grid_set_column_homogeneous(GTK_GRID(grid), FALSE);
    gtk_container_add(GTK_CONTAINER(window), grid);

    // Sidebar for the timer, pay button, and exit button
    GtkWidget *sidebar = create_sidebar(window);  // Pass window to sidebar
    gtk_grid_attach(GTK_GRID(grid), sidebar, 0, 0, 1, 3);

    // Header label
    GtkWidget *header_label = gtk_label_new("Oops, your files have been encrypted!");
    gtk_widget_set_name(header_label, "header_label");  // Set the name for CSS styling
    gtk_grid_attach(GTK_GRID(grid), header_label, 1, 0, 1, 1);

    // Info label
    GtkWidget *info_label = gtk_label_new("What happened to my computer?\nYour important files are encrypted.");
  gtk_widget_set_name(info_label, "info_label");  // Set the name for CSS styling
    gtk_grid_attach(GTK_GRID(grid), info_label, 1, 1, 1, 2);

    // Apply CSS styling
    apply_css_styling();

    gtk_widget_show_all(window);

    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    return window;
}

GtkWidget* create_sidebar(GtkWidget *window) {
    GtkWidget *sidebar = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_container_set_border_width(GTK_CONTAINER(sidebar), 10);

    GtkWidget *time_label = gtk_label_new(
        "Time left:\n00:00:00"
    );
    gtk_widget_set_name(time_label, "time_label");  // Set a name for CSS styling
    gtk_box_pack_start(GTK_BOX(sidebar), time_label, TRUE, TRUE, 0);

    // Set the time_label to be retrievable from the window later
    g_object_set_data(G_OBJECT(window), "time_label", time_label);

    GtkWidget *pay_button = gtk_button_new_with_label("Pay Now");
    g_signal_connect(pay_button, "clicked", G_CALLBACK(show_error_dialog), NULL);
    gtk_box_pack_start(GTK_BOX(sidebar), pay_button, FALSE, FALSE, 0);

    GtkWidget *exit_button = gtk_button_new_with_label("Exit");
    g_signal_connect(exit_button, "clicked", G_CALLBACK(gtk_main_quit), NULL);
    gtk_box_pack_start(GTK_BOX(sidebar), exit_button, FALSE, FALSE, 0);

    return sidebar;
}

void apply_css_styling() {
    GtkCssProvider *cssProvider = gtk_css_provider_new();
    gtk_css_provider_load_from_data(cssProvider,
        "window { "
        "    background-color: darkred; "
        "} "
        "#header_label { "
        "    font-size: 20px; "
        "    color: yellow; "
        "    font-weight: bold; "
        "} "
        "#time_label { "
        "    font-size: 12px; "
        "    color: white; "
        "} "
        "label { "
        "    color: black; "
        "    font-size: 14px; "
        "} "
                                      "#info_label { "
        "    color: white; "  // Set info_label text color to white
        "} "
        ,
        -1, NULL);

    gtk_style_context_add_provider_for_screen(gdk_screen_get_default(),
                                              GTK_STYLE_PROVIDER(cssProvider),
                                              GTK_STYLE_PROVIDER_PRIORITY_USER);
}

// Add the definition of show_error_dialog
void show_error_dialog(GtkWidget *widget, gpointer data) {
    GtkWidget *dialog = gtk_message_dialog_new(NULL,
                                               GTK_DIALOG_DESTROY_WITH_PARENT,
                                               GTK_MESSAGE_ERROR,
                                               GTK_BUTTONS_OK,
                                               "Error: Payment could not be processed.");
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
}
