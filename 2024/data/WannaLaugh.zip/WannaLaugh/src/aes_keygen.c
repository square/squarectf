#include <stdio.h>  // For FILE, fopen, fseek, fread, fclose, perror
#include <stdlib.h> // For malloc, free
#include <string.h> // For memcpy
#include <time.h>   // For time(), srand, rand
#include <sys/stat.h> // For file statistics
#include <dirent.h>  // For directory handling
#include <openssl/aes.h>  // For AES encryption
#include <openssl/rand.h> // For generating random bytes

#include "aes_keygen.h"

void generate_random_bytes(unsigned char *key, int len) {
    srand((unsigned int)time(NULL));

    for (int i = 0; i < len; i++) {
        key[i] = rand() % 256;  // Generates random byte
    }
}

// Function to pad the data to make it a multiple of AES_BLOCK_SIZE (PKCS7 padding)
int pad_data(unsigned char *data, int data_len) {
    int pad_len = AES_BLOCK_SIZE - (data_len % AES_BLOCK_SIZE);
    for (int i = 0; i < pad_len; i++) {
        data[data_len + i] = pad_len;
    }
    return data_len + pad_len;
}

// Function to encrypt a file with AES and save as .enc
void encrypt_file(const char *input_file, const unsigned char *key, const unsigned char *iv) {
    // Open the input file
    FILE *in_file = fopen(input_file, "rb");
    if (!in_file) {
        perror("Error opening input file");
        return;
    }

    // Determine the file size
    fseek(in_file, 0, SEEK_END);
    long file_size = ftell(in_file);
    fseek(in_file, 0, SEEK_SET);

    // Allocate buffer for the file contents
    unsigned char *file_data = (unsigned char *)malloc(file_size + AES_BLOCK_SIZE);
    if (!file_data) {
        perror("Error allocating memory");
        fclose(in_file);
        return;
    }

    // Read the file contents
    fread(file_data, 1, file_size, in_file);
    fclose(in_file);

    // Pad the file data
    int padded_size = pad_data(file_data, file_size);

    // Encrypt the file data
    unsigned char *encrypted_data = (unsigned char *)malloc(padded_size);
    if (!encrypted_data) {
        perror("Error allocating memory for encrypted data");
        free(file_data);
        return;
    }

    // Create a copy of the IV to preserve the original
    unsigned char iv_copy[AES_BLOCK_SIZE];
    memcpy(iv_copy, iv, AES_BLOCK_SIZE);

    AES_KEY enc_key;
    AES_set_encrypt_key(key, AES_KEY_LENGTH * 8, &enc_key);  // 256-bit key
    AES_cbc_encrypt(file_data, encrypted_data, padded_size, &enc_key, (unsigned char *)iv_copy, AES_ENCRYPT);

    // Create the output file name with .enc extension
    char output_file[256];
    snprintf(output_file, sizeof(output_file), "%s.enc", input_file);

    // Write the encrypted data to the output file
    FILE *out_file = fopen(output_file, "wb");
    if (!out_file) {
        perror("Error opening output file");
        free(file_data);
        free(encrypted_data);
        return;
    }
    fwrite(encrypted_data, 1, padded_size, out_file);
    fclose(out_file);

    printf("Encrypted file created: %s\n", output_file);

    // Clean up
    free(file_data);
    free(encrypted_data);
}

// Function to find and encrypt all .txt files in the directory
void encrypt_txt_files_in_directory(const unsigned char *key, const unsigned char *iv) {
    DIR *dir;
    struct dirent *entry;
    struct stat file_stat;

    dir = opendir(".");
    if (!dir) {
        perror("Error opening directory");
        return;
    }

    // Iterate over all files in the directory
    while ((entry = readdir(dir)) != NULL) {
        // Check if the file is a regular file and has a .txt extension
        if (stat(entry->d_name, &file_stat) == 0 && S_ISREG(file_stat.st_mode)) {
            const char *file_ext = strrchr(entry->d_name, '.');
            if (file_ext && strcmp(file_ext, ".txt") == 0) {
                // Encrypt the .txt file
                encrypt_file(entry->d_name, key, iv);
            }
        }
    }

    closedir(dir);
}

