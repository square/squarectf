#ifndef UI_H
#define UI_H

#include <gtk/gtk.h>

GtkWidget* create_main_window();
GtkWidget* create_sidebar(GtkWidget *window);
void apply_css_styling();
void show_error_dialog(GtkWidget *widget, gpointer data);

#endif
