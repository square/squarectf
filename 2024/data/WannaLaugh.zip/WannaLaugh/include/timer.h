#ifndef TIMER_H
#define TIMER_H

#include <gtk/gtk.h>

void calculate_time_difference();
gboolean update_timer(gpointer data);
void start_timer(GtkWidget *window);

#endif
