# WannaLaugh

Grandpa downloaded a weird program on the Internet and now his files do not work. 
Knowing you're good with computers, he asked for your help.

The program is asking for Bitcoin to get his files back, but his wallet password was encrypted as well.

You will be provided a Docker image containing the mysterious program and the password to his wallet.

Note: 
The program will only encrypt .txt files in the same directory as the executable and won't delete any files so nothing bad should happen?

## Solution

The ransomware uses srand(TIME) to generate AES key and IV to encrypt files. 

File creation (encryption) time is provided, 
so participants need to write a script with the same srand value to regenerate the key and IV and apply the same ciphers found in the binary to decrypt the flag.

`./build.sh` to generate the docker image to distribute.

`./run.sh` to load and run the image.

`docker cp solution.c my-solution-container:/usr/local/src/` copy solution to Docker container.

`gcc -o solution solution.c -lssl -lcrypto` build solution.

`./solution` to decrypt the flag.

flag{D0nT_cRy_n0-M0re}

