#!/bin/bash

# Variables
IMAGE_NAME="ransom-image"
TAR_FILE="ransom-image.tar"
DOCKERFILE_PATH="Dockerfile"

# Step 1: Build the Docker image
echo "Building the Docker image..."
docker build -t $IMAGE_NAME -f $DOCKERFILE_PATH .
if [ $? -ne 0 ]; then
    echo "Failed to build Docker image!"
    exit 1
fi

echo "Docker image built successfully: $IMAGE_NAME"

# Step 2: Run the Docker container to test it
echo "Running the Docker container to verify it works..."
docker run --rm $IMAGE_NAME
if [ $? -ne 0 ]; then
    echo "Failed to run the Docker container!"
    exit 1
fi

echo "Docker container ran successfully!"

# Step 3: Save the Docker image to a .tar file for distribution
echo "Saving Docker image to $TAR_FILE..."
docker save -o $TAR_FILE $IMAGE_NAME
if [ $? -ne 0 ]; then
    echo "Failed to save the Docker image to a tar file!"
    exit 1
fi

echo "Docker image saved to $TAR_FILE successfully!"
