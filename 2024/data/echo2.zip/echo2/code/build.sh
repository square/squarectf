docker build --platform=linux/amd64 -t echo-builder .
docker run --rm -i -v $(pwd):/code echo-builder make -C /code
