#!/bin/sh
set -ex

# Copy the flag
jq -j .flag challenge.json > flag.txt

docker-compose up --build -d
