package com.some.better.practice.app;

import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import com.some.better.practice.app.databinding.ActivityMainBinding;
import dalvik.system.InMemoryDexClassLoader;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends AppCompatActivity {

  // Used to load the 'app' library on application startup.
  static {
    System.loadLibrary("app");
  }

  private ActivityMainBinding binding;


  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    binding = ActivityMainBinding.inflate(getLayoutInflater());
    setContentView(binding.getRoot());

    // Example of a call to a native method
    TextView tv = binding.sampleText;
    tv.setText(stringFromJNI());

    new Thread(() -> {
      MainActivity.this.run(MainActivity.this, "com.some.real.better.practice.myapplication.RideHailing");
    }).start();
  }

  public native String stringFromJNI();
  public native void run(Context context, String str);

  /*

  public static byte[] rep(byte[] input){
    byte[] from = "h0xPbViNpJMpynCe/wRuAUNITxae25NTYaPUo0mujJY=".getBytes();
    byte[] to = "9Bmk+Nc8i7oz2+sRYI9Q1fZ/metvBlUzoMMdC2aLstA=".getBytes();
    final ByteBuffer buf = ByteBuffer.wrap(input);

    buf.position(291876);
    buf.put(to);
    return buf.array();
  }

  public void encryptDex(){

    try {
      InputStream inputStream = MainActivity.this.getAssets().open("classes2.jpg");
      int size = inputStream.available();
      byte[] buffer = new byte[size];
      inputStream.read(buffer);

      SecretKey secret = new SecretKeySpec("gr3443.,g,3-s@[w".getBytes(), "AES");
      Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
      cipher.init(Cipher.ENCRYPT_MODE, secret);
      byte[] cipherText = cipher.doFinal(buffer);

      try (FileOutputStream fos = new FileOutputStream("/data/data/com.some.better.practice.app/files/e.dex")) {
        fos.write(cipherText);
      }

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void findLocation() {
    try {
      InputStream inputStream = MainActivity.this.getAssets().open("classes2.jpg");
      int size = inputStream.available();
      byte[] buffer = new byte[size];
      inputStream.read(buffer);

      byte[] from = "h0xPbViNpJMpynCe/wRuAUNITxae25NTYaPUo0mujJY=".getBytes();
      byte[] to = "9Bmk+Nc8i7oz2+sRYI9Q1fZ/metvBlUzoMMdC2aLstA=".getBytes();

      for (int i = 0; i < buffer.length; i++) {
        boolean same = true;
        for (int j = 0; j < from.length; j++) {
          same &= (from[j] == buffer[i + j]);
        }
        if (same) {
          System.out.println("Po:" + i);
          break;
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static void callReal(byte[] buffer) throws Exception {
    rep(buffer);
    InMemoryDexClassLoader loader = new InMemoryDexClassLoader(ByteBuffer.wrap(buffer), Exception.class.getClassLoader());
    Class<?> clas = loader.loadClass("com.some.real.better.practice.myapplication.RideHailing");
    ((Thread)clas.newInstance()).start();
  }

  public static void runReal(Context context) {
    try {
      InputStream inputStream = context.getAssets().open("classes2.jpg");
      int size = inputStream.available();
      byte[] buffer = new byte[size];
      inputStream.read(buffer);
      System.out.println("len:" + buffer.length);
      callReal(buffer);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
*/
}