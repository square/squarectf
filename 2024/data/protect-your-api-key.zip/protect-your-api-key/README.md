# Protect your API Key

## Point Value
100

## Challenge Description
Bob is creating an app in which he needs to include a particular SDK. To use the SDK, he applied for an API Key which needs to pass to the SDK in the runtime. Considering the Key is not free, Bob is trying multiple approaches to protect it.


## Description
There are two protections.
- The real code is encrypted. It will be decrypted and loaded at runtime.
- The key is in cipher-text. It will be decrypted before use. 

No matter what approaches have been applied. The key eventually needs to pass to the SDK. So the player needs to find the function in the SDK that takes the key as a parameter. Then hook it at runtime to dump the key.
##### Step 1: Find the package name of the SDK
Monitoring the apps' log in `logcat`, the player can see the following information:
```
10-23 10:15:16.547 11283 11335 V com.some.map.sdk.Navigator: Your location is Location[ 43.000000,67.000000 et=0]
```
It indicates that the SDK's package name is `com.some.map.sdk`

##### Step 2: Find the function that takes the key as parameter.
Frida can be used to list all the classes/functions in the package:
```javascript
function findClass(){
    Java.enumerateLoadedClassesSync().map(function (cname) {
        if (cname.includes('com.some.map.sdk')) {
            console.log(cname)
        }
    });
}

setTimeout(function(){
    Java.perform(function(){
        findClass();
    });
}, 1000);
```
Several classes will be logged. Among them the one with name `com.some.map.sdk.Entry` indicates its the entry point of the SDK. Then let's list its functions
```javascript
function findFunction(){
    let classLoaders = Java.enumerateClassLoadersSync()
    for (let i = 0; i < classLoaders.length; i++) {
        let classLoader = classLoaders[i]
        Java.classFactory.loader = classLoader

        try{
            var theClass = Java.use("com.some.map.sdk.Entry");
            var methods = theClass.class.getMethods();
            for(var m in methods)
            {
                console.log(methods[m]);
            }
        }catch (e) {
        }
    }
}

setTimeout(function(){
    Java.perform(function(){
        findFunction();
    });
}, 1000);
```
Then there is a function `com.some.map.sdk.Entry.initialization(java.lang.String)` which obvious is what we are looking for. 
##### Step 3: Hook and dump the key.
```javascript
function dumpApiKey(){
    if(true){
        let classLoaders = Java.enumerateClassLoadersSync()
        for (let i = 0; i < classLoaders.length; i++) {
            let classLoader = classLoaders[i]
            Java.classFactory.loader = classLoader
            try {
                var theClass = Java.use("com.some.map.sdk.Entry");
                theClass.initialization.overload("java.lang.String").implementation = function(apikey) {
                    console.log(apikey);
                }
                return;
            }catch (e) {
            }
        }
    }
}

setTimeout(function(){
    Java.perform(function(){
        dumpApiKey();
    });
}, 1000);
```
Please note that the above code all wait for 1 second first to make sure the target code got loaded. Another solution would be that the player can try to RE the logic of dynamic loading `.dex` to dump the real code.
## Deployment
players just need access to app.apk