package com.some.map.sdk;

import android.location.Location;

public class Entry {
  public Navigator initialization(String apiKey){
    Location targetLocation = new Location(apiKey);
    targetLocation.setLatitude(43.0d);
    targetLocation.setLongitude(67.0d);
    return getNavigator();
  }

  private Navigator getNavigator(){
    return Navigator.getInstance();
  }
}
