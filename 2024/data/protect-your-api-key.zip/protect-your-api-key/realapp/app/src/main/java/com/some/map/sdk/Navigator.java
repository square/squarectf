package com.some.map.sdk;

import android.location.Location;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class Navigator {

  public static Navigator getInstance(){
    return new Navigator();
  }

  private Navigator() {
    super();
  }

  public Location locate(){
    Location targetLocation = new Location("");
    targetLocation.setLatitude(43.0d);
    targetLocation.setLongitude(67.0d);

    return targetLocation;
  }

  @Override public int hashCode() {
    return super.hashCode();
  }

  @Override public boolean equals(@Nullable Object obj) {
    return super.equals(obj);
  }

  @NonNull @Override protected Object clone() throws CloneNotSupportedException {
    return super.clone();
  }

  @NonNull @Override public String toString() {
    return super.toString();
  }

  @Override protected void finalize() throws Throwable {
    super.finalize();
  }
}
