package com.some.real.better.practice.myapplication;

import android.location.Location;
import android.util.Base64;
import android.util.Log;
import com.some.map.sdk.Navigator;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class RideHailing extends Thread {
  private void logLocation(Navigator navigator){
    Location location= navigator.locate();
    Log.v(Navigator.class.getName(), "Your location is " + location);
  }

  public void start(){
    String api_key;
    try {
      byte[] data = Base64.decode("9Bmk+Nc8i7oz2+sRYI9Q1fZ/metvBlUzoMMdC2aLstA=", Base64.NO_WRAP);
      api_key = RideHailing.decryptMsg(data);
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
    Navigator navigator = new com.some.map.sdk.Entry().initialization(api_key);
    logLocation(navigator);
  }


  public static byte[] encryptMsg(String message) throws Exception
  {
    SecretKey secret = new SecretKeySpec("er34rgr3443.,g,3-09gjs@[wpef9j3j".getBytes(), "AES");
    Cipher cipher = null;
    cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
    cipher.init(Cipher.ENCRYPT_MODE, secret);
    byte[] cipherText = cipher.doFinal(message.getBytes("UTF-8"));
    return cipherText;
  }

  public static String decryptMsg(byte[] cipherText) throws Exception
  {
    SecretKey secret = new SecretKeySpec("er34rgr3443.,g,3-09gjs@[wpef9j3j".getBytes(), "AES");
    Cipher cipher = null;
    cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
    cipher.init(Cipher.DECRYPT_MODE, secret);
    String decryptString = new String(cipher.doFinal(cipherText), "UTF-8");
    return decryptString;
  }
}
