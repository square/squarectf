## Where's My Key?

### Overview
The server is set up to send an encrypted flag to the client via an
[ECIES](https://en.wikipedia.org/wiki/Integrated_Encryption_Scheme)-like system with
[X25519](https://cr.yp.to/ecdh.html) and AES-256-CTR. The AES key is generated using a random server key and a
client-provided public key. With X25519, each side derives the shared secret using  their own private key and the
"other's" public key.

The client connects, sends its public key to the server, and the server responds with the encrypted flag.

However, the server "forgets" to send its public key, which means the client can't generate the shared secret and
decrypt the flag. What do?

### The Solution
X25519 is pretty safe to use in general. But like all curves, users must be aware of bad values. For X25519, the
"bad value" is a zero'd public key. The result of `curve25519(my_secret, their_public)` when the public key is zero is
always zero.

Note that the `cryptography` python library (or perhaps the underlying openssl library) will correctly throw an
exception if we give it an all-zero public key (or perhaps if the result is zero). The server uses a different,
pure-python library that lacks such checks.

The solution to the challenge is to send an all-zero public key. The server then generate an all-zero AES key, which
makes decrypting the flag trivial at that point.
