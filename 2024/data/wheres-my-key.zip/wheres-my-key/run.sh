#!/bin/sh
set -ex

# Copy the flag
echo "FLAG=\"$(jq -r .flag challenge.json)\"" > flag.env

docker-compose up --build -d
