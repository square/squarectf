import socket
import sys
import json

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes


def hack_the_planet(host: str, port: int):
    """Solve the wheres-my-key challenge.

    The solution is to send an all-zero public key. The server then generate an all-zero AES key, which lets us decrypt
    the flag with ease.
    """
    all_zeros = b'\x00' * 32

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))

    s.sendall(json.dumps({"client_pub": all_zeros.hex()}).encode())
    data = json.loads(s.recv(1024))

    iv = bytes.fromhex(data["iv"])
    ct = bytes.fromhex(data["ct"])

    cipher = Cipher(algorithms.AES(all_zeros), modes.CTR(iv))
    decryptor = cipher.decryptor()
    flag = decryptor.update(ct) + decryptor.finalize()

    return flag.decode()


if __name__ == "__main__":
    print(hack_the_planet(sys.argv[1], int(sys.argv[2])))
