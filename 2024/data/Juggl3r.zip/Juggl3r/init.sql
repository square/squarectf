CREATE DATABASE IF NOT EXISTS ctf_challenge;
USE ctf_challenge;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(100) NOT NULL
);

CREATE TABLE flags (
  id INT AUTO_INCREMENT PRIMARY KEY,
  flag VARCHAR(100) NOT NULL
);

CREATE TABLE login_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45),  -- to store IPv4/IPv6
    attempt_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert the users
INSERT INTO users (username, password) VALUES
('admin', '0e66298694359207596086558843543959518835691168370379069085300385'),
('user', 'acfd808ff32cbc72e65ea0a09f928a3af046d75dde4bca5343807c2b160d6515');

-- Insert the flag from file using LOAD_FILE()
INSERT INTO flags (flag) VALUES (LOAD_FILE('/var/lib/mysql-files/flag.txt'));
