<?php
// admin.php

session_start();
require_once 'config.php';

if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'admin') {
    header("Location: login.php");
    exit();
}

if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    $sql = "SELECT * FROM users WHERE id = $user_id";
    $stmt = $conn->query($sql);

    if ($stmt && $user = $stmt->fetch()) {
        $message = "User found: " . htmlspecialchars($user['username']);
    } else {
        $message = "User not found.";
    }
} else {
    $message = "Please provide a user ID.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="styles.css" rel="stylesheet"> <!-- Custom Styles -->
</head>
<body class="bg-light">

<div class="container my-5">
    <div class="card shadow p-4">
        <h2 class="text-center mb-4">Admin Panel</h2>
        <p class="text-center"><?php echo htmlspecialchars($message); ?></p>
        <a href="login.php" class="btn btn-danger d-block mx-auto" style="max-width: 200px;">Logout</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

