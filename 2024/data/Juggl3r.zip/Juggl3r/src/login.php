<?php
session_start();
require_once 'config.php';

// Configure rate limiting settings
$max_attempts = 5;      // Maximum login attempts allowed
$block_time = 300;      // Block time in seconds (5 minutes)
$ip_address = $_SERVER['REMOTE_ADDR'];  // Get the user's IP address

// Check if the user has exceeded the maximum number of attempts
$stmt = $conn->prepare("SELECT COUNT(*) FROM login_attempts WHERE ip_address = ? AND attempt_time > NOW() - INTERVAL ? SECOND");
$stmt->execute([$ip_address, $block_time]);
$attempt_count = $stmt->fetchColumn();

if ($attempt_count >= $max_attempts) {
    die("Too many login attempts. Please try again after 5 minutes.");
}

// Initialize an error message variable
$error_message = '';

// Process the login form
if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prepare and execute the query to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Stored password hash
        $stored_hash = $user['password'];

        if ($stored_hash == hash("sha256", $password)) {
            // Authentication successful
            $_SESSION['username'] = $username;

            // Reset login attempts on successful login
            $stmt = $conn->prepare("DELETE FROM login_attempts WHERE ip_address = ?");
            $stmt->execute([$ip_address]);

            // Redirect to admin.php with an example user_id
            header("Location: admin.php?user_id=1");
            exit();
        } else {
            $error_message = "Invalid password.";
        }
    } else {
        $error_message = "User not found.";
    }

    // Log the failed login attempt
    $stmt = $conn->prepare("INSERT INTO login_attempts (ip_address) VALUES (?)");
    $stmt->execute([$ip_address]);

    // Check if the user has now exceeded the limit
    $stmt = $conn->prepare("SELECT COUNT(*) FROM login_attempts WHERE ip_address = ? AND attempt_time > NOW() - INTERVAL ? SECOND");
    $stmt->execute([$ip_address, $block_time]);
    $attempt_count = $stmt->fetchColumn();

    if ($attempt_count >= $max_attempts) {
        $error_message = "Too many login attempts. Please try again after 5 minutes.";
    }
}
?>

<!-- HTML Login Form -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="styles.css" rel="stylesheet"> <!-- Custom Styles -->
</head>
<body class="bg-light">

<div class="container d-flex justify-content-center align-items-center vh-100">
    <div class="card shadow-lg p-4" style="width: 100%; max-width: 400px;">
        <h3 class="text-center mb-4">Login</h3>

        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Login</button>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
