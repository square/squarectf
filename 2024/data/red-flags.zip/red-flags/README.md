## Description
I made a video game, its really hard!
## solution
There are 8 visible flags in the game, and 2 more are hidden off screen (8 visible flags is an intentional bait for the lazy - 256 possibilities can be brute forced by hand but ultimately you need to set both of the hidden flags to get the flag). One of two hidden flags is unreachable.
Touching a flag wil flip its boolean state between true and false. The state of all 10 flags is concatenated to a string of 0s and 1s which is then sha'd and md5'd.
Each character of the flag has a physical position which is offset based off of the bytes in the concatenated sha1+md5 string.
setting flags 0, 1, 4, 5, 6, and 8 to red should result in a sha1 + md5 of A9D35E62B9B41D03AF9C9A9120550C943D33050681F988DDE503E64ECD34DCE35ACE0B4B which will correctly order the flag in the sky.
Once you know whats going on you should be able to write a quick script to brute force the correct flag state, then either flip the unreachable flags in a debugger or just calculate where they're supposed to be

## points
250

## flag
flag{now_wishlist_me_on_steam}