# An Elf on a Shelf
This is a layered reverse engineering challenge. The challenge starts with a simple AI-generated PNG of a festive elf,
sitting on a shelf, and looking into a mirror. The mirror contains a square block that has seemingly random pixels in
them. These pixels are in fact another embedded "elf" file (mirrored), which must be reverse engineered to continue.

tl;dr... what do you get when a magic elf looks into a mirror? An executable Linux ELF file, and that ELF file, when
run, will encrypt and overlay a given flag on top of a wrapped present in the same PNG image... ...obviously...

This challenge involves:
* Image file manipulation (ImageMagick)
* Binary analysis (objdump, Ghidra)
* Some scripting to decode/decrypt the flag

## ELF Extraction
The first major challenge is to figure out what this square block of pixels is. Since it's in a PNG format, we cannot
analyze the compressed data directly, but must convert to raw RGB. Starting with an incorrect, partial extraction that
is somewhat corrupt should reveal that the extracted file is a binary application of some sort. E.g.:
```
magick elf.png -crop 120x120+215+215 extracted.rgb
```

Shows data like:
```
...
00000150: 0000 0000 0000 0100 0001 0000 4602 0146  ............F..F
00000160: 0201 7f45 4c7f 454c 0000 0000 0000 0000  ...EL.EL........
...
00000710: 316f 2e31 342e 7334 2e73 6368 3663 6836  1o.14.s4.sch6ch6
00000720: 6161 7261 6172 736c 2d73 6c2d 2d6d 752d  aaraarsl-sl--mu-
00000730: 6d75 2f6c 642f 6c64 6c69 626c 6962 0000  mu/ld/ldliblib..
...
```

Inspection should show that the pixels are doubled in size and mirrored (flipped vertically). These pixels must be
down-sampled properly using a technique that does not attempt to blend any colors. ImageMagick's `-sample` method should
be used in combination with un-mirroring (flopping) the image:
```
magick elf.png -crop 120x120+215+215 -flop -sample 50% extracted.rgb
```

Using naive `-scale` may also work, but `-resize` will average neighboring pixels and corrupt data. The problem solver
will have to know or learn a bit about image processing to be successful here (or just get lucky).

## Reversing
Once properly extracted, the binary can be analyzed in standard tools. Optimization is turned off and basic symbols (not
debug info) have been left in intentionally to aid in the RE process. Ghidra decompiles it pretty nicely:

```
void main(void)
{
  undefined auStack_20 [32];
  
  memset(auStack_20,0,0x20);
  read(0,auStack_20,0x20);
  mask_flag(auStack_20);
  write_flag(auStack_20);
  return;
}

```

This shows that there is a 32-byte flag read from stdin. It is masked, then written.

### mask\_flag
Decompiled:
```
void mask_flag(long param_1)
{
  ulong local_8;
  
  for (local_8 = 0; local_8 < 0x20; local_8 = local_8 + 1) {
    *(undefined1 *)(param_1 + local_8) = (&SBOX)[(int)(uint)*(byte *)(param_1 + local_8)];
  }
  return;
}
```

This shows a loop over the 32-byte input. There is an `SBOX` being used as a substitution cipher.

### write\_flag
Decompiled:
```
undefined8 write_flag(undefined8 param_1)
{
  ...
  uVar3 = NewMagickWand();
  iVar2 = MagickReadImage(uVar3,"input.png");
  if (iVar2 == 0) {
    perror("image read");
    uVar3 = 1;
  }
  else {
    MagickGetImageWidth(uVar3);
    lVar4 = MagickGetImageHeight(uVar3);
    uVar5 = NewPixelWand();
    PixelSetGreen(0x3fae1e1e1e1e1e1e,uVar5);
    PixelSetBlue(0x3fae1e1e1e1e1e1e,uVar5);
    local_8 = 0;
    for (local_10 = 0; local_10 < 0x10; local_10 = local_10 + 1) {
      for (local_18 = 0; local_18 < 0x10; local_18 = local_18 + 1) {
        bVar1 = bit_of(param_1,local_8);
        PixelSetRed(((double)(uint)bVar1 + 150.0) / 255.0,uVar5);
        MagickSetImagePixelColor(uVar3,local_18 + 0x40,lVar4 + -0x40 + local_10,uVar5);
        local_8 = local_8 + 1;
      }
    }
    iVar2 = MagickWriteImage(uVar3,"elf.png");
    if (iVar2 == 0) {
      perror("image write");
      uVar3 = 1;
    }
    ...
  }
  return uVar3;
}
```

This shows that the masked flag is written into a PNG file. The `input.png` file is read, updated, then written to
`elf.png`.

Analyzing the loop shows that the flag is written to a square area of the image. Each bit of the masked flag is
extracted (`bit_of()`), then written to the red pixel as the normalized value of 150 + flag bit.

It's always challenging to get the X/Y ordering right, but this loop was written to be straight forward to aid in easy
extraction later.

Important to note that discovering the red box in the picture + encoding mechanism alone won't be enough for this
challenge. The `SBOX` must be extracted successfully from the ELF file as well.


## Flag Recovery

### Extraction
ImageMagick again can be used to extract the encoded flag easily:
```
magick elf.png -crop 16x16+64+960 flag.rgb
```

No scaling, flipping, or flopping is occurring here, so it's fairly straight forward. The encoded flag is a red box over
a present in the lower-left of the image, which is easily visible to the eye, but does not stand out like the ELF file.

### "Decryption"
The `SBOX` from `mask_flag()` is required. Luckily, it's the first 256-bytes of the `.rodata` section of the ELF file,
which can be recovered easily using various tooling. For example
```
objcopy -O binary --only-section=.rodata extracted.rgb rodata.bin
head -c 256 rodata.bin > sbox.bin 
```

Manually grabbing these 256-bytes via Ghidra is also straight forward.

Substitution boxes are trivial to invert, e.g.:
```python
import pathlib

def invert(sbox: bytes) -> list[int]:
    invsbox = [0] * 256
    for value, b in enumerate(sbox):
        invsbox[b] = value
    return invsbox

inv_sbox = invert(pathlib.Path("sbox.bin").read_bytes())
```

The raw `flag.rgb` data must be read and analyzed. The flag is encoded in the red pixels (`PixelSetRed()`). As the data
is RGB, every 3rd byte must be analyzed.

Inspecting the decompiled code reveals this, as well as looking at the raw RGB data:
```
$ xxd flag.rgb
00000000: 960f 0f97 0f0f 960f 0f97 0f0f 960f 0f96  ................
00000010: 0f0f 960f 0f97 0f0f 970f 0f97 0f0f 960f  ................
00000020: 0f97 0f0f 960f 0f97 0f0f 960f 0f97 0f0f  ................
00000030: 960f 0f97 0f0f 970f 0f96 0f0f 970f 0f96  ................
00000040: 0f0f 960f 0f96 0f0f 970f 0f97 0f0f 970f  ................
...
```

Decoding it in Python:
```python
import itertools
import pathlib

def decode_rgb(raw_rgb: bytes) -> bytes:
    BASE_VALUE = 150
    bits = "0b"
    for red_pixel in itertools.islice(raw_rgb, 0, None, 3):
        if red_pixel == BASE_VALUE:
            bits += "0"
        elif red_pixel == BASE_VALUE + 1:
            bits += "1"
        else:
            raise RuntimeError(f"Can't determine flag bit based on {red_pixel}")
    flag_len = len(raw_rgb) // 8 // 3
    return int(bits, 0).to_bytes(flag_len, 'big')

decoded_flag = decode_rgb(pathlib.Path("flag.rgb").read_bytes())
```

Which still looks like random data at this point:
```
>>> decoded_flag
b'Q\xd5h\xfc...'
>>> decoded_flag.hex()
'51d568fca...'
```

Lastly, we run the result through the inverse SBOX:
```python
"".join(chr(inv_sbox[b]) for b in decoded_flag)
```

Which gives:
```
flag{magick_mirr0r__m4gick_elf}
```
