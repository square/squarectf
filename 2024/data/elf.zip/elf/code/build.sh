docker build --platform linux/arm64 -t alpine-builder .
docker run --rm -i -v $(pwd):/code alpine-builder make -C /code
