set -ex

pushd code
make clean
./build.sh
popd

pushd image
./build.sh
popd
