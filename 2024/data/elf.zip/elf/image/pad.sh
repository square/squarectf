set -ex

# Size of our ELF file
file_size=$(wc -c $1 | sed -e 's/ *\([0-9]*\) .*/\1/')

# Figure out the dimensions of a square that can contain the elf, rounded up to the nearest 10
xy_dim=$(echo "scale=0; (sqrt(${file_size}/3)+9)/10 * 10" | bc)
total_size=$(echo "${xy_dim}*${xy_dim}*3" | bc)

# Pad the file
diff=$(( $total_size-$file_size ))
head -c $diff /dev/zero > zeros
cat $1 zeros > $1.rgb

# Mirror the image
magick -size ${xy_dim}x${xy_dim}x3 -depth 8 $1.rgb -flop -sample 200% $1.png

# Ensure our resulting image lost no information
magick $1.png -flop -sample 50% recreated.rgb
diff -q recreated.rgb $1.rgb

rm zeros $1.rgb recreated.rgb
