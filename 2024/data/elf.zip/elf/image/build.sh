set -ex

# Stage inputs
cp ../code/main ./elf-file
cp base.png input.png
chmod 644 input.png

# Embed the ELF
./pad.sh elf-file  # Creates elf-file.png
magick \
    \( -page 1024x1024+0 input.png -background black \) \
    \( -page +215+215 elf-file.png \) \
    -layers flatten \
    output.png

# Output from one is the input to the other
mv output.png input.png

# Embed the flag (writes to elf.png)
jq -r .flag ../challenge.json | docker run --rm -i -v $(pwd):/code -w /code --platform linux/arm64 alpine-builder ./elf-file

rm elf-file elf-file.png input.png
