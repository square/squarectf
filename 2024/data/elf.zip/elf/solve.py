import itertools
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile

CHALLENGE_ROOT = pathlib.Path(__file__).parent


def call(command):
    print(f"Calling: {command}")
    subprocess.check_call(command.split(" "))


def invert(sbox: bytes) -> list[int]:
    """Invert the SBOX used for 'encryption' so we can 'decrypt' the flag"""
    invsbox = [0] * 256
    for value, b in enumerate(sbox):
        invsbox[b] = value
    return invsbox


def decode_rgb(raw_rgb: bytes) -> bytes:
    """Extract each bit from the red channel (every 3rd byte)"""
    BASE_VALUE = 150
    bits = "0b"
    for red_pixel in itertools.islice(raw_rgb, 0, None, 3):
        if red_pixel == BASE_VALUE:
            bits += "0"
        elif red_pixel == BASE_VALUE + 1:
            bits += "1"
        else:
            raise RuntimeError(f"Can't determine flag bit based on {red_pixel}")

    flag_len = len(raw_rgb) // 8 // 3
    return int(bits, 0).to_bytes(flag_len, 'big')


def decrypt_flag(encoded_flag: bytes, inv_sbox: list[int]) -> str:
    """Run the flag data through the inverted sbox to 'decrypt'"""
    return "".join(chr(inv_sbox[b]) for b in encoded_flag)


def main(input_path):
    with tempfile.TemporaryDirectory() as tempdir:
        os.chdir(tempdir)
        print(f"Working in: {os.getcwd()}")
        shutil.copy(input_path, os.path.join(tempdir, "elf.png"))

        call(f"magick elf.png -crop 120x120+215+215 -flop -sample 50% extracted.rgb")
        call(f"magick elf.png -crop 16x16+64+960 flag.rgb")
        call("objcopy -O binary --only-section=.rodata extracted.rgb rodata.bin")

        sbox = pathlib.Path("rodata.bin").read_bytes()[:256]
        rgb_data = pathlib.Path("flag.rgb").read_bytes()

    print(f"Decrypting flag...")
    inv_sbox = invert(sbox)
    encrypted_flag = decode_rgb(rgb_data)
    flag = decrypt_flag(encrypted_flag, inv_sbox)

    print(flag)


if __name__ == "__main__":
    main(os.path.abspath(sys.argv[1]))
