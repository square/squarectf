#!/bin/bash

docker build . -t ihnsaims
docker run -d -p ${HOST_PORT}:8000 ihnsaims
