#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <syscall.h>
#include <sys/mman.h>
#include <sys/random.h>
#include <seccomp.h>


#include <string.h>

size_t HAYSTACK_SIZE =    0x100000000; 
void *HAYSTACK = (void *)  0x04200000;
size_t SHELLCODE_OFF =     0x00690000;

typedef void shellcode();


int main(int argc, char **argv)
{
    int chosen_syscall;
    char syscall_str[8];
    char shellcode_buf[4096];

    if (argc != 2) {
        printf("you gotta give me a flag dawg\n");
        exit(0);
    }
    printf("Hey there! I've got a flag here, and I'm gonna be hiding it somewhere out in the wide, wide, 64 bit memory space.\n");
    printf("I'm feeling generous this CTF, so I'll give you 1 whole syscall that you'll be allowed to use! Go ahead, pick a number!\n");
    
    read(STDIN_FILENO, syscall_str, sizeof(syscall_str) - 3);

    size_t rand_64bit;
    getrandom((void *)&rand_64bit, sizeof(size_t), 0); // its insane that libc does not have a 64 bit rand() implementation in 2024
    char *needle = HAYSTACK + (rand_64bit % HAYSTACK_SIZE);
    mmap(needle, 1, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    strcpy(needle, argv[1]);

    // wipe all references to needle and the argv flag
    memset(argv[1], 0, strlen(argv[1]));
    rand_64bit = 0;
    needle = 0;

    printf("Ok lets skip all that 'exploitation' business for this one - give me some shellcode to execute!\n");
    
    // load up shellcode
    int bytes_read = read(STDIN_FILENO, shellcode_buf, sizeof(shellcode_buf));
    void *shellcode_ptr = mmap((void *) SHELLCODE_OFF, 1, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    memcpy(shellcode_ptr, shellcode_buf, bytes_read);

    // setup the seccomp filter
    scmp_filter_ctx ctx = seccomp_init(SCMP_ACT_KILL_PROCESS);

    // give exit() so the program can exit(0) and because why not
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(exit_group), 0);

    // user's chosen syscall
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, atoi(syscall_str), 0);

    printf("Good luck!\n");
    seccomp_load(ctx);
    seccomp_release(ctx);

    ((shellcode *)shellcode_ptr)();
}