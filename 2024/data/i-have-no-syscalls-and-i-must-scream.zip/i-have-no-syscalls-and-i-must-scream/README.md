# I Have No Syscalls And I Must Scream

## description
write(1, "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH", 64);

## Solution
this challenge asks you for a shellcode payload of up to 4kb, and also asks for you to pick a syscall number. 
The flag is passed into the program via argv, and copied into a random offset in a random page of memory somewhere between 0x04200000 and 0x424200000. All other references to the stack and the location of the memory page are zeroized out of memory.
All syscall numbers besides the one chosen and exit_group() are disabled via seccomp. Then the shellcode payload is mapped and called.
Players essentially have 1 syscall to use for both finding the flag and somehow exfiltrating it out of the process. My intended solution is to "spend" your 1 syscall on a readable memory oracle, such as access() or mincore(), and then write your shellcode to scan memory for the first readable page, then search that page for the flag. it should take less than half a second on average to locate the page, at which point you can use infinite loops to hang the process vs instantly crashing the process as a 1 bit oracle to slowly extract the flag, either via binary search or bitwise operations or whatever. You could also encode several bits in each request by varying the number of loops being executed if you wanted to be fancy.
There are likely other possible solutions, and this being a 64 bit process allows for the use of a 2nd syscall by switching the process to 32 bit execution mode.
