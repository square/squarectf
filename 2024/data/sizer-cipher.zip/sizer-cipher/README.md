## Sizer Cipher

### Overview
This challenge defines the following custom 6-bit ascii encoding:
```
'a' .. 'z' ---  0 .. 25
'A' .. 'Z' --- 26 .. 51
'0' .. '9' --- 52 .. 61
       '{' --- 62
       '}' --- 63
```

The flag is encoded and given in the challenge description. Users a given a server they can interact with where for a given input the server will return the encoded output. It should be fairly straightforward to try different combinations and uncover the mapping.
A helpful trick is remembering that the flag begins with `flag{` and confirming that this message encoded matches the start of the given ciphertext.


### The Solution

Just reverse the mapping. The main function in `sizer_cipher.py` has a solver commented out under the `# to decode message` comment
