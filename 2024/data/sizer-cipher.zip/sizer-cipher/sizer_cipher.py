import sys

encode_mapping = {
    'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4, 'f': 5, 'g': 6, 'h': 7, 'i': 8, 'j': 9, 'k': 10, 'l': 11, 'm': 12, 'n': 13, 'o': 14, 'p': 15, 'q': 16, 'r': 17, 's': 18, 't': 19, 'u': 20, 'v': 21, 'w': 22, 'x': 23, 'y': 24, 'z': 25,
    'A': 26, 'B': 27, 'C': 28, 'D': 29, 'E': 30, 'F': 31, 'G': 32, 'H': 33, 'I': 34, 'J': 35, 'K': 36, 'L': 37, 'M': 38, 'N': 39, 'O': 40, 'P': 41, 'Q': 42, 'R': 43, 'S': 44, 'T': 45, 'U': 46, 'V': 47, 'W': 48, 'X': 49, 'Y': 50, 'Z': 51,
    '0': 52, '1': 53, '2': 54, '3': 55, '4': 56, '5': 57, '6': 58, '7': 59, '8': 60, '9': 61,
    '{': 62, '}':63
}

decode_mapping = {v: k for k, v in encode_mapping.items()} 

def char_to_bits(char):
    if char not in encode_mapping:
        raise ValueError(f"Invalid character: {char}")
    return bin(encode_mapping[char])[2:].zfill(6)

def encode_string(string):
    encoded_str = ''.join([char_to_bits(char) for char in string])
    padding = 0
    if len(encoded_str) % 8 != 0:
        padding = 8 - len(encoded_str) % 8
    return encoded_str.zfill(len(encoded_str) + padding)

def bits_to_char(bits):
    return decode_mapping[int(bits, 2)]

def decode_string(encoded_str):
    # decoding is a little tricky because we don't know if a zfill of 6 at the start is padding or not
    # this approach will sometimes prepend an extra 'a'

    # first convert to encoded bits
    encoded_bits = ''.join([bin(int(encoded_str[i:i+2], 16))[2:].zfill(8) for i in range(0, len(encoded_str), 2)])

    start_idx = len(encoded_bits) % 6

    decoded_str = ''.join([bits_to_char(encoded_bits[i:i+6]) for i in range(start_idx, len(encoded_bits), 6)])
    return decoded_str

def binary_to_ascii(binary):
    return ''.join([hex(int(binary[i:i+8], 2))[2:].zfill(2) for i in range(0, len(binary), 8)])

def main():
    input_data = sys.stdin.readline(4096).rstrip()

    try:
        encoded_bits = encode_string(input_data)

        encoded = binary_to_ascii(encoded_bits)
        sys.stdout.write(encoded)
        # to decode message
        #sys.stdout.write(f"\n{decode_string(encoded)}\n")


    except ValueError as e:
        sys.stdout.write(f"{e}\n")
        sys.exit(1)

if __name__ == '__main__':
    main()
