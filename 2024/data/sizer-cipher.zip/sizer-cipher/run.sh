#!/bin/bash

docker build . -t sizer_cipher
docker run -d -p ${HOST_PORT}:8000 sizer_cipher