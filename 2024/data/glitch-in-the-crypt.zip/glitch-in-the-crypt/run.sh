#!/bin/sh
set -ex

# Copy the flag
echo "FLAG=\"$(jq -r .flag challenge.json)\"" > flag.env

#docker run -d -p ${HOST_PORT}:8000 glitch-in-the-crypt
docker-compose up --build -d
