import socket
import logging
from Crypto.Util.number import GCD, inverse, long_to_bytes

# Configure logging
logging.basicConfig(level=logging.DEBUG, format='%(message)s')
logger = logging.getLogger()

# RSA public parameters (ensure these match the server's values)
n = 30392456691103520456566703629789883376981975074658985351907533566054217142999128759248328829870869523368987496991637114688552687369186479700671810414151842146871044878391976165906497019158806633675101
e = 65537

# Server details
HOST = 'localhost'  # Change this to the server's IP address if needed
PORT = 8010         # Port number where the server is listening

def main():
    logger.info("Starting RSA Fault Attack Exploit Script")

    # Step 1: Generate a plaintext message
    plaintext = b'Test message for fault attack.'
    m = int.from_bytes(plaintext, byteorder='big')
    logger.debug(f"Plaintext message: {plaintext}")
    logger.debug(f"Plaintext as integer: {m}")

    # Ensure m < n
    assert m < n, "Plaintext integer m must be less than modulus n."

    # Step 2: Encrypt the plaintext
    c = pow(m, 65537, n)
    c_hex = hex(c)[2:]
    logger.debug(f"Ciphertext (int): {c}")
    logger.debug(f"Ciphertext (hex): {c_hex}")
    logger.debug(f"Modulus n: {n}")

    # Ensure c < n
    assert c < n, "Ciphertext c must be less than modulus n."

    # Step 3: Interact with the decryption oracle to get both correct and faulty decryptions
    correct_plaintext = None
    faulty_plaintext = None

    logger.info("Attempting to obtain correct and faulty plaintexts...")
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        s.settimeout(5)  # Set a timeout for socket operations
        try:
            # Receive welcome messages and initial prompt
            welcome_data = ''
            while True:
                data = s.recv(4096).decode()
                if not data:
                    break
                welcome_data += data
                if 'Send your ciphertext in hex format:' in data:
                    break
            logger.debug(f"Received welcome messages: {welcome_data}")

            # Loop to obtain both correct and faulty plaintexts
            attempt = 1
            while attempt <= 200 and (not correct_plaintext or not faulty_plaintext):
                logger.debug(f"Attempt {attempt}")

                # Send ciphertext when prompted
                s.sendall((c_hex + '\n').encode())
                logger.debug(f"Sent ciphertext: {c_hex}")

                # Receive response and next prompt
                response = ''
                while True:
                    data = s.recv(4096).decode()
                    if not data:
                        break
                    response += data
                    if 'Send your ciphertext in hex format:' in data:
                        break
                logger.debug(f"Received response: {response}")

                # Check for faulty decryption
                faulty = 'Note: Fault occurred during decryption.' in response

                # Extract decrypted message
                lines = response.strip().split('\n')
                decrypted_int = None
                for line in lines:
                    if 'Decrypted message (hex):' in line:
                        decrypted_hex = line.split(': ')[1]
                        decrypted_int = int(decrypted_hex, 16)
                        break

                if decrypted_int is not None:
                    if faulty and not faulty_plaintext:
                        faulty_plaintext = decrypted_int
                        logger.info(f"Faulty plaintext obtained on attempt {attempt}")
                        logger.debug(f"Faulty plaintext (int): {faulty_plaintext}")
                    elif not faulty and not correct_plaintext:
                        correct_plaintext = decrypted_int
                        logger.info(f"Correct plaintext obtained on attempt {attempt}")
                        logger.debug(f"Correct plaintext (int): {correct_plaintext}")
                else:
                    logger.error(f"Error in server response: {response}")

                attempt += 1

                # If we have both plaintexts, break the loop
                if correct_plaintext and faulty_plaintext:
                    break

            if not (correct_plaintext and faulty_plaintext):
                logger.error("Failed to obtain both correct and faulty plaintexts.")
                return

            # Step 4: Compute the difference s = (m - m') mod n
            s_val = (correct_plaintext - faulty_plaintext) % n
            logger.debug(f"Difference s = (correct - faulty) mod n: {s_val}")

            # Step 5: Compute gcd(s, n) to find q
            q = GCD(s_val, n)
            if q == 1 or q == n:
                logger.error("Failed to factor n using the obtained plaintexts.")
                return
            p = n // q
            logger.info("Successfully factored n.")
            logger.debug(f"Computed p: {p}")
            logger.debug(f"Computed q: {q}")

            # Verify that n = p * q
            assert p * q == n, "Failed to verify that n = p * q"
            logger.info("Verified that n = p * q")

            # Step 7: Compute the private exponent d
            phi = (p - 1) * (q - 1)
            d = inverse(65537, phi)
            logger.debug(f"Computed private exponent d: {d}")

            # Step 8: Get the encrypted flag
            # Send 'flag' command
            s.sendall(b'flag\n')
            logger.debug("Sent 'flag' command")

            # Receive response
            response = ''
            while True:
                data = s.recv(4096).decode()
                if not data:
                    break
                response += data
                if 'Send your ciphertext in hex format:' in data:
                    break
            logger.debug(f"Received response: {response}")
            lines = response.strip().split('\n')
            flag_ciphertext_hex = None
            for line in lines:
                if 'Encrypted flag (hex):' in line:
                    flag_ciphertext_hex = line.split(': ')[1]
                    break
            if flag_ciphertext_hex is None:
                logger.error("Failed to retrieve the encrypted flag.")
                return
            logger.info("Encrypted flag retrieved from server.")
            logger.debug(f"Encrypted flag (hex): {flag_ciphertext_hex}")

            # Step 9: Decrypt the encrypted flag
            flag_ciphertext = int(flag_ciphertext_hex, 16)
            decrypted_flag_int = pow(flag_ciphertext, d, n)

            # Convert integer to bytes using long_to_bytes()
            decrypted_flag_bytes = long_to_bytes(decrypted_flag_int)
            logger.debug(f"Decrypted flag bytes: {decrypted_flag_bytes}")

            # Decode the bytes to get the flag
            decrypted_flag = decrypted_flag_bytes.decode('utf-8')
            logger.info(f"Decrypted flag: {decrypted_flag}")

        except Exception as e:
            logger.error(f"An error occurred: {e}")
        finally:
            s.close()

if __name__ == '__main__':
    main()
