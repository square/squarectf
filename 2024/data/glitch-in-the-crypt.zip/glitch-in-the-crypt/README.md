# Glitch in the Crypt: Exploiting Faulty RSA Decryption

---

## Challenge Description

**Scenario:**

A high-security server, **SecureVault Inc.**, uses RSA encryption to protect sensitive data. The server utilizes a **1024-bit RSA key** and employs the **CRT optimization** during decryption to improve performance.

Due to a hardware fault, the server occasionally introduces errors during the decryption process. Specifically, the fault affects the computation of \( m_p = c^{d_p} \mod p \) during the CRT step, causing \( m_p \) to be incorrect, while \( m_q = c^{d_q} \mod q \) remains correct.

As an experienced cryptanalyst, you have managed to obtain access to the server's decryption service. Your goal is to exploit the faulty decryption results to recover the prime factors \( p \) and \( q \) of the RSA modulus \( n \), effectively breaking the encryption scheme and recovering the private key.

---

## Files Provided

1. **`server.py`** – The server script simulating the faulty RSA decryption oracle.
2. **`solution.py`** – The solution script that demonstrates how to exploit the fault and recover the private key.

---

## Background

### RSA Encryption and Decryption

RSA is an asymmetric cryptographic algorithm that relies on the mathematical properties of large prime numbers. The public key consists of a modulus \( n \) and a public exponent \( e \), while the private key consists of the modulus \( n \) and a private exponent \( d \).

- **Encryption:** \( c = m^e \mod n \)
- **Decryption:** \( m = c^d \mod n \)

### Chinese Remainder Theorem (CRT) Optimization

To improve the efficiency of RSA decryption, especially with large keys, implementations often use the CRT. Instead of computing \( m = c^d \mod n \) directly, the CRT allows us to compute:

1. \( m_p = c^{d_p} \mod p \), where \( d_p = d \mod (p - 1) \)
2. \( m_q = c^{d_q} \mod q \), where \( d_q = d \mod (q - 1) \)
3. Combine \( m_p \) and \( m_q \) to get \( m \) using the CRT.

This optimization reduces the computation time significantly.

### Fault Attacks and the Bellcore Attack

A fault attack exploits errors introduced during the cryptographic computation to retrieve secret information. The **Bellcore attack** targets RSA implementations that use CRT optimization. If a fault affects the computation of \( m_p \) but not \( m_q \), the incorrect decrypted message \( \tilde{m} \) can be used to factor the modulus \( n \).

---

## Solution Overview

Our goal is to recover the prime factors \( p \) and \( q \) of \( n \) by exploiting the faulty decryption results from the server. Here's an overview of the steps we'll follow:

1. **Encrypt a plaintext message** using the public key.
2. **Send the ciphertext to the decryption oracle** multiple times to obtain both correct and faulty plaintexts.
3. **Compute the difference** between the correct and faulty plaintexts.
4. **Calculate the greatest common divisor (GCD)** of the difference and \( n \) to find one of the prime factors.
5. **Recover the other prime factor** by dividing \( n \) by the found prime.
6. **Verify the factors** and compute the private exponent \( d \).
7. **Decrypt the ciphertext** using the recovered private key.
8. **Verify that the decrypted message** matches the original plaintext.

---

## Detailed Solution

### Prerequisites

- **Python 3.x**
- **`pycryptodome` library** (Install using `pip install pycryptodome`)

### Step 1: Generate a Plaintext Message

We'll start by choosing a plaintext message to encrypt. For this challenge, we'll use:

```plaintext
"Hello, RSA!"
```

**Code:**

```python
plaintext = b'Hello, RSA!'
m = int.from_bytes(plaintext, byteorder='big')
```

- We convert the plaintext string to bytes and then to an integer for encryption.

### Step 2: Encrypt the Plaintext Using the Public Key

The public key parameters are:

- **Modulus \( n \):**

  ```
  n = 30392456691103520456566703629789883376981975074658985351907533566054217142999128759248328829870869523368987496991637114688552687369186479700671810414151842146871044878391976165906497019158806633675101
  ```

- **Public Exponent \( e \):**

  ```
  e = 65537
  ```

**Code:**

```python
c = pow(m, e, n)
c_hex = hex(c)[2:]
```

- We compute the ciphertext \( c = m^e \mod n \).
- The ciphertext is converted to hexadecimal for interaction with the server script.

### Step 3: Interact with the Decryption Oracle

Our goal is to obtain both correct and faulty plaintexts for the same ciphertext.

**Code:**
Refer to `solution.py` for the entire code. This code basically does the following - 

1. **Encrypts a Message**: Generates a plaintext message and encrypts it using the public RSA key to produce a ciphertext.

2. **Collects Decryptions**: Sends the ciphertext to the server repeatedly to obtain both correct and faulty decrypted plaintexts.

3. **Recovers Private Key**: Computes the difference between the correct and faulty plaintexts, uses it to calculate a prime factor of the modulus, and derives the RSA private key.

4. **Decrypts the Flag**: Uses the recovered private key to decrypt the encrypted flag obtained from the server.

### Step 4: Compute the Difference Between the Plaintexts

We compute \( s = (m - \tilde{m}) \mod n \).

**Code:**

```python
s = (correct_plaintext - faulty_plaintext) % n
```

### Step 5: Compute the GCD to Find One of the Prime Factors

We compute \( q = \gcd(s, n) \).

**Code:**

```python
from Crypto.Util.number import GCD

q = GCD(s, n)
if q == 1 or q == n:
    print("Failed to factor n using the obtained plaintexts.")
    exit()
```

- If \( q \) is neither 1 nor \( n \), we have found a non-trivial factor of \( n \).

### Step 6: Recover the Other Prime Factor

We compute \( p = n / q \).

**Code:**

```python
p = n // q
print(f"Recovered primes:\np = {p}\nq = {q}")
```

### Step 7: Verify the Factors

We verify that \( p \times q = n \).

**Code:**

```python
assert p * q == n, "Failed to verify that n = p * q"
print("Verified that n = p * q")
```

### Step 8: Compute the Private Exponent

We compute \( \phi(n) = (p - 1)(q - 1) \) and \( d = e^{-1} \mod \phi(n) \).

**Code:**

```python
from Crypto.Util.number import inverse

phi = (p - 1) * (q - 1)
d = inverse(e, phi)
```

### Step 9: Decrypt the Ciphertext Using the Recovered Private Key

We decrypt the ciphertext using \( d \).

**Code:**

```python
decrypted_m = pow(c, d, n)
decrypted_message = long_to_bytes(decrypted_m)
```

- We convert the decrypted integer back to bytes to get the plaintext message.

### Step 10: Verify the Decrypted Message Matches the Original Plaintext

We check if the decrypted message matches the original plaintext.

**Code:**

```python
assert decrypted_message == plaintext, "Decrypted message does not match the original plaintext"
print("Successfully decrypted the message using the recovered private key.")
```

---

## Conclusion

In this challenge, we've successfully exploited a hardware fault in RSA decryption to recover the private key. By obtaining both correct and faulty plaintexts for the same ciphertext, we used the difference between them to compute the GCD with \( n \), revealing one of the prime factors.

This attack underscores the importance of implementing fault detection and mitigation strategies in cryptographic systems, especially when using optimizations like CRT that can introduce vulnerabilities if not handled carefully.

---

