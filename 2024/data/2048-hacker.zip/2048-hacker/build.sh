#!/bin/bash

g++ -std=c++11 2048-hacker-solvable.cpp -o 2048-hacker-solvable-deploy.out
g++ -std=c++11 2048-hacker-solvable.cpp -DDEBUG -o 2048-hacker-solvable-distr.out
