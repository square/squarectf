#include <iostream>
#include <cstdio>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <random>
#include <cstring>
#include <unistd.h>

#ifdef DEBUG
    const char* FLAG = "placeholder flag\n";
#else
    const char* FLAG = "flag{u_r_b3st_numb3r_0ne_f4st3st_2048_champi0n_0f_all_tim3}\n";
#endif

// Custom 12-bit signed integer class
class Signed12Bit {
    int16_t value;

public:
    Signed12Bit() : value(0) {}

    Signed12Bit(int v) {
        setValue(v);
    }

    // Set value with 12-bit signed overflow behavior
    void setValue(int v) {
        // Limit to 12 bits by taking the lower 12 bits
        v &= 0xFFF; // Mask to 12 bits (4095 max)

        // If the 12th bit is set (indicating a negative number in 12 bits)
        if (v & 0x800) { 
            // Convert to negative by extending the sign (two's complement)
            v |= ~0xFFF;
        }

        value = static_cast<int16_t>(v);
    }

    // Get value
    int getValue() const {
        return value;
    }

    // Overload assignment operator
    Signed12Bit& operator=(int v) {
        setValue(v);
        return *this;
    }

    // Overload addition operator with wrapping behavior
    Signed12Bit operator+(const Signed12Bit& other) const {
        Signed12Bit result;
        result.setValue(this->value + other.value);
        return result;
    }

    // Overload compound assignment operator with wrapping behavior
    Signed12Bit& operator+=(const Signed12Bit& other) {
        setValue(this->value + other.value);
        return *this;
    }

    // Output stream overload for printing the value
    friend std::ostream& operator<<(std::ostream& os, const Signed12Bit& obj) {
        os << obj.getValue();
        return os;
    }
};

// 2048 game implementation
class Game2048 {
    static const int SIZE = 4;
    Signed12Bit board[SIZE][SIZE];
    bool moved;

public:
    Game2048() {
        std::srand(std::time(nullptr));
        resetBoard();
    }

    // Reset board and add two initial tiles
    void resetBoard() {
        for (int i = 0; i < SIZE; ++i)
            for (int j = 0; j < SIZE; ++j)
                board[i][j] = 0;

        addRandomTile();
        addRandomTile();
    }

    // Print the current state of the board
    void printBoard() const {
        printf("\n");
        for (int i = 0; i < SIZE; ++i) {
            for (int j = 0; j < SIZE; ++j) {
                printf("%6d", board[i][j].getValue());
            }
            printf("\n");
        }
        printf("\n");
    }

    // Add a random tile (2 or 4) at a random empty position
    void addRandomTile() {
        std::vector<std::pair<int, int> > emptyCells;
        for (int i = 0; i < SIZE; ++i)
            for (int j = 0; j < SIZE; ++j)
                if (board[i][j].getValue() == 0)
                    emptyCells.push_back({i, j});

        if (!emptyCells.empty()) {
            int randomIndex = std::rand() % emptyCells.size();
            int value = (std::rand() % 10 == 0) ? 4 : 2;
            board[emptyCells[randomIndex].first][emptyCells[randomIndex].second] = value;
        }
    }

    // Move the board in a given direction
    void move(char direction) {
        moved = false;

        switch (direction) {
            case 'w': moveUp(); break;
            case 's': moveDown(); break;
            case 'a': moveLeft(); break;
            case 'd': moveRight(); break;
        }

        if (moved) {
            addRandomTile();
        }
    }

    bool canMove() const {
        // Check if any cell is zero or if any two adjacent cells are the same
        for (int i = 0; i < SIZE; ++i) {
            for (int j = 0; j < SIZE; ++j) {
                if (board[i][j].getValue() == 0)
                    return true;
                if (i < SIZE - 1 && board[i][j].getValue() == board[i + 1][j].getValue())
                    return true;
                if (j < SIZE - 1 && board[i][j].getValue() == board[i][j + 1].getValue())
                    return true;
            }
        }
        return false;
    }

    bool checkWin() const {
        // Check if any tile has the value 2048 (even though it's not possible with the 12-bit constraint)
        for (int i = 0; i < SIZE; ++i) {
            for (int j = 0; j < SIZE; ++j) {
                if (board[i][j].getValue() == 2048) {
                    return true;
                }
            }
        }
        return false;
    }

private:
    // Slide and merge logic for all directions
    void moveUp() {
        for (int j = 0; j < SIZE; ++j) {
            for (int i = 1; i < SIZE; ++i) {
                if (board[i][j].getValue() != 0) {
                    int k = i;
                    while (k > 0 && board[k - 1][j].getValue() == 0) {
                        board[k - 1][j] = board[k][j];
                        board[k][j] = 0;
                        k--;
                        moved = true;
                    }
                    if (k > 0 && board[k - 1][j].getValue() == board[k][j].getValue()) {
                        board[k - 1][j] += board[k][j];
                        board[k][j] = 0;
                        moved = true;
                    }
                }
            }
        }
    }

    void moveDown() {
        for (int j = 0; j < SIZE; ++j) {
            for (int i = SIZE - 2; i >= 0; --i) {
                if (board[i][j].getValue() != 0) {
                    int k = i;
                    while (k < SIZE - 1 && board[k + 1][j].getValue() == 0) {
                        board[k + 1][j] = board[k][j];
                        board[k][j] = 0;
                        k++;
                        moved = true;
                    }
                    if (k < SIZE - 1 && board[k + 1][j].getValue() == board[k][j].getValue()) {
                        board[k + 1][j] += board[k][j];
                        board[k][j] = 0;
                        moved = true;
                    }
                }
            }
        }
    }

    void moveLeft() {
        for (int i = 0; i < SIZE; ++i) {
            for (int j = 1; j < SIZE; ++j) {
                if (board[i][j].getValue() != 0) {
                    int k = j;
                    while (k > 0 && board[i][k - 1].getValue() == 0) {
                        board[i][k - 1] = board[i][k];
                        board[i][k] = 0;
                        k--;
                        moved = true;
                    }
                    if (k > 0 && board[i][k - 1].getValue() == board[i][k].getValue()) {
                        board[i][k - 1] += board[i][k];
                        board[i][k] = 0;
                        moved = true;
                    }
                }
            }
        }
    }

    void moveRight() {
        for (int i = 0; i < SIZE; ++i) {
            for (int j = SIZE - 2; j >= 0; --j) {
                if (board[i][j].getValue() != 0) {
                    int k = j;
                    while (k < SIZE - 1 && board[i][k + 1].getValue() == 0) {
                        board[i][k + 1] = board[i][k];
                        board[i][k] = 0;
                        k++;
                        moved = true;
                    }
                    if (k < SIZE - 1 && board[i][k + 1].getValue() == board[i][k].getValue()) {
                        board[i][k + 1] += board[i][k];
                        board[i][k] = 0;
                        moved = true;
                    }
                }
            }
        }
    }
};

int main() {
    setvbuf(stdout, NULL, _IONBF, 0);
    alarm(180);
    Game2048 mainGame;
    Game2048 backupGame = mainGame; // Store initial state as backup
    Game2048* game = &mainGame;
    char *commands = nullptr;  // Pointer for dynamic allocation
    size_t length = 0;

    while (true) {
        game->printBoard();

        if (game->checkWin()) {
            printf("Congratulations! You reached 2048 and won the game!\n");
            printf(FLAG);
            break;
        }

        if (!game->canMove()) {
            printf("Game Over! No more moves available.\n");
            break;
        }

        printf("Enter command(s) (w/a/s/d for movement, u to undo, q to quit): ");
        
        getline(&commands, &length, stdin);
        
        size_t commandLen = strlen(commands);
        if (commands[commandLen - 1] == '\n') {
            commands[commandLen - 1] = '\0';
        }

        bool validMoves = true;

        for (size_t i = 0; commands[i] != '\0'; i++) {
            if (commands[i] == 'q') {
                free(commands);
                return 0;
            }

            if (commands[i] == 'u') {
                // Swap game pointer to backup
                *game = backupGame;
                break;
            }

            if (commands[i] != 'w' && commands[i] != 'a' && commands[i] != 's' && commands[i] != 'd') {
                validMoves = false;
                break;
            }
        }

        if (validMoves) {
            backupGame = mainGame; // Backup state before moving
            for (size_t i = 0; commands[i] != '\0'; i++) {
                game->move(commands[i]);
            }
        } else if (commands[0] != 'u') {
            printf("Skipping turn. Invalid command\n", commands);
            printf(commands);
        }
    }

    free(commands);
    return 0;
}
