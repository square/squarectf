# 2048-hacker

This is the classic [2048 game](https://en.wikipedia.org/wiki/2048_(video_game)) that has been rigged by using a custom  12 bit signed integer implementation for the cells. They have an upper limit value of 2047 so a 2048 tile would wrap around to -2048 preventing winning.

But..the control input (wasd) has a simple format string bug if the user enters invalid controls. 
* It can be used to arbitrarily write the 2048 value in binary to any of the cell. This gives you the first flag. The board with all cells is on the stack, and the custom 12 bit int impl uses int16 as it's underlying type so the higher bits can be set appropriately to get a 2048 value. 
* It can also be used to get code exec which gives you the second flag stored in a file on the server.


### Exploit

#### First flag
```
%2048c%20$n
```

#### Second flag

because the input string is stored on heap not stack, you do not directly get the ability to put an address you may want to arbitrarily read/write to as a positional printf argument. you need to construct those addresses through indirection relying on stack_ptr->stack_ptr chains. annoyingly for players, aslr-on and different stack layouts between local and remote will also get in the way but definitely something that can be worked around

![Arbitrary R/W](ctf.png)