#!/bin/bash

docker build . -t 2048-hacker
docker run -d -p ${HOST_PORT}:8000 2048-hacker
