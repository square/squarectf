## Custom Keyboard

### Overview
This challenge is a keyboard firmware reverse engineering/crypto challenge. We implemented a crappy engima machine in [QMK](https://github.com/qmk/qmk_firmware) so that keypresses
from A-Z are transformed into an Engima-enciphered keypress instead. We share the compiled firmware binary and also share the encrypted flag. The firmware is flashable on a Keychron V1 and `FN + .` will toggle from normal Mac keymap to and from the Enigma one. Players need to RE the firmware to determine that it is Enigma and to figure out the Engima settings.

There are 3 rotors and a reflector. Only `A..Z` are encoded.

### The Solution

Intended solution steps:

1. RE the binary and find the string with reflector+rotor2+rotor1+rotor0
2. Find the function that encrypts each letter and understand what it's doing
3. Reimplement that function in python (even easier if you realize it's Enigma)
4. Brute force encrypt the flag prefix `FLAG{` over all possible rotor starting positions (26^3) until they find the one that matches the ciphertext
5. You now know the rotor starting positions and can find the flag

The actual rotor starting positions are `7-7-4` and the decrypted flag is `KKPJ{HVNQSVNQYWSKKOEDSNWUPIDSRVHYPAZLAFLX}`.
