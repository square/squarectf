/* Copyright 2021 @ Keychron (https://www.keychron.com)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include QMK_KEYBOARD_H

// clang-format off

enum layers{
    MAC_BASE,
    ENIGMA,
    MAC_FN,
};

enum planck_normal_keycodes {
    EN_TOGGLE = SAFE_RANGE,
    EN_A,
    EN_B,
    EN_C,
    EN_D,
    EN_E,
    EN_F,
    EN_G,
    EN_H,
    EN_I,
    EN_J,
    EN_K,
    EN_L,
    EN_M,
    EN_N,
    EN_O,
    EN_P,
    EN_Q,
    EN_R,
    EN_S,
    EN_T,
    EN_U,
    EN_V,
    EN_W,
    EN_X,
    EN_Y,
    EN_Z,
    EN_RESET,
    EN_DEBUG,
    EN_LEFT,
    EN_DOWN,
    EN_UP,
    EN_RGHT,
};

#define KC_TASK LGUI(KC_TAB)
#define KC_FLXP LGUI(KC_E)

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
    [MAC_BASE] = LAYOUT_ansi_82(
        KC_ESC,   KC_BRID,  KC_BRIU,  KC_NO,    KC_NO,    RGB_VAD,  RGB_VAI,  KC_MPRV,  KC_MPLY,  KC_MNXT,  KC_MUTE,  KC_VOLD,    KC_VOLU,  KC_DEL,             KC_INS,
        KC_GRV,   KC_1,     KC_2,     KC_3,     KC_4,     KC_5,     KC_6,     KC_7,     KC_8,     KC_9,     KC_0,     KC_MINS,    KC_EQL,   KC_BSPC,            KC_PGUP,
        KC_TAB,   KC_Q,     KC_W,     KC_E,     KC_R,     KC_T,     KC_Y,     KC_U,     KC_I,     KC_O,     KC_P,     KC_LBRC,    KC_RBRC,  KC_BSLS,            KC_PGDN,
        KC_CAPS,  KC_A,     KC_S,     KC_D,     KC_F,     KC_G,     KC_H,     KC_J,     KC_K,     KC_L,     KC_SCLN,  KC_QUOT,              KC_ENT,             KC_HOME,
        KC_LSFT,            KC_Z,     KC_X,     KC_C,     KC_V,     KC_B,     KC_N,     KC_M,     KC_COMM,  KC_DOT,   KC_SLSH,              KC_RSFT,  KC_UP,
        KC_LCTL,  KC_LOPT,  KC_LCMD,                                KC_SPC,                                 KC_RCMD,  MO(MAC_FN), KC_RCTL,  KC_LEFT,  KC_DOWN,  KC_RGHT),

    [ENIGMA] = LAYOUT_ansi_82(
        KC_ESC,   KC_BRID,  KC_BRIU,  KC_NO,    KC_NO,    RGB_VAD,  RGB_VAI,  KC_MPRV,  KC_MPLY,  KC_MNXT,  KC_MUTE,  KC_VOLD,    KC_VOLU,  KC_DEL,             KC_INS,
        KC_GRV,   KC_1,     KC_2,     KC_3,     KC_4,     KC_5,     KC_6,     KC_7,     KC_8,     KC_9,     KC_0,     KC_MINS,    KC_EQL,   KC_BSPC,            KC_PGUP,
        KC_TAB,   EN_Q,     EN_W,     EN_E,     EN_R,     EN_T,     EN_Y,     EN_U,     EN_I,     EN_O,     EN_P,     KC_LBRC,    KC_RBRC,  KC_BSLS,            KC_PGDN,
        KC_CAPS,  EN_A,     EN_S,     EN_D,     EN_F,     EN_G,     EN_H,     EN_J,     EN_K,     EN_L,     KC_SCLN,  KC_QUOT,              KC_ENT,             KC_HOME,
        KC_LSFT,            EN_Z,     EN_X,     EN_C,     EN_V,     EN_B,     EN_N,     EN_M,     KC_COMM,  KC_DOT,   KC_SLSH,              KC_RSFT,  KC_UP,
        KC_LCTL,  KC_LOPT,  KC_LCMD,                                KC_SPC,                                 KC_RCMD,  MO(MAC_FN), KC_RCTL,  KC_LEFT,  KC_DOWN,  KC_RGHT),

    [MAC_FN] = LAYOUT_ansi_82(
        _______,  KC_F1,    KC_F2,    KC_F3,    KC_F4,    KC_F5,    KC_F6,    KC_F7,    KC_F8,    KC_F9,    KC_F10,   KC_F11,     KC_F12,   _______,            _______,
        _______,  _______,  _______,  _______,  _______,  _______,  _______,  _______,  _______,  _______,  _______,  _______,    _______,  EN_RESET,            _______,
        RGB_TOG,  RGB_MOD,  RGB_VAI,  RGB_HUI,  RGB_SAI,  RGB_SPI,  _______,  _______,  _______,  _______,  _______,  _______,    _______,  _______,            _______,
        _______,  RGB_RMOD, RGB_VAD,  RGB_HUD,  RGB_SAD,  RGB_SPD,  _______,  _______,  _______,  _______,  _______,  _______,              _______,            _______,
        _______,            _______,  _______,  _______,  _______,  _______,  NK_TOGG,  _______,  _______,  EN_TOGGLE,  EN_DEBUG,              _______,  EN_UP,
        _______,  _______,  _______,                                _______,                                _______,  _______,    _______,  EN_LEFT,  EN_DOWN,  EN_RGHT),

};

#define NUM_ROTORS 3
#define NUM_ALPHA 26

// Rotor definitions in order from right to left. Generated using gen_wiring.py.
static const char rot[NUM_ROTORS][NUM_ALPHA] = {
    "YKNQXBMOVZPIAEJCSDLGRTUFWH",
    "ZXVALNTFMJQBCPYWURSOKDEHIG",
    "RETAIGBSJNUWYXZLPVKCDMQOFH"
};

// Reflector definition. Generated using gen_wiring.py.
static const char ref[NUM_ALPHA] = "YGQNVUBROLTJZDIWCHXKFEPSAM";

// Whether the Enigma layer is currently active.
static bool toggle = false;

// Current rotor positions.
static int8_t pos[NUM_ROTORS];

// Current rotor selection (for setting the positions).
static int8_t selection;

static void reset_settings(void) {
    pos[0] = 0;
    pos[1] = 0;
    pos[2] = 0;
    selection = 0;
}

static inline char digit_to_char(int digit) {
    return '0' + digit;
}

static void print_settings(void) {
    send_string("Positions: ");
    send_char(digit_to_char(pos[0]));
    send_string(" ");
    send_char(digit_to_char(pos[1]));
    send_string(" ");
    send_char(digit_to_char(pos[2]));
    send_string("\n");
    send_string("Selection: ");
    send_char(digit_to_char(selection));
    send_string("\n");
}

__attribute__((always_inline)) static inline void apply_rotor(const char *rotor, int position, char *letter) {
    *letter = rotor[(*letter - 'A' + position) % NUM_ALPHA];
}

__attribute__((always_inline)) static inline void apply_reverse_rotor(const char *rotor, int position, char *letter) {
    for (int i = 0; i < NUM_ALPHA; i++) {
        if (rotor[i] == *letter) {
            *letter = 'A' + (i - position + NUM_ALPHA) % NUM_ALPHA;
            return;
        }
    }
}

__attribute__((always_inline)) static inline void apply_reflector(char *letter) {
    *letter = ref[*letter - 'A'];
}

__attribute__((always_inline)) static inline void step_rotor_positions(void) {
    // Rotate the rightmost rotor after every keypress.
    pos[0] = (pos[0] + 1) % NUM_ALPHA;

    // Simulate stepping of the middle rotor after the right rotor completes a full rotation.
    if (pos[0] == 0) {
        pos[1] = (pos[1] + 1) % NUM_ALPHA;
    }

    // Simulate stepping of the left rotor after the middle rotor completes a full rotation.
    if (pos[1] == 0 && pos[0] == 0) {
        pos[2] = (pos[2] + 1) % NUM_ALPHA;
    }
}

static void handle_letter_pressed(char *letter) {
    // Pass through the rotors from right to left.
    apply_rotor(rot[0], pos[0], letter);
    apply_rotor(rot[1], pos[1], letter);
    apply_rotor(rot[2], pos[2], letter);

    // Reflect the signal.
    apply_reflector(letter);

    // Pass through the rotors from left to right (reverse order).
    apply_reverse_rotor(rot[2], pos[2], letter);
    apply_reverse_rotor(rot[1], pos[1], letter);
    apply_reverse_rotor(rot[0], pos[0], letter);

    // Simulate stepping the rotors after every keypress.
    step_rotor_positions();
}

static void set_layer(uint8_t default_layer) {
    default_layer_set((layer_state_t)1 << default_layer);
}

void keyboard_pre_init_user(void) {
    reset_settings();
}

bool process_record_user(uint16_t keycode, keyrecord_t *record) {
    uint8_t letter_index;
    bool letter_found = false;
    if (record->event.pressed) {
        switch (keycode) {
            case EN_TOGGLE:
                toggle = !toggle;
                if (toggle) {
                    set_layer(ENIGMA);
                } else {
                    set_layer(MAC_BASE);
                }
                break;
            case EN_DEBUG:
                print_settings();
                break;
            case EN_LEFT:
                selection = (selection - 1) % NUM_ROTORS;
                break;
            case EN_RGHT:
                selection = (selection + 1) % NUM_ROTORS;
                break;
            case EN_UP:
                pos[selection] = (pos[selection] + 1) % NUM_ALPHA;
                break;
            case EN_DOWN:
                pos[selection] = (pos[selection] - 1) % NUM_ALPHA;
                break;
            case EN_A ... EN_Z:
                letter_index = keycode - EN_A;
                letter_found = true;
                break;
            case EN_RESET:
                reset_settings();
                break;
        }
    }
    if (letter_found) {
        char letter = 'A' + letter_index;
        handle_letter_pressed(&letter);
        send_char(letter);
    }
    return true;
}

void keyboard_post_init_user(void) {
    set_layer(MAC_BASE);
}
