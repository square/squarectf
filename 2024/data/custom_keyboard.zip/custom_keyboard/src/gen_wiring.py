import random
import string

def gen_rotor():
    rotor = list(string.ascii_uppercase)
    random.shuffle(rotor)
    return ''.join(rotor)

def gen_reflector():
    alphabet = list(string.ascii_uppercase)
    random.shuffle(alphabet)
    
    swaps = {}
    for i in range(len(alphabet)//2):
        swaps[alphabet[i]] = alphabet[i+len(alphabet)//2]
        swaps[alphabet[i+len(alphabet)//2]] = alphabet[i]

    reflector = list(string.ascii_uppercase)
    for i in range(len(reflector)):
        print(f'Swap {reflector[i]} <-> {swaps[reflector[i]]}')
        reflector[i] = swaps[reflector[i]]

    return ''.join(reflector)

print(f'Reflector: {gen_reflector()}')
print(f'Rotor 1: {gen_rotor()}')
print(f'Rotor 2: {gen_rotor()}')
print(f'Rotor 3: {gen_rotor()}')
