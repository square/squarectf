# Only Ws

## Description
The flag is write there. All you have to do is get it.

## Solution
This challenge gives you arbitrary shellcode exec and a flag loaded into memory. All you have to do is write some shellcode to sys\_write hat flag out to stdout.
