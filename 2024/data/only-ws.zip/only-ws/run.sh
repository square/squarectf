#!/bin/bash

docker build . -t only_ws
docker run -d -p ${HOST_PORT}:8000 only_ws
