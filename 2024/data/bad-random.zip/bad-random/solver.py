import requests
import numpy as np

from base64 import b64decode


SERVER_ADDRESS = 'http://localhost:5000'


def request_encrypted_flag():
    return b64decode(requests.get(SERVER_ADDRESS + '/encrypted_flag').text)


def solve():
    results = []
    num_attempts = 5000
    for _ in range(num_attempts):
        resp = request_encrypted_flag()
        array = np.unpackbits(np.frombuffer(resp, dtype='uint8'))
        results.append(array)

    summed_result = np.sum(results, axis=0)

    result = ''
    for elt in summed_result:
        if elt > ((num_attempts / 2) + 50):
            result += '1'
        else:
            result += '0'

    result_int = int(result, 2)
    return result_int.to_bytes((result_int.bit_length() + 7) // 8, 'big').decode()


if __name__ == '__main__':
    print(solve())