# Bad Random Challenge
This challenge has a flag that is encrypted multiple times with a one time pad. 
However, the one time pad is not generated completely randomly. 
With enough samples the attacker should be able to recover the flag based upon the bias introduced 
into the values used for OTP. 


## Starting the server
`python3.9 -m flask --app app run`

## Running the client
`python3.9 client.py`

## Solving
Collect a significant number of ciphertex (~5000) and then use the bias to recover the plaintext. 