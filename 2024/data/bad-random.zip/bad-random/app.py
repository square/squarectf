import random

from base64 import b64encode
from flask import Flask

FLAG = b"flag{make_sure_your_random_is_good}"
BAD_ENTROPY_RATE = 1 / 8
app = Flask(__name__)


@app.route("/encrypted_flag")
def get_encrypted_flag():
    return b64encode(encrypt(FLAG))


def encrypt(flag):
    key_bytes = bytearray(random.randbytes(len(flag)))
    biased_key_bytes = bias_key(key_bytes)
    return bytes(flag_byte ^ key_byte for flag_byte, key_byte in zip(flag, biased_key_bytes))


def bias_key(key_bytes):
    for idx, key_byte in enumerate(key_bytes):
        key_bits = '{0:b}'.format(key_byte).zfill(8)
        biased_random_byte = ''
        for bit in key_bits:
            if random.random() < BAD_ENTROPY_RATE:
                biased_random_byte += '0'
            else:
                biased_random_byte += bit

        key_bytes[idx] = int(biased_random_byte, 2)
    return key_bytes
