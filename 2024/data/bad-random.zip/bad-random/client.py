import requests

from base64 import b64decode

SERVER_ADDRESS = 'http://localhost:5000'


def request_encrypted_flag():
    return b64decode(requests.get(SERVER_ADDRESS + '/encrypted_flag').text)


def solve():
    # Fill in your solution here!
    print(request_encrypted_flag())


if __name__ == '__main__':
    solve()