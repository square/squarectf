# 2048-hacker

This is the classic [2048 game](https://en.wikipedia.org/wiki/2048_(video_game)) that has a 60s alarm which makes it very hard to solve it manually. 
But..an automated solver can be written or existing one such as https://github.com/nneonneo/2048-ai can be used which is able to get to a 2048 tile within 30s. Getting there in time gives you the flag.

### Solver
Using https://github.com/nneonneo/2048-ai ailib to interact with `server:port` directly for _speed_

```
from pwn import *
import math
import re
from ailib import ailib, to_c_board, from_c_board, to_c_index, from_c_index
# p = process('./2048-ai-solvable-deploy.out')
context.log_level = 'debug'
p = remote('54.85.45.101', 8006)
def get_board(p):
    data = p.recvuntil(b"quit): ")

    # Parsing and processing
    board = [
        [
            int(math.log2(int(e.decode()))) if int(e.decode()) != 0 else int(e.decode())
            for e in re.split(rb'\s+',row)[1:]
        ]
        for row in data.split(b"\n\n")[0].split(b"\n")[1:]
    ]
    return board

movemap = {0: 'w', 1: 's', 2: 'a', 3: 'd'}
movecount = 0
def game_loop(p):
    global movecount
    board = get_board(p)
    move = ailib.find_best_move(to_c_board(board))
    p.sendline(movemap[move])
    movecount+=1
    print("move %s, movecount %u", move, movecount)

while(True):
    game_loop(p)
```