#!/bin/bash

docker build . -t 2048-ai
docker run -d -p ${HOST_PORT}:8000 2048-ai
