#!/bin/bash

g++ -std=c++11 2048-ai-solvable.cpp -o 2048-ai-solvable-deploy.out
g++ -std=c++11 2048-ai-solvable.cpp -DDEBUG -o 2048-ai-solvable-distr.out
