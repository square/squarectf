#!/bin/bash

docker build . -t ihnsaims-patched
docker run -d -p ${HOST_PORT}:8000 ihnsaims-patched
