import SwiftUI

@main
struct MyApp: App {
    init() {
        UserDefaults.standard.register(defaults: [
            "a": "qQwrmkzuhJv6fzCF2XsxuaB+ZBtMEH+Cd3fpTgJpEM8=", // key
            "b": "FjmNRmlNzMZYK8TbIItuVA==", // iv
            "c" : "8XvXFKhm8YFfQShtVXcNZh5F8q0zBJMTnfBSh33SEr8r4hMWb/E2VJq20QO2Byef" // enc
        ])
    }
    
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
