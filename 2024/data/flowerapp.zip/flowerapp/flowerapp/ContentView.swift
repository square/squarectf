import SwiftUI

struct MainView: View {
    @State private var flag: String = loadf()

    var body: some View {
        ZStack {
            ForEach(Array(flag), id: \.self) { char in
                FlowerView(
                    seed: Int(char.asciiValue!)
                )
            }
        }
    }
}
