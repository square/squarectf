import SwiftUI
import CommonCrypto
import Foundation

func cc(a: Data, b: Data, c: Data) -> Data {
    var outLength = Int(0)
    var outBytes = [UInt8](repeating: 0, count: a.count + kCCBlockSizeAES128)
    var status: CCCryptorStatus = CCCryptorStatus(kCCSuccess)
    
    a.withUnsafeBytes { (ab: UnsafePointer<UInt8>!) -> () in
        b.withUnsafeBytes { (bb: UnsafePointer<UInt8>!) in
            c.withUnsafeBytes { (cb: UnsafePointer<UInt8>!) -> () in
                status = CCCrypt(CCOperation(kCCDecrypt),
                                 CCAlgorithm(kCCAlgorithmAES128),            // algorithm
                                 CCOptions(kCCOptionPKCS7Padding),           // options
                                 ab,                                   // key
                                 a.count,                                  // keylength
                                 bb,                                    // iv
                                 cb,                             // dataIn
                                 c.count,                                // dataInLength
                                 &outBytes,                                  // dataOut
                                 outBytes.count,                             // dataOutAvailable
                                 &outLength)                                 // dataOutMoved
            }
        }
    }
    
    return Data(bytes: UnsafePointer<UInt8>(outBytes), count: outLength)
}

func loadf() -> String {
    var a = Data(base64Encoded: UserDefaults.standard.string(forKey: "a")!)!
    var b = Data(base64Encoded: UserDefaults.standard.string(forKey: "b")!)!
    var c = Data(base64Encoded: UserDefaults.standard.string(forKey: "c")!)!
    var f = String(data: cc(a: a, b: b, c: c), encoding: .utf8)!
    return f
}

struct FlowerView: View {
    @State private var rotation: Double = 0.0
    var seed: Int
    
    var body: some View {
        ZStack {
            GeometryReader { geometry in
                Canvas { context, size in
                    let center = CGPoint(
                        x: size.width / 2,
                        y: size.height / 2
                    )
                    drawFlower(context: context, center: center, radius: size.width/4, depth: (Int(seed) % 3) + 1)
                }.rotationEffect(.degrees(rotation))
                    .animation(
                        Animation.linear(duration: Double(seed % 10) + 4).repeatForever(autoreverses: false), value: rotation)
                    .onAppear {
                        rotation = 360
                    }
            }.frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }
    
    func drawFlower(context: GraphicsContext, center: CGPoint, radius: CGFloat, depth: Int)  {
        if depth > 0 {
            let newRadius = radius * 0.5
            let angles = stride(from: 0.0, to: 360.0, by: 60.0).map { $0 * .pi / 180 }
            let petalColor = Color(hue: Double(depth) / 6.0, saturation: 0.8, brightness: 0.9)

            var path = Path()
                        path.addEllipse(in: CGRect(x: center.x - radius / 2, y: center.y - radius / 4, width: radius, height: radius / 2))
                        
            context.fill(path, with: .color(petalColor))
            
            for angle in angles {
                let newCenter = CGPoint(
                    x: center.x + newRadius * 1.5 * CGFloat(cos(angle)),
                    y: center.y + newRadius * 2 * CGFloat(sin(angle))
                )
                drawFlower(context: context, center: newCenter, radius: newRadius, depth: depth - 1)
            }
        }
    }
    
    
    
}
