package main

import (
	"github.com/alokmenghrajani/go-moth/api"
)

func main() {
	api.Start()
}
