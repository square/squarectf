#!/bin/bash

docker build . -t go-moth
docker run -d -p ${HOST_PORT}:8000 go-moth

