# go-moth

A Golang web puzzle. A simple web application shows a message which changes every hour (MOTH stands for Message Of The Hour).

Participants are given access to a public copy of this repo, minus this `README.md` and `utils/aes.key`. Right now, the footer points to
https://github.com/alokmenghrajani/go-moth (private repo), but I can change that to anything else.

Each hourly message is stored in `api/moth.json`, in encrypted form. The flag is the 25th entry and requires the participants to
find the decryption key.

The `/encrypt` endpoint is used to generate the encrypted `api/moth.json` file.

## Building & running

```bash
docker build -t go-moth .
docker run -p 127.0.0.1:8000:8000 go-moth
```

Or without Docker:

```bash
go build .
./go-moth
```

The puzzles listens for http traffic on port 8000.

You can optionally create a new `utils/aes.key` file with `head -c 32 /dev/urandom > utils/aes.key`. You'll then have to generate new encrypted strings using the `/encrypt` endpoint.

## Solution

The puzzle exposes an endpoint to encrypt data and the encryption algorithm is bad: AES-CBC (unauthenticated) with a fixed IV. However, the poor
cryptographic code is a misdirection. The actual solution requiring finding the backdoor (which lives in the `vendor/` folder). The backdoor
requires solving a math puzzle, which is easiest to solve using [Wolfram Alpha](https://www.wolframalpha.com/). You can then grab the AES key,
add a print statement to `api/api.go`, and run the code on your own machine.

## Plaintext version of moth.json

```json
[
  "The horizon holds secrets for those who dare to chase the sunset.",
  "In the heart of every storm, a new path awaits the brave.",
  "Dreams are the seeds; actions are the sunlight they need to grow.",
  "In the garden of life, gratitude is the richest soil.",
  "Every heartbeat is a reminder of the magic in the mundane.",
  "Creativity flourishes where curiosity is free to roam.",
  "A quiet moment can echo louder than a thousand words.",
  "The dance of shadows reveals the beauty of the light.",
  "A single step can change the direction of your entire journey.",
  "In the symphony of existence, silence has its own melody.",
  "The map to your dreams is drawn by the choices you make.",
  "In the weave of time, every thread tells a tale of resilience.",
  "Each dawn offers a blank page, waiting for your story.",
  "Wisdom blooms in the garden of experience.",
  "Life's sweetest moments often hide in the simplest gestures.",
  "Hope is the compass that guides us through uncertainty.",
  "A kind word is a pebble that can create ripples of change.",
  "The strength of a tree lies in its roots, not just its height.",
  "Every challenge is a stepping stone to something greater.",
  "In the embrace of nature, we find our true selves.",
  "The whispers of the past shape the songs of the future.",
  "A heart full of wonder will always find something to marvel at.",
  "The colors of your life are painted with your choices.",
  "Patience is the art of believing in tomorrow.",
  flag{85d680bbb5103431d31d9413e29c7f6f}
]
```
