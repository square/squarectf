#include <stdio.h>

volatile const char* flag = "flag{al1_th3_h0miez_l0v3_llvm_643e5f4a}";

int main() {
    printf("The flag begins with %c\n", flag[0]);
    return 0;
}
