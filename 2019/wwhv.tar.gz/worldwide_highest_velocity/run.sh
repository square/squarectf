#!/bin/sh
./worldwide_highest_velocity
