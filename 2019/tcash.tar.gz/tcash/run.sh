#!/bin/sh
./tcash
