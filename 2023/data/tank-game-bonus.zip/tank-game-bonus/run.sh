#!/bin/bash

docker build . -t tank-game-bonus
docker run -d -p ${HOST_PORT}:8000 tank-game-bonus