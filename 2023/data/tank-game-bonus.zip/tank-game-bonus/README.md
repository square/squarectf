# Tank game bonus

## Description
alright now do it without the freebie shell function. Here's a libc:<br>
<br>
<a href='/static/files/tank-game-bonus/super-sick-tank-game-bonus'>tank-game-bonus</a><br>
<a href='/static/files/tank-game-bonus/libc.so.6'>libc.so.6</a> <a href='/static/files/tank-game-bonus/libm.so.6'>libm.so.6</a><br>
Note: This is just Tank game but without a helpful convenience function. you can technically solve in either order but solving Tank game first will be easier.

## Solution
this is the exact same binary as tank-game except the free shell function was removed. I didn't write a solver but the only extra steps involve leaking a libc address via the printable strings and performing a ret2libc.