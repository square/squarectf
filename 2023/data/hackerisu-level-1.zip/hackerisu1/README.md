# solution

This is the second part of a game challenge modelled after Baba Is You 

Solving this level requires you teleport outside the outer walls by using a wstring write primitive given via the `babaat<addr>` string. My solution relies on ASLR being in favor (`babaat0x...axx`) so that we one can use the `d` from `digitispush` to teleport to a `sun` located outside.

[![asciicast](https://asciinema.org/a/usE3u6LASvEkTp5pfHZ6aFusn.svg)](https://asciinema.org/a/usE3u6LASvEkTp5pfHZ6aFusn)