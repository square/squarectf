package com.example.betheadmin;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Objects;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MainController {

  private static final HashMap<Integer, Profile> PROFILES = new HashMap<>() {{
    put(1, new Profile(1, "CTF Participant", "This is a secret message"));
    put(2, new Profile(2, "Admin", "flag{boyireallyhopenobodyfindsthis!!}"));
  }};

  @GetMapping()
  public String getIndex (HttpServletResponse response,
      @CookieValue(value = "session_id", defaultValue = "") String sessionId,
      Model model) {

    if(Objects.equals(sessionId, "")) {
      response.addCookie(new Cookie("session_id", getSessionId(PROFILES.get(1).getName())));
    }

    model.addAttribute("profiles", PROFILES.values());

    return "index";
  }

  @GetMapping("profile")
  public String getProfile (HttpServletResponse response,
      @RequestParam(defaultValue="1", required=false) Integer id,
      @CookieValue(value = "session_id", defaultValue = "") String sessionId,
      Model model) {

    if(Objects.equals(sessionId, "")) {
      response.addCookie(new Cookie("session_id", getSessionId(PROFILES.get(1).getName())));
    }

    Profile profile = PROFILES.get(id);
    if(profile == null) {
      return "noprofile";
    }

    model.addAttribute("name", profile.getName());

    if(Objects.equals(sessionId, getSessionId(profile.getName()))) {
      model.addAttribute("secret", profile.getSecret());
    } else {
      model.addAttribute("secret", "[ACCESS DENIED: User's can only see their own secret]");
    }

    return "profile";
  }

  private String getSessionId(String name) {
    return Base64.encodeBase64URLSafeString(name.getBytes(
        StandardCharsets.UTF_8));
  }
}
