package com.example.betheadmin;

public class Profile {
  private Integer id;
  private String name;
  private String secret;

  public Profile(Integer id, String name, String secret) {
    this.id = id;
    this.name = name;
    this.secret = secret;
  }

  public Integer getId() {return id;}
  public String getName() {return name;}
  public String getSecret() {return secret;}
}
