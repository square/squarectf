# Be The Admin

Square 2023 Web CTF challenge

## Description

This is a very basic website where you can view other user's profiles, but you can only see your own secret. I'll bet other users' secrets have something of interest

## Hints

1. How does this site know which user you are?


## Notes

This application runs in a single container, and the flag is hardcoded in source, so participants will not get access to the source.

## Solution

The app determines which user you are from the `session_id` cookie, which is just your username Base64 encoded. Once you discover that, then you can replace your cookie value with "Admin" Base64 encoded and you can access the flag