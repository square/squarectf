# Solution
There is a binary message encoded in the final part of the video's audio track. It is encoded using the Specific Area
Message Encoding (SAME) protocol. Many of you may recognize the sound, as it is part of the emergency alert system and
often played on TV at various times as part of a regular test.

`minimodem` is easy to install and can be used to encode or decode the related audio. To decode it, the audio needs to
be fed to it somehow:
1. Extract the audio as a FLAC file and pass the file in to `minimodem -r -f export.flac same`
    1. Grab the  Download the video from youtube (via some third party downloader).
    2. Use VLC to extract the audio again to FLAC.
2. Pass the audio in to the system's input (probably microphone) and have minimodem listen with `minimodem -r same`.
    1. On macOS, one needs to install/run pulseaudio.
    2. For best results, use a dedicated microphone that won't have noise cancellation automatically applied.
        1. I used an Antlion USB microphone successfully.
