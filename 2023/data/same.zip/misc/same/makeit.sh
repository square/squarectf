cat data.txt | minimodem --tx -a -R 48000 -f input-audio.flac same
