import sys
import urllib.request

import server


def xor_bytes(first: bytes, second: bytes) -> bytes:
    assert len(first) == len(second)
    return bytes(a ^ b for a, b in zip(first, second))


def hack_token(token: bytes, current_user: str, desired_user: str) -> bytes:
    """Modify the token, changing the current user to the desired user (of same length).

    Note: Token is IV || USER || NONCE || MAC(CRC)

    CRCs have an interesting property that makes this attack possible (in combination with AES-CTR mode)...

      CRC(A ⊕ B) = CRC(A) ⊕ CRC(B)

    Where ⊕ is an XOR operation. For CRCs that have a non-zero result for an all-zero message, we also need to XOR in
    the CRC of all zeros:

      CRC(A ⊕ B) = CRC(A) ⊕ CRC(B) ⊕ CRC(00...)

    AES-CTR encryption is just an XOR of a secret value against the plaintext. So, a bit flip in the ciphertext will
    result in a corresponding bit flip in the plaintext. We can therefore modify parts of a message via an XOR and
    compute the necessary _change_ to the CRC. We do not have to know the original CRC or any part of the message we do
    not want to modify.
    """
    # And what do you know... "admin" and "azure" are the same length...
    assert len(current_user) == len(desired_user)

    # These are not modified (just an XOR of zeros)
    iv_xor = bytes(server.IV_LEN)
    nonce_xor = bytes(server.NONCE_LEN)

    # Compute the change to the user field that we want to see
    user_xor = xor_bytes(current_user.encode(), desired_user.encode())

    # Compute the change to the CRC/MAC we want to see
    # Note that we can omit leading zeros if we want (iv_xor), but not trailing.
    mac_xor = xor_bytes(
        server.gen_mac(iv_xor + user_xor + nonce_xor),              # CRC(the change)
        server.gen_mac(bytes(len(iv_xor + user_xor + nonce_xor)))   # CRC(all zeros)
    )

    # Modify the token and return
    hacked_token = xor_bytes(token, iv_xor + user_xor + nonce_xor + mac_xor)
    return hacked_token


def hack_the_planet(base_url: str) -> None:
    azure_token_hex = urllib.request.urlopen(f"{base_url}/auth?user=azure&password=hunter2").read().decode()
    admin_token_hex = hack_token(bytes.fromhex(azure_token_hex), "azure", "admin").hex()

    flag = urllib.request.urlopen(f"{base_url}/read/flag.txt?token={admin_token_hex}").read().decode()
    return flag


if __name__ == "__main__":
    # Pass the base URL as the only argument
    print(hack_the_planet(sys.argv[1]))
