import secrets
import unittest

import server
import solution


class Tests(unittest.TestCase):
    def setUp(self) -> None:
        self.key = secrets.token_bytes(32)
        self.token = server.encrypt_token("foobar", self.key)
        self.assertIsNotNone(self.token)

    def test_hack_works(self) -> None:
        hacked_token = solution.hack_token(self.token, "HaCkEd", "foobar")
        user = server.decrypt_token(hacked_token, self.key)
        self.assertEqual("HaCkEd", user)
