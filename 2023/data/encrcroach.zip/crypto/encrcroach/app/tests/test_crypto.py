import secrets
import unittest

import server


class Tests(unittest.TestCase):
    def test_encryption_decryption_works(self) -> None:
        key = secrets.token_bytes(32)
        token = server.encrypt_token("foobar", key)
        self.assertIsNotNone(token)

        user = server.decrypt_token(token, key)
        self.assertEqual("foobar", user)

    def test_decryption_when_any_bit_is_flipped_returns_none(self) -> None:
        key = secrets.token_bytes(32)
        token = server.encrypt_token("foobar", key)
        self.assertIsNotNone(token)

        for i in range(len(token) * 8):
            modified = bytearray(token)
            modified[i // 8] ^= 1 << (i % 8)
            user = server.decrypt_token(bytes(modified), key)
            self.assertIsNone(user, i)

    def test_mac(self) -> None:
        # Test value from https://reveng.sourceforge.io/crc-catalogue/17plus.htm
        data = b"123456789"
        expected = bytes.fromhex("b90956c775a41001")
        actual = server.gen_mac(data)
        self.assertEqual(expected, actual)
