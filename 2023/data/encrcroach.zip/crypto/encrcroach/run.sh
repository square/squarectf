#!/bin/sh
set -ex

# Copy the flag
mkdir -p app/src/users/admin
jq -r .flag challenge.json > app/src/users/admin/flag.txt

# Create a fresh, persistent server key if it does not exist
if [ ! -f server_key.env ]; then
    SERVER_KEY=$(head -c 32 /dev/urandom | xxd -p -c 128)
    echo "SERVER_KEY=${SERVER_KEY}" > server_key.env
fi

docker-compose up --build -d
