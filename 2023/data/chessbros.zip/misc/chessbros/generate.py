import chess.pgn, chess

def square_color(move):
    # returns True if square color is white

    square = move.to_square
    if(((square // 8) % 2 == 0) ^ ((square % 8) % 2 == 0)):
        return chess.WHITE

    return chess.BLACK

def valid_move(target, turn, move):
    return (target=='1') ^ turn ^ square_color(move)

def ascii_to_binary(input_string):
   return ''.join(format(i, '08b') for i in bytearray(input_string, encoding ='utf-8'))

pgn = open("./base.pgn")
game = chess.pgn.read_game(pgn)

board = chess.Board()

for move in game.mainline_moves():
    board.push(move)

target_string = "ag{ch3ss_1s_fun_CheSS_i5_kew1_is_th1s_fl@g_loo0ng_enuff_4_u?}"
target_binary = ascii_to_binary(target_string)
white_move = True
for char in target_binary:
    made_move = False
    for move in set(board.legal_moves):
        #print(move)
        #print(square_color(move))
        if valid_move(char, white_move, move):
            board.push(move)
            made_move = True
            #print(move)
            break
    if not made_move:
        print("no legal moves")
    white_move = not white_move

game = chess.pgn.Game()
game = game.from_board(board)
print(game)
for i,c in enumerate(target_binary):
    print(f"{i}:{c}")
