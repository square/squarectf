# Chessbros

## Description
> I've been wanting to join this chess club for a while now, but I can't seem to figure out the secret password to get in. Can you help me? Apparently the first 40 and last 8 half-moves are all theory ;). This challenge follows the normal flag format.

## Solution
The flag format starts with `flag{` and the hint that the first 40 last 8 half-moves being all theory lets us deduce that each move somehow encodes a bit. `fl` encoded is `01100110 01101100`. Hopefully it isn't too much of a stretch to realize that a same-colored piece moving to the same-colored square is a 1 whereas moving to a different-colored square is a 0.
From there using the Python chess library can quickly solve for the solution. It is intended to be very painful to solve manually. I purposely chose a pgn that did not include castling.

See [solve.py](./solve.py) for an example solution
