import chess.pgn, chess

def square_color(move):
    # returns True if square color is white

    square = move.to_square
    if(((square // 8) % 2 == 0) ^ ((square % 8) % 2 == 0)):
        return chess.WHITE

    return chess.BLACK



pgn = open("dist/chessbros.pgn")
game = chess.pgn.read_game(pgn)

bitstream = ""
for num, move in enumerate(game.mainline_moves()):
    if square_color(move) ^ (num % 2 == 0):
        bitstream += "0"
    else:
        bitstream += "1"

# print(bitstream)        
assert(len(bitstream) % 8 == 0)

def binary_to_ascii(binary_string):
   binary_chunks = [binary_string[i:i+8] for i in range(0, len(binary_string), 8)]
   integer_values = [int(binary, 2) for binary in binary_chunks]
   ascii_string = ''.join([chr(i) for i in integer_values])
   return ascii_string

print(binary_to_ascii(bitstream))  

