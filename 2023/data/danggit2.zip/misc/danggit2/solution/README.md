# Solution

Like in part 1, we have to reconstruct the commit from the commit log. Part 1 is a prerequisite, as we must be able to generate the last commit in part 1 to reconstruct this commit.

```
commit f1543b8d6792da44c7fcf5634c6115c8c8c1a98f
Author: CTF Organizer <ctforganizer@noreply.squarectf.com>
Date:   Wed Nov 1 12:32:27 2023 -0700

    Somehow people are guessing the password! Add some random letters and numbers at the end to make it really secure.
```

The message mentions adding random letters and numbers at the end of the password. We can brute-force the password assuming it is not too long.

A first try might be to modify the file on disk and then invoke `git commit` and `git reset` for each attempted password. On my machine, that benchmarks at about 9 values/sec. If we assume "random letters and numbers" means random lower- and upper-case English letters and all ten digits, then we have `26*2+10 = 62` possible characters. At the rate of 9 values/sec, brute-forcing only 2 characters will take `62^2/9/60 ~= 7` minutes. Similarly, for 3 characters it will be about 7 hours.

Instead of modifying files on disk and invoking actual git commands, what if we could compute the commit sha ourselves? That would involve figuring out how git internally computes commit shas. Searching on Stack Overflow reveals that [it's not actually too complicated](https://stackoverflow.com/a/68806436).

The solution script invokes a Go program that brute-forces the password by computing each potential commit sha. It does all the computations in-memory, with minimal copying, and uses goroutines to achieve better performance through parallelization. On my machine, this benchmarks at around 10,000,000 values/sec. It takes a little over 1 minute to find the password.

The solution script is at [./solve.sh](./solve.sh) and the main logic is in [./main.go](./main.go).

Giving the password to the server reveals the flag!
