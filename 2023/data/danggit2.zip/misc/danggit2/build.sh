#!/bin/bash

GOOS=linux GOARCH=amd64 go build -o danggit2-linux-amd64 .
