#!/bin/bash

docker build . -t danggit2
docker run --restart=always -d -p ${HOST_PORT}:8000 danggit2
