# danggit! (part 2)

### Setup

1. Generate the code and commit history:
    ```shell
    # generate the code
    mkdir -p /tmp/danggit2
    ./generate.sh /tmp/danggit2
    cd /tmp/danggit2

    # generate the commit history
    git log -1 > commit.txt

    # copy files into the challenge repo
    cp go.mod main.go <path/to/challenge/repo>
    cp commit.txt <path/to/challenge/repo/dist>
    ```
2. Build the challenge binary:
    ```shell
    cd <path/to/challenge/repo>
    ./build.sh
    ```
3. Build and run the docker image:
    ```shell
    ./run.sh
    ```

### Solution

See [./solution](./solution).
