package main

import (
	"bufio"
	"crypto/subtle"
	"fmt"
	"os"
	"time"
)

func main() {
	fmt.Print("Password: ")

	scanner := bufio.NewScanner(os.Stdin)
	scanner.Scan()

	time.Sleep(5 * time.Second)

	if subtle.ConstantTimeCompare(scanner.Bytes(), []byte("41156adeacb68c10705f9a6f50c8e9ef92de4e589iUPN")) == 1 {
		flag, _ := os.ReadFile("flag")
		fmt.Println(string(flag))
	}
}
