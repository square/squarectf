package com.example.authenticator;

import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import com.example.authenticator.databinding.ActivityMainBinding;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends AppCompatActivity {


  private ActivityMainBinding binding;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    binding = ActivityMainBinding.inflate(getLayoutInflater());
    setContentView(binding.getRoot());
  }
  int screenWidth = 1080;
  int screenHeight = 2205;
  static String SHA256 = "5dfd1ac9741873dbb889fc5f6362af39c7e8085ea3d952974f37ca66e6f6c597";
  static String FLAG = "9YU3fxDFo276KmxJ4FbfZJYldNY9K4xHRkEjSjeh1hlBWGgYr4CRGo2+w4bHKIL7";

  public void click(View view) throws Exception {
    TextView tv = binding.sampleText;

    String password = binding.editTextTextPassword.getText().toString();
    if(isPassword(screenWidth, screenHeight, password)) {
      System.out.println("Password is correct!");
      tv.setText(getFlag(password));
    } else {
      tv.setText("Incorrect password!");
    }
  }

  public static boolean isPassword(int a, int b, String password) {
    byte[] data = shuffle(a, b, getHash(password));
    String dataStr = bin2hex(data);
    System.out.println("Shuffled : " + dataStr);
    return dataStr.equals(SHA256);
  }
  public static String getFlag(String password) throws Exception {
    SecretKey secretKey = generateAESKeyFromPassword(password);
    return decrypt(FLAG, secretKey);
  }

  public native String stringFromJNI();

  public static byte[] getHash(String password) {
    MessageDigest digest=null;
    try {
      digest = MessageDigest.getInstance("SHA-256");
    } catch (NoSuchAlgorithmException e1) {
      e1.printStackTrace();
    }
    digest.reset();
    return digest.digest(password.getBytes());
  }
  static String bin2hex(byte[] data) {
    StringBuilder hex = new StringBuilder(data.length * 2);
    for (byte b : data)
      hex.append(String.format("%02x", b & 0xFF));
    return hex.toString();
  }

  public static byte[] shuffle(int seedA, int seedB, byte[] secret) {
    Random randA = new Random(seedA*seedB);

    for (int i = 0; i < secret.length; i++) {
      int randomIndex = randA.nextInt(secret.length);
      byte temp = secret[i];
      secret[i] = secret[randomIndex];
      secret[randomIndex] = temp;
    }

    return secret;
  }

  public static SecretKey generateAESKeyFromPassword(String password) throws Exception {
    byte[] salt = new byte[16]; // Generate a random salt
    KeySpec keySpec = new PBEKeySpec(password.toCharArray(), salt, 10000, 128); // 128 bits
    SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
    byte[] keyBytes = factory.generateSecret(keySpec).getEncoded();
    return new SecretKeySpec(keyBytes, "AES");
  }

  public static String decrypt(String encryptedText, SecretKey secretKey) throws Exception {
    Cipher cipher = Cipher.getInstance("AES");
    cipher.init(Cipher.DECRYPT_MODE, secretKey);
    byte[] encryptedBytes = Base64.getDecoder().decode(encryptedText);
    byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
    return new String(decryptedBytes);
  }
}