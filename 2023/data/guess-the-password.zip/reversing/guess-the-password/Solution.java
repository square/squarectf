
import java.math.BigInteger;
import java.security.spec.KeySpec;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class Solution {
  static String SHA256 = "5dfd1ac9741873dbb889fc5f6362af39c7e8085ea3d952974f37ca66e6f6c597";
  static String FLAG = "9YU3fxDFo276KmxJ4FbfZJYldNY9K4xHRkEjSjeh1hlBWGgYr4CRGo2+w4bHKIL7";
  public static void main(String[] args) throws Exception {
    int screenWidth = 1080;
    int screenHeight = 2205;
    byte[] data = unshuffle(screenWidth, screenHeight, new BigInteger(SHA256, 16).toByteArray());
    System.out.println("SHA256: " + bin2hex(data));

    String password = "SQSQSQ";
    SecretKey secretKey = generateAESKeyFromPassword(password);
    String decryptedText = decrypt(FLAG, secretKey);
    System.out.println("Decrypted: " + decryptedText);
  }
  static String bin2hex(byte[] data) {
    StringBuilder hex = new StringBuilder(data.length * 2);
    for (byte b : data)
      hex.append(String.format("%02x", b & 0xFF));
    return hex.toString();
  }

  public static byte[] unshuffle(int seedA, int seedB, byte[] shuffledSecret) {
    Random randA = new Random(seedA*seedB);
    List<Integer> indexes = new ArrayList<>();
    for (int i = 0; i < shuffledSecret.length; i++){
      indexes.add(0, randA.nextInt(shuffledSecret.length));
    }
    for (int i = shuffledSecret.length - 1; i >= 0 ; i--) {
      int randomIndex = indexes.remove(0);
      byte temp = shuffledSecret[i];
      shuffledSecret[i] = shuffledSecret[randomIndex];
      shuffledSecret[randomIndex] = temp;
    }

    return shuffledSecret;
  }

  public static SecretKey generateAESKeyFromPassword(String password) throws Exception {
    byte[] salt = new byte[16]; // Generate a random salt
    KeySpec keySpec = new PBEKeySpec(password.toCharArray(), salt, 10000, 128); // 128 bits
    SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
    byte[] keyBytes = factory.generateSecret(keySpec).getEncoded();
    return new SecretKeySpec(keyBytes, "AES");
  }

  // Decrypt data using AES
  public static String decrypt(String encryptedText, SecretKey secretKey) throws Exception {
    Cipher cipher = Cipher.getInstance("AES");
    cipher.init(Cipher.DECRYPT_MODE, secretKey);
    byte[] encryptedBytes = Base64.getDecoder().decode(encryptedText);
    byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
    return new String(decryptedBytes);
  }
}
