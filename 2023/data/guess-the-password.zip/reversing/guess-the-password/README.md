# Guess the password

## Point Value
150

## Challenge Description
Once you give it the password, it will show you the flag! 

## Description
The apk is just hash (sha256) the password then shuffle the hash. It will continue if the shuffle hash is the same as expected. Then the password will be used to decrypt the flag. The key point is to RE the shuffle algorithm. It is pretty simple that it just use static value (1800*2205) as seed to create `Random`. For each item in the hash value, it will use the `Random` to generate a new index which will be used to swap the value. All you need to do is perform the swap back one by one from the last one. As shown in the following:
```java
public static byte[] unshuffle(byte[] shuffledSecret) {
Random randA = new Random(1800*2205);
List<Integer> indexes = new ArrayList<>();
for (int i = 0; i < shuffledSecret.length; i++){
    indexes.add(0, randA.nextInt(shuffledSecret.length));
}
for (int i = shuffledSecret.length - 1; i >= 0 ; i--) {
    int randomIndex = indexes.remove(0);
    byte temp = shuffledSecret[i];
    shuffledSecret[i] = shuffledSecret[randomIndex];
    shuffledSecret[randomIndex] = temp;
}

return shuffledSecret;
}
```

Then you will get the sha256 as `8966d9fd5ddb97635e5fe8e697af4f62b8a3c7fcc939ca37f67408c5731a1852`. Use sha256 crack websites (e.g., https://md5decrypt.net/en/Sha256/) you can get its plain text is `SQSQSQ` which is the password.
## Deployment
players just need access to Authenticator.apk