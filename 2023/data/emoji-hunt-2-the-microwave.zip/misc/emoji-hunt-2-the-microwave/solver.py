import zlib, pytesseract, time, io
from PIL import Image

def fix_image(b1, b2, b_arr):
    ind = 0

    b_arr[ind] = b_arr[ind] ^ b1

    ind += b_arr[ind]
    b_arr[ind] = b_arr[ind] ^ b2

    return b_arr
        
with open("hebringsyouflag.png", "rb") as f:
    img = bytearray(f.read())
idat_loc = img.index(b'IDAT')
idat_sz = int.from_bytes(img[idat_loc - 4:idat_loc], "big")
crc_loc = idat_loc + 4 + idat_sz

raw_image_data = img[idat_loc + 4 : crc_loc]

block_offset = 0x420

ctr = 0
start = time.time()
for i in range(256):
    for j in range(256):
        img[idat_loc + 4 + block_offset:crc_loc] = fix_image(i, j, raw_image_data[block_offset:])
        img[crc_loc:crc_loc + 4] = zlib.crc32(img[idat_loc:crc_loc]).to_bytes(4, "big")

        try:
            flag = pytesseract.image_to_string(Image.open(io.BytesIO(img))).strip().replace("\n", "").replace(" ", "")
        except:
            continue

        if "flag" in flag:
            print(flag)
            with open("./out/" + "out.png", "wb") as f2:
                f2.write(img)
            print("took {} seconds", time.time() - start)
            exit(0)