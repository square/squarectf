# Emoji hunt 2: The Microwave

## description
:he-brings-you-flag: isn't looking too hot :( maybe you can help the lil' guy out and figure out whats wrong with him?<br>
slack wouldn't let me upload this as an emoji so you'll have to live with spamming the OG :he-brings-you-flag:<br>
<br>
<img src='/static/files/emoji-hunt-2-the-microwave/hebringsyouflag.png' alt='and he always delivers'>

## solution
I took the :he-brings-you-flag: emoji and photoshopped the flag in text onto the flag. i then wrote a script that OCRs that flag out, hashes it, and uses the first two bytes of the hash to corrupt the image that the flag was written on. the script also embedds itself into a ztxt chunk in the corrupted image. contestants get only the image and have to identify the script and extract it, then RE it to figure out the algorithm. They then need to brute force the two bytes that corrupted the image until they land on a working image. this can be done by eye if you're patient enough as the total amount of possible images is 65535 (it seems like most if not all other than the exact original do not have legible text), otherwise you can use the same technique as the script and just start brute forcing images until one outputs the string "flag" somewhere in the OCR output. On my machine a super naive and unoptimized version of this script takes ~20 seconds to run. I could potentially use 3 bytes of the hash instead, though this likely eliminates the possibility of people doing this challenge manually by eye which would be really funny.