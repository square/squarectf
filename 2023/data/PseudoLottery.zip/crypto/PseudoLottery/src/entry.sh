#!/bin/bash

python3 /app/main.py
