import os
import random
import threading
from datetime import datetime, timedelta
import time
from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit

TIMER_DURATION = 30 # seconds
LOTTERY_NUMBER_COUNT = 48

app = Flask(__name__)
socketio = SocketIO(app)

numbers_folder = 'winning_numbers'
flag = open("./flag.txt").read()

# It's not going to be that easy (or is it?)
os.remove("./flag.txt") 

# Initialize timer variables
timer_value = TIMER_DURATION  # Initial timer value in seconds
socket_data = {}
winning_numbers = []

def timer_thread():
    global timer_value, winning_numbers, socket_data

    while True:
        try:
            time.sleep(1)
            timer_value -= 1

            if timer_value == 0:
                notify_winners()
                save_numbers(winning_numbers)
                trim_oldest_file(numbers_folder)
                socket_data.clear()
                # Clear the list of winning numbers and reset the timer
                generate_winnings_numbers(winning_numbers)
                timer_value = TIMER_DURATION
        except Exception as e:
            print(f"Exception in timer thread: {e}")

def notify_winners():
    try:
        # if nobodoy is connected, no one to notify
        if "/" not in socketio.server.manager.rooms:
            return

        for client_sid in list(socketio.server.manager.rooms["/"]):
            if client_sid not in socket_data:
                continue
            client_guess = socket_data[client_sid].get("guess", None)
            if client_guess is None: 
                continue
            if len(client_guess) == len(winning_numbers) and all (x == y for x,y in zip(client_guess, winning_numbers)):
                socketio.emit("notify_client", { "message": f"You won! Here's your prize: {flag}"}, room=client_sid)
            else:
                socketio.emit("notify_client", { "message": "You lost. Better luck next time!"}, room=client_sid)
    except:
        print("Failed to notify winners")


def save_numbers(winning_numbers, timestamp=None):
    # Save the winning numbers to a file
     # Generate a timestamp for the filename
    timestamp = timestamp or datetime.now()
    label = timestamp.strftime('%Y-%m-%d-%H-%M-%S')
    filename = os.path.join(numbers_folder, label)
    with open(filename, 'a') as file:
        for number in winning_numbers:
            file.write(str(number) + '\n')

def generate_winnings_numbers(target_array):
    target_array.clear()
    for _ in range(LOTTERY_NUMBER_COUNT):
        target_array.append(random.randrange(0,4294967295))

def clear_numbers_folder():
    global numbers_folder
    folder = numbers_folder
    for filename in os.listdir(folder):
        file_path = os.path.join(folder, filename)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
        except Exception as e:
            print(f"Error deleting {file_path}: {e}")

def trim_oldest_file(folder_path, max_files=48):
    files = os.listdir(folder_path)

    if len(files) > max_files:
        files.sort()
        oldest_file = os.path.join(folder_path, files[0])
        os.remove(oldest_file)

@app.route('/')
def index():
    return render_template('index.html', timer_value=timer_value, timer_duration=TIMER_DURATION)

@app.route('/winning_numbers')
def view_winning_numbers():
    timestamp = request.args.get('timestamp')
    if timestamp:
        filename = os.path.join('winning_numbers', timestamp)
        with open(filename, 'r') as file:
            numbers = [line.strip() for line in file]
        return render_template('winning_numbers_view.html', numbers=numbers, timestamp=timestamp)
    else:
        # List all the winning numbers files in the folder
        files = [f for f in os.listdir(numbers_folder)]
        files.sort(reverse=True)
        return render_template('winning_numbers.html', files=files)

@socketio.on('disconnect')
def handle_disconnect():
    socket_id = request.sid
    if socket_id in socket_data:
        del socket_data[socket_id]

@socketio.on('guess')
def handle_guess(data):
    user_guess = data['numbers']

    if request.sid not in socket_data:
        socket_data[request.sid] = {}

    # only keep digits and spaces
    filtered_guess = "".join(c for c in user_guess if c.isdigit() or c.isspace())

    # and split on spaces
    guess = [int(n) for n in filtered_guess.split()]

    if len(guess) != LOTTERY_NUMBER_COUNT:
        emit('notify_client', {'message': f"Invalid number count: {len(guess)}, expected {LOTTERY_NUMBER_COUNT}"})
    elif any(n < 0 or n >= 4294967295 for n in guess):
        emit('notify_client', {'message': f"Invalid number range: numbers must be 0 <= n < 4294967295"})
    else:
        socket_data[request.sid]["guess"] = guess
        emit('notify_client', {'message': f"Your guess has been received. Please wait for timer for results. \n Current guess: {guess}"})

if __name__ == '__main__':
    # Create a folder for storing winning numbers if it doesn't exist
    if not os.path.exists(numbers_folder):
        os.makedirs(numbers_folder)
    else:
        clear_numbers_folder()

    historical_draw_count = 26
    for minute_delta in range(1,historical_draw_count+1):
        generate_winnings_numbers(winning_numbers)
        save_numbers(winning_numbers, datetime.now() - timedelta(minutes=historical_draw_count-minute_delta))

    generate_winnings_numbers(winning_numbers)
    threading.Thread(target=timer_thread).start()
    socketio.run(app, debug=False, allow_unsafe_werkzeug=True, host='0.0.0.0')

