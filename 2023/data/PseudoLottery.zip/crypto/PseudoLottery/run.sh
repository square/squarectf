#!/bin/bash

docker build ./src -t pseudo-lottery
docker run --restart=always -d -p ${HOST_PORT}:5000 pseudo-lottery
