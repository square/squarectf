import sys
import requests
from bs4 import BeautifulSoup
from randcrack import RandCrack


port = "5000"

if len(sys.argv) > 1:
    port = sys.argv[1]

# URL of the website to scrape
url = 'http://localhost:' + port  # Replace with the actual URL

# Send an HTTP GET request to the website
response = requests.get(url + "/winning_numbers")

generated_numbers = []

# Check if the request was successful
if response.status_code == 200:
    # Parse the HTML content of the page
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Find all the links within the 'ul' element
    links = soup.find_all('a')
    
    # Visit each link
    for link in links[::-1]:
        link_text = link.get_text()
        link_url = link['href']
        
        # You can perform further actions here, such as following the link or extracting data
        print(f'Link Text: {link_text}')
        print(f'Link URL: {link_url}')
        link_response = requests.get(url + link_url)
        if link_response.status_code == 200:
            link_soup = BeautifulSoup(link_response.text, 'html.parser')
            numbers = link_soup.find_all('li')
            extracted_numbers = [int(number.get_text()) for number in numbers]
            generated_numbers += extracted_numbers
        else:
            print(f'Failed to retrieve the link. Status code: {link_response.status_code}')
        print()
else:
    print(f'Failed to retrieve the page. Status code: {response.status_code}')


for i in range(624):
    rc = RandCrack()
    slice = generated_numbers[i:i+624]
    for n in slice:
        rc.submit(n)

    next_predicted = rc.predict_getrandbits(32)
    j = i+624
    target = generated_numbers[j]
    success = False
    if next_predicted == target:
        success = True
        result = []
        j += 1
        while j < len(generated_numbers):
            rc.predict_getrandbits(32)
            j += 1
        for _ in range(48):
            result.append(rc.predict_getrandbits(32))
        print(result)
        break
    if success:
        break
