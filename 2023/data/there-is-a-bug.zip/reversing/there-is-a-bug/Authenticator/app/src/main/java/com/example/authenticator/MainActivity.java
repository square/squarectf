package com.example.authenticator;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import com.example.authenticator.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

  static {
    System.loadLibrary("authenticator");
  }

  private ActivityMainBinding binding;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    binding = ActivityMainBinding.inflate(getLayoutInflater());
    setContentView(binding.getRoot());
  }

  public void click(View view) {
    TextView tv = binding.sampleText;
    EditText et = binding.editTextTextPassword;
    Context context = this;
    SharedPreferences sharedPref = context.getSharedPreferences("file.txt", Context.MODE_PRIVATE);

    String password = et.getText().toString();
    if (password.equals("password")) {
      System.out.println("Password is correct!");
      String str = "";
      System.out.println("It is time to call getFlag.");
      str = "empty";
      //str = getFlag(tv, et, this, sharedPref);
      tv.setText(str);
    } else {
      tv.setText("Incorrect password!");
    }
  }

  public String getFlag(TextView tv, EditText et, Context context, SharedPreferences sp) {
    return stringFromJNI(tv, et, this, sp);
  }

  /**
   * A native method that is implemented by the 'authenticator' native library,
   * which is packaged with this application.
   */
  public native String stringFromJNI(TextView tv, EditText et, Context context, SharedPreferences sp);
}