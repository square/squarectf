#include <jni.h>
#include <string>

bool isInstanceOfClass(JNIEnv* env, jobject obj, const char* className) {
    jclass targetClass = env->FindClass(className); // Find the class by its name
    if (targetClass == NULL) {
        return false;
    }
    return env->IsInstanceOf(obj, targetClass) == JNI_TRUE;
}

void decrypt(char *ciphertext, size_t plaintext_len, char IV, unsigned char *key)
{
    unsigned char current_block = IV;
    unsigned char unmodified_ciphertext;
    for (int byte_ind = 0; byte_ind < plaintext_len; byte_ind++)
    {
        unmodified_ciphertext = ciphertext[byte_ind];
        current_block = current_block ^ key[current_block % sizeof(size_t)];
        ciphertext[byte_ind] = ciphertext[byte_ind] - (current_block * current_block);
        current_block = unmodified_ciphertext;
    }
    for (int i = 0; i < 64; i++)
    {
        printf("%02x", ciphertext[i]);
    }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_authenticator_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */, jobject tv, jobject et, jobject ct, jobject sp) {
    char* flag = "missing parameter";
    if(!isInstanceOfClass(env, tv, "android/widget/TextView") ||
       !isInstanceOfClass(env, et, "android/widget/EditText") ||
       !isInstanceOfClass(env, ct, "android/content/Context") ||
       !isInstanceOfClass(env, sp, "android/content/SharedPreferences")) return env->NewStringUTF(flag);

    int len = 31;
    unsigned char data[] = {0xA6, 0x70, 0x82, 0x0B, 0xAC, 0xF2, 0x43, 0xC7, 0xAF, 0x72, 0x4B, 0x20, 0xF5, 0x6F, 0x74, 0x48, 0xF0, 0x8E, 0x45, 0xFB, 0xB6, 0xA3, 0x15, 0x78, 0xD6, 0x23, 0x04, 0x1A, 0x70, 0x8D, 0x8D, 0x00};
    decrypt(reinterpret_cast<char *>(data), len, 87, (unsigned char *) "android/content/SharedPreferences");
    return env->NewStringUTF(reinterpret_cast<const char *>(data));
}
