# Nauseous

## description
I've been talking to this obnoxious elf binary, he's super talkative but I think he mentioned he wanted to give you a flag or something.<br>
Required reading:<br>
- <a href='https://en.wikipedia.org/wiki/Executable_and_Linkable_Format#File_layout'>ELF format</a> <br>
- <a href='https://www.technovelty.org/linux/plt-and-got-the-key-to-code-sharing-and-dynamic-libraries.html'>dynamic linking + GOT + PLT</a><br>
<br>
<a href='/static/files/nauseous/nauseous.c'>nauseous.c</a>

## Solution
this challenge claims it will just print the flag via calling a get_flag function provided by a dynamically linked binary. the binary saves the pointer to said function on the stack, then "accidentally" overflows over it. the player is asked to inspect the stack by providing offsets from a stack variable and recover the pointer. The binary is position independent, so players have to use existing return pointers and stack pointers to calculate the distance from the stack to where the binary is loaded, as well as where on the stack they are, and then locate the get_flag function by calculating its offset from the return pointer to main that they find. The goal is to get people to understand how ELF files and pocess mappings work.
This is technically also exploitable through ret2libc or ROP if they can find enough gadgets since I give total RIP control right off the bat, but both of those options are significantly harder than just figuring it out the intended way.