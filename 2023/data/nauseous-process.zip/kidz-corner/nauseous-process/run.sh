#!/bin/bash

docker build . -t nauseous
docker run -d -p ${HOST_PORT}:8000 nauseous