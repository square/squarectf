gcc -fPIC -shared getflag.c -o getflag.so
gcc nauseous.c -o nauseous getflag.so
LD_LIBRARY_PATH=. LD_PRELOAD=getflag.so ./nauseous
