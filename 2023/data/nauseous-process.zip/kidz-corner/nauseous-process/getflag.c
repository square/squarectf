char *get_flag()
{
    return "flag{man_linux_binaries_are_gr0ss}";
}