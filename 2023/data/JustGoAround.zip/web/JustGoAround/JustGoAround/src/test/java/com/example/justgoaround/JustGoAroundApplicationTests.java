package com.example.justgoaround;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JustGoAroundApplicationTests {

  @Test
  void contextLoads() {
  }
}
