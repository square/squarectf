package com.example.justgoaround;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch.core.search.Hit;
import co.elastic.clients.json.jackson.JacksonJsonpMapper;
import co.elastic.clients.transport.ElasticsearchTransport;
import co.elastic.clients.transport.rest_client.RestClientTransport;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

@Controller
public class MainController {

  private ElasticsearchClient elasticsearchClient;
  private ArrayList<Post> posts;

  @GetMapping()
  public String getIndex (Model model) {

    model.addAttribute("posts", new ArrayList<Post>());

    return "index";
  }

  @PostMapping()
  public String postIndex (@RequestParam(defaultValue="", required=false) String query,
      Model model) throws Exception {

    SearchResponse<Post> search = getElasticsearchClient().search(s -> s
            .index("posts")
            .query(q -> q
                .multiMatch(cf -> cf
                    .fields("author", "title", "message")
                    .query(query)
                    .fuzziness("2")
                )
            ).postFilter(f -> f
                .match(m -> m
                    .field("isActive")
                    .query(true)
                )
            ),
        Post.class);

    model.addAttribute("posts", search.hits().hits().stream().map(Hit::source));

    return "index";
  }

  @GetMapping("/post")
  public String getPost () throws Exception {
    return "post";
  }

  @PostMapping("/post")
  public String postPost (@RequestParam(defaultValue="", required=false) String title,
      @RequestParam(defaultValue="", required=false) String message,
      Model model) throws Exception {

    Post post = new Post("0", "CTF Participant", title, message, true);

    Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();

    // root element
    Element postElement = doc.createElement("post");
    doc.appendChild(postElement);

    Attr authorAttr = doc.createAttribute("author");
    authorAttr.setValue("CTF Participant");
    postElement.setAttributeNode(authorAttr);

    Attr titleAttr = doc.createAttribute("title");
    titleAttr.setValue(title);
    postElement.setAttributeNode(titleAttr);

    Attr idAttr = doc.createAttribute("id");
    idAttr.setValue("0");
    postElement.setAttributeNode(idAttr);

    Element messageElement = doc.createElement("message");
    messageElement.setTextContent(message);
    postElement.appendChild(messageElement);

    // write the content into xml file
    Transformer transformer = TransformerFactory.newInstance().newTransformer();
    DOMSource source = new DOMSource(doc);

    String postXml;
    try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
      StreamResult result = new StreamResult(baos);
      transformer.transform(source, result);
      postXml = baos.toString("UTF-8");
    }

    model.addAttribute("post", post);
    model.addAttribute("postXml", postXml);

    return "review";
  }

  @PostMapping("/accept")
  public String postAccept (@RequestParam(defaultValue="", required=false) String postXml,
      Model model) throws Exception {

    Document doc;
    try (ByteArrayInputStream bais = new ByteArrayInputStream(postXml.getBytes(StandardCharsets.UTF_8))) {
      doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(bais);
    }

    var element = doc.getDocumentElement();
    var author = element.getAttribute("author");
    var title = element.getAttribute("title");
    var message = element.getFirstChild().getTextContent();
    Post post = new Post("0", author, title, message, true);
    model.addAttribute("post", post);

    return "accept";
  }

  private ElasticsearchClient getElasticsearchClient() {

    if(elasticsearchClient != null) {
      return elasticsearchClient;
    }

    RestClient restClient = RestClient
        .builder(HttpHost.create("http://"+System.getProperty("ELASTIC_HOST", "db")+":9200"))
        .build();

    // Create the transport with a Jackson mapper
    ElasticsearchTransport transport = new RestClientTransport(
        restClient, new JacksonJsonpMapper());

    // And create the API client
    elasticsearchClient = new ElasticsearchClient(transport);
    return elasticsearchClient;
  }
}

