package com.example.justgoaround;

public class Post {
  public String id;
  public String author;
  public String title;
  public String message;
  public Boolean isActive;

  public Post() {}

  public Post(String id, String author, String title, String message, Boolean isActive) {
    this.id = id;
    this.author = author;
    this.title = title;
    this.message = message;
    this.isActive = isActive;
  }
}
