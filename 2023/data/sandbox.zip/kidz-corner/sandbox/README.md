# sandbox

## description
I "made" "a" "python" "sandbox" """"<br>
nc ip port

## solution
There's plenty of ways to break the sandbox, the two easiest that come to mind are cat${IFS}flag or python3 -> open("flag.txt", "r").read()