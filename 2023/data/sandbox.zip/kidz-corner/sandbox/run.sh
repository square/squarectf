#!/bin/bash

docker build . -t sandbox
docker run -d -p ${HOST_PORT}:8000 sandbox