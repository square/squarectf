#!/usr/bin/env python3

from os import system

print("Hi! Welcome to the kidz corner sandbox! we made it super safe in here - you can execute whatever command you want, but only one word at a time so you can't do anything too dangerous, like steal our flags!")
naughty_words = ["sh", '\t', ';']
while 1:
    naughty = False
    command = input().split(" ")[0]
    for word in command.split(" "):
        for naughty_word in naughty_words:
            if naughty_word in word:
                print("woah there, that looks like a dangerous command! i'm not executing that...")
                naughty = True
        if not naughty:
            system(command)