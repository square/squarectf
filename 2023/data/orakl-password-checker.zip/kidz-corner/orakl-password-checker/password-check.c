#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int super_proprietary_super_advanced_password_checker_hasher(char a, char b, int argc)
{
    // https://jameshfisher.com/2018/02/19/how-to-syscall-in-c/ no idea how this special syntax for inline assembly works but its super neat
    struct timespec ts;
    int syscall_num = 35 * argc; // argc will just be 1, i'm including it here so decompilers don't immediately recognize the syscall number

    char test[8];
    char diff = abs(a - b);
    ts.tv_nsec = 0;
    ts.tv_sec = diff * argc;
    register int syscall_no asm("rax") = 35 * argc; // nanosleep
    register void *arg1 asm("rdi") = &ts;
    register char *arg2 asm("rsi") = 0;
    asm("syscall");
    return diff;
}

int secret_proprietary_super_advanced_password_checker(char *inp, int argc)
{
    char flag[64];
    FILE *fptr = fopen("flag.txt", "r");
    fread(flag, 1, 64, fptr);
    fclose(fptr);
    int diff = 0;
    for (int i = 0; i < strlen(flag); i++)
    {
        if (diff != 0)
        {
            return diff;
        }
        diff += super_proprietary_super_advanced_password_checker_hasher(inp[i], flag[i], argc);
        if (flag[i] == '}')
        {
            return diff;
        }
    }
    return diff;
}

int main(int argc, char **argv)
{
    puts("Time for a classic! i'm not going to GIVE you the flag, instead you give me the flag and I'll tell you if its right or wrong!");
    char inp[64];
    fgets(inp, sizeof(inp), stdin);
    if (!secret_proprietary_super_advanced_password_checker(inp, argc)) {
        puts("Hey you got it! nice work!");
    } else {
        puts("wrong password! cya");
    }
}