#!/bin/bash

docker build . -t orakl-password-checker
docker run -d -p ${HOST_PORT}:8000 orakl-password-checker