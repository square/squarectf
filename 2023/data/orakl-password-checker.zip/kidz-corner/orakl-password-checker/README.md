# orakl password checker

## description
I was reading up on password hashes for my new startup, orakl. apparently they're supposed to take a really long time?<br>
Required reading:<br>
- <a href='https://www.cs.virginia.edu/~evans/cs216/guides/x86.html'>intro to x86</a> + x86_64<br>
- basic documentation for a disassembler of your choosing (try Ghidra, or IDA Free)<br>
<br>
<a href='/static/files/orakl-password-checker/orakl-password-checker'>orakl-password-checker</a>

## solution
the simplest possible "oracle attack" challenge, the binary compares the flag to your input and will sleep for 1 second * the difference between the flag character and the input character. for each character you can binary search down to the correct character. I didn't bother writing a solver though I did some minor testing to ensure it behaves correctly.
The only twists on this challenge are that the sleep syscall was implemented by hand, and the syscall number is multiplied by argc (which will be 1) to make it so decompilers don't immediately recognize the syscall as nanosleep.