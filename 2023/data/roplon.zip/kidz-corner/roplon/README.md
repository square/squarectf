# roplon

## description
I THINK that buffer is big enough, right?<br>
Required reading:<br>
- <a href='https://en.wikipedia.org/wiki/X86_calling_conventions#System_V_AMD64_ABI'>x86_64 calling conventions</a><br>
- <a href='https://en.wikipedia.org/wiki/Return-oriented_programming'>Return Oriented Programming</a><br>
<br>
<a href='/static/files/roplon/roplon'>roplon</a> <a href='/static/files/roplon/roplon.c'>roplon.c</a><br>
nc ip port

## solution
there's a solver script but tl;dr the cat_flag function loads "cat flag.txt" into rdi and do_the_thing passes its sole argument to system().