#!/bin/bash

docker build . -t roplon
docker run -d -p ${HOST_PORT}:8000 roplon