# solution

This is the third part of a game challenge modelled after Baba Is You 

Solving this level requires one to make `wall` not be `stop` which is easy once you are outside the outer walls (level2). Then you can use the digits and letters all over the grid to use the same arbitrary wstring write primitive to write to a global wstring that is currently `cat notflag`. That cmd is run after a timeout using the signal handler for alarm so if one overwrites it with `sh` or `bash` one gets shell after which one can `cat flag`

[![asciicast](https://asciinema.org/a/bxIU7xS8f0LOtrH4lHzEuRXUt.svg)](https://asciinema.org/a/bxIU7xS8f0LOtrH4lHzEuRXUt)