#!/bin/bash
/etc/init.d/xinetd start;
sleep infinity;