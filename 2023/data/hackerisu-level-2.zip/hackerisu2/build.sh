#!/usr/bin/env bash
g++ game.cpp -no-pie -o game-prod.out
g++ game.cpp -no-pie -DDEBUG -o ./dist/game-distr.out
