#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <regex>
#include <locale>
#include <codecvt>
#include <string>
#include <iostream>
#include <iomanip>
#include <csignal>
#include <set>
#include <unistd.h>

#ifdef DEBUG
const std::wstring flag0 = L"placeholder for first flag";
const std::wstring flag1 = L"placeholder for second flag";
#else
const std::wstring flag0 = L"flag{b4B4_Y0ur_m0V35_4re_w34k___n0t!}";
const std::wstring flag1 = L"flag{th3r3_wer3_no_m000v3s}";
#endif

#define GRID_WIDTH 32
#define GRID_HEIGHT 32

enum ObjectType
{
    STOP,
    PUSH,
    YOU,
    PASS,
    MELT,
    WIN
};

class GameObject
{
public:
    virtual wchar_t getSymbol() const = 0;
    virtual ObjectType getObjectType() const = 0;
    virtual void move(wchar_t direction) = 0;
    virtual uint8_t getX() const = 0;
    virtual uint8_t getY() const = 0;
    virtual ~GameObject() {}
};

class Object : public GameObject
{
public:
    Object(uint8_t x, uint8_t y, ObjectType type, wchar_t symbol, std::wstring name)
        : x(x), y(y), type(type), symbol(symbol), name(std::move(name)) {}

    wchar_t getSymbol() const override
    {
        return symbol;
    }

    void setSymbol(wchar_t newsym)
    {
        symbol = newsym;
    }

    ObjectType getObjectType() const override
    {
        return type;
    }

    void move(wchar_t direction) override
    {
        switch (direction)
        {
        case L'w':
            y = std::max(0, y - 1); // Move up
            break;
        case L'a':
            x = std::max(0, x - 1); // Move left
            break;
        case L's':
            y = std::min(GRID_HEIGHT - 1, y + 1); // Move down
            break;
        case L'd':
            x = std::min(GRID_WIDTH - 1, x + 1); // Move right
            break;
        }
    }

    uint8_t getX() const override
    {
        return x;
    }

    uint8_t getY() const override
    {
        return y;
    }

    void setObjectType(ObjectType newType)
    {
        type = newType;
    }

    void setObjectName(std::wstring to)
    {
        name = to;
    }

    const std::wstring &getObjectName() const
    {
        return name;
    }

    const std::wstring getObjAt() const
    {
        std::wstringstream ss;
        ss << L"0x" << std::hex << reinterpret_cast<size_t>(this);
        std::wstring addressString = ss.str();
        std::wstring objectis = this->getObjectName() + L"at" + ss.str();
        return objectis;
    }

private:
    uint8_t x, y;
    ObjectType type;
    wchar_t symbol;
    std::wstring name;
};

class Helper
{
public:
    static std::vector<Object> genAlNum(const std::wstring &alNum, uint8_t startX, uint8_t startY, char direction)
    {
        std::vector<Object> objects;

        for (size_t i = 0; i < alNum.size(); ++i)
        {
            uint8_t x = startX + (direction == 'r' ? i : 0);
            uint8_t y = startY + (direction == 'd' ? i : 0);

            if (std::isdigit(alNum[i]))
            {
                // If it's a digit, create a digit object
                objects.emplace_back(x, y, PASS, alNum[i], L"digit");
            }
            else if (std::isalpha(alNum[i]))
            {
                // If it's a letter, create a letter object
                objects.emplace_back(x, y, PASS, alNum[i], L"letter");
            }
            // Ignore other characters
        }

        return objects;
    }

    static std::vector<Object> genWalls(uint8_t x, uint8_t y, uint8_t height, uint8_t width)
    {
        std::vector<Object> wall;

        // Create horizontal walls
        for (uint8_t i = 0; i < width; ++i)
        {
            wall.emplace_back(x + i, y, PASS, L'▦', L"wall");
            wall.emplace_back(x + i, y + height - 1, PASS, L'▦', L"wall");
        }

        // Create vertical walls
        for (uint8_t i = 1; i < height - 1; ++i)
        {
            wall.emplace_back(x, y + i, PASS, L'▦', L"wall");
            wall.emplace_back(x + width - 1, y + i, PASS, L'▦', L"wall");
        }

        return wall;
    }

    static std::vector<Object> genWall(uint8_t x, uint8_t y, uint8_t len, char dir)
    {
        std::vector<Object> wall;
        if (dir == 'h')
        {
            for (uint8_t i = 0; i < len; ++i)
            {
                wall.emplace_back(x + i, y, PASS, L'▦', L"wall");
            }
        }
        else if (dir == 'v')
        {
            for (uint8_t i = 0; i < len; ++i)
            {
                wall.emplace_back(x, y + i, PASS, L'▦', L"wall");
            }
        }

        return wall;
    }

    static wchar_t getCharOrQ(wchar_t symbol)
    {
        auto letterIt = letters.find(symbol);
        auto digitIt = digits.find(symbol);

        return (letterIt != letters.end() || digitIt != digits.end()) ? symbol : L'?';
    }

    // Trim '?' characters from the start of the string
    static std::wstring trimStartQ(const std::wstring &input)
    {
        size_t start = input.find_first_not_of(L'?');
        return (start == std::wstring::npos) ? L"" : input.substr(start);
    }

    // Trim '?' characters from the end of the string
    static std::wstring trimEndQ(const std::wstring &input)
    {
        size_t end = input.find_last_not_of(L'?');
        return (end == std::wstring::npos) ? L"" : input.substr(0, end + 1);
    }

    static std::wstring getSubstrAfterLastQ(const std::wstring &input)
    {
        // Trim '?' from start and end
        std::wstring trimmed = trimStartQ(trimEndQ(input));

        auto lastQuestionMark = trimmed.rfind(L'?');

        if (lastQuestionMark != std::wstring::npos)
        {
            // Found at least one '?'
            return trimmed.substr(lastQuestionMark + 1);
        }

        // No '?', return the entire string
        return trimmed;
    }

    static std::wstring getSubstrBeforeFirstQ(const std::wstring &input)
    {
        // Trim '?' from start and end
        std::wstring trimmed = trimEndQ(input);

        auto firstQuestionMark = trimmed.find(L'?');

        if (firstQuestionMark != std::wstring::npos)
        {
            // Found at least one '?'
            return trimmed.substr(0, firstQuestionMark);
        }

        // No '?', return the entire string
        return trimmed;
    }

private:
    static const std::set<wchar_t> letters;
    static const std::set<wchar_t> digits;
};

const std::set<wchar_t> Helper::letters = {
    L'a', L'b', L'c', L'd', L'e',
    L'f', L'g', L'h', L'i', L'j',
    L'k', L'l', L'm', L'n', L'o',
    L'p', L'q', L'r', L's', L't',
    L'u', L'v', L'w', L'x', L'y', L'z'};
const std::set<wchar_t> Helper::digits = {L'0', L'1', L'2', L'3', L'4', L'5', L'6', L'7', L'8', L'9'};

class Game
{
public:
    Game() // No need for width and height as members
    {
        initMap();
    }

    void add(Object *object)
    {
        // Add the object to its new position
        uint8_t x = object->getX();
        uint8_t y = object->getY();
        objectsMap[{x, y}].insert(objectsMap[{x, y}].begin(), object);
    }

    void remove(Object *object)
    {
        // Iterate over the entire map
        for (auto &entry : objectsMap)
        {
            auto &objectsAtPosition = entry.second;

            // Find the object in the vector and erase it
            auto it = std::remove_if(objectsAtPosition.begin(), objectsAtPosition.end(),
                                     [object](const Object *obj)
                                     { return obj == object; });

            objectsAtPosition.erase(it, objectsAtPosition.end());
        }
    }

    bool isStopped(Object *pushObject, wchar_t direction) const
    {
        uint8_t pushX = pushObject->getX();
        uint8_t pushY = pushObject->getY();

        // Calculate the position after the push in the specified direction
        uint8_t newX = pushX, newY = pushY;
        switch (direction)
        {
        case L'w':
            newY = std::max(0, pushY - 1); // Move up
            break;
        case L'a':
            newX = std::max(0, pushX - 1); // Move left
            break;
        case L's':
            newY = std::min(GRID_HEIGHT - 1, pushY + 1); // Move down
            break;
        case L'd':
            newX = std::min(GRID_WIDTH - 1, pushX + 1); // Move right
            break;
        }

        if ((newX == pushX && (direction == 'a' || direction == 'd')) || (newY == pushY && (direction == 'w' || direction == 's')))
        {
            return true;
        }

        // Make a copy of the objectsMap before iterating over it
        auto objectsMapCopy = objectsMap;

        // Check if the new position is adjacent to a STOP object
        for (auto &object : objectsMapCopy[{newX, newY}])
        {
            if (object->getObjectType() == STOP)
            {
                return true;
            }
        }

        // Check if the new position is adjacent to another PUSH object
        for (auto &object : objectsMapCopy[{newX, newY}])
        {
            if (object->getObjectType() == PUSH && object != pushObject)
            {
                return isStopped(object, direction);
            }
        }

        return false;
    }

    void init(std::vector<Object *> &objects)
    {
        for (auto &object : objects)
        {
            add(object);
        }
    }

    void move(wchar_t direction)
    {
        // Find all player objects
        std::vector<Object *> players;
        for (auto &entry : objectsMap)
        {
            for (auto *object : entry.second)
            {
                if (object->getObjectType() == YOU)
                {
                    players.push_back(object);
                }
            }
        }

        // If there are no YOU players, return
        if (players.empty())
        {
            return;
        }

        // Iterate over each player
        for (auto *player : players)
        {
            // Attempt to move player
            Object tempPlayer = *player; // Create a temporary player to check for collisions
            tempPlayer.move(direction);

            // Check if the new position of the player is valid (no collision with other objects)
            bool playerMoveValid = true;

            for (auto &entry : objectsMap)
            {
                for (auto *object : entry.second)
                {

                    if (object->getX() == tempPlayer.getX() && object->getY() == tempPlayer.getY())
                    {
                        if (object->getObjectType() == PUSH)
                        {
                            if (isStopped(object, direction))
                            {
                                // Do not move the player if adjacent to a STOP object
                                playerMoveValid = false;
                                break;
                            }
                        }
                        else if (object->getObjectType() == STOP)
                        {
                            if (object->getX() == tempPlayer.getX() && object->getY() == tempPlayer.getY())
                            {
                                // Do not move the player if adjacent to a STOP object
                                playerMoveValid = false;
                                break;
                            }
                        }
                    }
                }
            }

            // Move player only if the new position is valid
            if (playerMoveValid)
            {
                remove(player);
                player->move(direction);
                add(player);
            }

            // Move objects if they are in the player's path
            for (auto &entry : objectsMap)
            {
                for (auto *object : entry.second)
                {
                    // Skip the player, as it has already been handled
                    if (object == player)
                    {
                        continue;
                    }

                    // Check if the object's position matches the player's new position
                    if (object->getX() == player->getX() && object->getY() == player->getY())
                    {
                        // Check for collision and move the object
                        if (object->getObjectType() == PUSH)
                        {
                            if (!isStopped(object, direction))
                            {
                                remove(object);
                                // !!modifying iterator in iteration bug!!
                                moveNext(object, direction);
                            }
                        }
                    }
                }
            }
        }
    }

    void moveNext(Object *pushObject, char direction)
    {
        // Move the push object in the specified direction
        pushObject->move(direction);
        add(pushObject);

        // Find other push objects adjacent to the moved push object
        uint8_t newX = pushObject->getX();
        uint8_t newY = pushObject->getY();

        for (auto *object : objectsMap[{newX, newY}])
        {
            if (object->getObjectType() == PUSH && object != pushObject)
            {
                // Recursively move the adjacent push objects
                remove(object);
                moveNext(object, direction);
            }
        }
    }

    std::vector<Object *> getObjectsByName(const std::wstring &name) const
    {
        std::vector<Object *> result;

        for (const auto &entry : objectsMap)
        {
            for (const auto &object : entry.second)
            {
                if (object->getObjectName() == name)
                {
                    result.push_back(object);
                }
            }
        }

        return result;
    }

    void display() const
    {
        // Print the title and level
        std::wcout << L"hacker is u" << std::endl;

        // Print the top border
        for (uint8_t i = 0; i < GRID_WIDTH * 2 + 2; ++i)
        {
            std::wcout << L'═';
        }
        std::wcout << std::endl;

        // Print debug information for each row and column
        for (uint8_t y = 0; y < GRID_HEIGHT; ++y)
        {
            std::wcout << L'║'; // Left border
            for (uint8_t x = 0; x < GRID_WIDTH; ++x)
            {
                auto it = objectsMap.find({x, y});
                if (it != objectsMap.end())
                {
                    if (!it->second.empty())
                    {
                        if (it->second.size() > 1)
                        {
                            std::wcout << L'?';
                        }
                        else
                        {
                            std::wcout << it->second.back()->getSymbol();
                        }
                    }
                    else
                    {
                        // Print an empty space if the vector is empty
                        std::wcout << L' ';
                    }
                }
                else
                {
                    std::wcout << L' ';
                }
                std::wcout << L' ';
            }
            std::wcout << L'║'; // Right border
            std::wcout << std::endl;
        }

        // Print the bottom border
        for (uint8_t i = 0; i < GRID_WIDTH * 2 + 2; ++i)
        {
            std::wcout << L'═';
        }
        std::wcout << std::endl;
    }

    // void printObjectsMap() const
    // {
    //     for (const auto &entry : objectsMap)
    //     {
    //         for (const auto &object : entry.second)
    //         {
    //             std::wcout << object->getSymbol() << " ";
    //         }
    //         std::wcout << std::endl;
    //     }
    // }

    std::map<ObjectType, std::vector<std::wstring>> scanIs() const
    {
        std::map<ObjectType, std::vector<std::wstring>> mappings;

        // Check rows
        for (uint8_t y = 0; y < GRID_HEIGHT; ++y)
        {
            std::vector<std::wstring> segments;
            std::wstring currentSegment;
            for (uint8_t x = 0; x < GRID_WIDTH; ++x)
            {
                auto it = objectsMap.find({x, y});
                if (it != objectsMap.end() && !it->second.empty())
                {
                    if (it->second.size() > 1)
                    {
                        currentSegment += L"?";
                        continue;
                    }
                    currentSegment += Helper::getCharOrQ(it->second.back()->getSymbol());
                }
                else
                {
                    if (!currentSegment.empty())
                    {
                        segments.push_back(currentSegment);
                        currentSegment.clear();
                    }
                }
            }

            if (!currentSegment.empty())
            {
                segments.push_back(currentSegment);
            }

            for (const auto &segment : segments)
            {
                // std::wcout << segment << std::endl;
                std::wregex pattern(LR"((.+)is(.+))");

                std::wsregex_iterator words_begin(segment.begin(), segment.end(), pattern);
                std::wsregex_iterator words_end;

                for (std::wsregex_iterator i = words_begin; i != words_end; ++i)
                {
                    auto match = *i;
                    std::wstring prefix = match[1].str();
                    std::wstring suffix = match[2].str();
                    std::wstring objectType = Helper::getSubstrBeforeFirstQ(suffix);
                    ObjectType mappedType = PASS;

                    if (objectType == L"u")
                    {
                        mappedType = YOU;
                    }
                    else if (objectType == L"push")
                    {
                        mappedType = PUSH;
                    }
                    else if (objectType == L"stop")
                    {
                        mappedType = STOP;
                    }
                    else if (objectType == L"win")
                    {
                        mappedType = WIN;
                    }
                    else if (objectType == L"melt")
                    {
                        mappedType = MELT;
                    }

                    mappings[mappedType].push_back(Helper::getSubstrAfterLastQ(prefix));
                }
            }
        }

        // Check columns
        for (uint8_t x = 0; x < GRID_WIDTH; ++x)
        {
            std::vector<std::wstring> segments;
            std::wstring currentSegment;

            for (uint8_t y = 0; y < GRID_HEIGHT; ++y)
            {
                auto it = objectsMap.find({x, y});
                if (it != objectsMap.end() && !it->second.empty())
                {
                    if (it->second.size() > 1)
                    {
                        currentSegment += L"?";
                        continue;
                    }
                    currentSegment += Helper::getCharOrQ(it->second.back()->getSymbol());
                }
                else
                {
                    if (!currentSegment.empty())
                    {
                        segments.push_back(currentSegment);
                        currentSegment.clear();
                    }
                }
            }

            if (!currentSegment.empty())
            {
                segments.push_back(currentSegment);
            }

            for (const auto &segment : segments)
            {
                // std::wcout << segment << std::endl;
                std::wregex pattern(LR"((.+)is(.+))");

                std::wsregex_iterator words_begin(segment.begin(), segment.end(), pattern);
                std::wsregex_iterator words_end;

                for (std::wsregex_iterator i = words_begin; i != words_end; ++i)
                {
                    auto match = *i;
                    std::wstring prefix = match[1].str();
                    std::wstring suffix = match[2].str();
                    std::wstring objectType = Helper::getSubstrBeforeFirstQ(suffix);
                    ObjectType mappedType = PASS;

                    if (objectType == L"u")
                    {
                        mappedType = YOU;
                    }
                    else if (objectType == L"push")
                    {
                        mappedType = PUSH;
                    }
                    else if (objectType == L"stop")
                    {
                        mappedType = STOP;
                    }
                    else if (objectType == L"win")
                    {
                        mappedType = WIN;
                    }
                    else if (objectType == L"melt")
                    {
                        mappedType = MELT;
                    }

                    mappings[mappedType].push_back(Helper::getSubstrAfterLastQ(prefix));
                }
            }
        }

        return mappings;
    }

    void scanAtInSegment(const std::wstring &segment, std::map<std::wstring, void *> &addrMappings) const
    {
        std::wregex addrPattern(LR"((.+)at(0x[0-9a-fA-F]+))");

        std::wsregex_iterator addr_words_begin(segment.begin(), segment.end(), addrPattern);
        std::wsregex_iterator addr_words_end;

        for (std::wsregex_iterator i = addr_words_begin; i != addr_words_end; ++i)
        {
            auto match = *i;
            std::wstring object = match[1].str();
            std::wstring addrStr = match[2].str();
            void *addr = reinterpret_cast<void *>(std::stoull(addrStr, nullptr, 16));
            addrMappings[object] = addr;
        }
    }

    std::map<std::wstring, void *> scanAt() const
    {
        std::map<std::wstring, void *> addrMappings;

        // Check rows
        for (uint8_t y = 0; y < GRID_HEIGHT; ++y)
        {
            std::vector<std::wstring> segments;
            std::wstring currentSegment;
            for (uint8_t x = 0; x < GRID_WIDTH; ++x)
            {
                auto it = objectsMap.find({x, y});
                if (it != objectsMap.end() && !it->second.empty())
                {
                    if (it->second.size() > 1)
                    {
                        currentSegment += L"?";
                        continue;
                    }
                    currentSegment += Helper::getCharOrQ(it->second.back()->getSymbol());
                }
                else
                {
                    if (!currentSegment.empty())
                    {
                        segments.push_back(currentSegment);
                        currentSegment.clear();
                    }
                }
            }

            if (!currentSegment.empty())
            {
                segments.push_back(currentSegment);
            }
            for (const auto &segment : segments)
            {
                // std::wcout << segment << std::endl;
                scanAtInSegment(segment, addrMappings);
            }
        }

        // Check columns
        for (uint8_t x = 0; x < GRID_HEIGHT; ++x)
        {
            std::vector<std::wstring> segments;
            std::wstring currentSegment;
            for (uint8_t y = 0; y < GRID_WIDTH; ++y)
            {
                auto it = objectsMap.find({x, y});
                if (it != objectsMap.end() && !it->second.empty())
                {
                    if (it->second.size() > 1)
                    {
                        currentSegment += L"?";
                        continue;
                    }
                    currentSegment += Helper::getCharOrQ(it->second.back()->getSymbol());
                }
                else
                {
                    if (!currentSegment.empty())
                    {
                        segments.push_back(currentSegment);
                        currentSegment.clear();
                    }
                }
            }

            if (!currentSegment.empty())
            {
                segments.push_back(currentSegment);
            }
            for (const auto &segment : segments)
            {
                // std::wcout << segment << std::endl;
                scanAtInSegment(segment, addrMappings);
            }
        }

        return addrMappings;
    }

    void removeMelted()
    {
        // Iterate over the entire map
        for (auto &entry : objectsMap)
        {
            auto &objectsAtPosition = entry.second;

            // Check for MELT objects
            std::vector<Object *> meltObjects;
            bool melts = false;

            for (auto *object : objectsAtPosition)
            {
                if (object->getObjectType() == MELT)
                {
                    melts = true;
                    break;
                }
            }

            if (melts) {
                // Remove overlapping-with-MELT objects
                for (auto *object : objectsAtPosition)
                {
                    if (object->getObjectType() != MELT)
                    {
                        remove(object);
                    }
                }
            }
        }
    }

    bool checkForWin()
    {
        // Iterate over the entire map
        for (auto &entry : objectsMap)
        {
            auto &objectsAtPosition = entry.second;

            // Check if any YOU objects are on WIN cells
            for (auto *object : objectsAtPosition)
            {
                if (object->getObjectType() == YOU)
                {
                    uint8_t x = object->getX();
                    uint8_t y = object->getY();

                    auto it = std::find_if(objectsAtPosition.begin(), objectsAtPosition.end(),
                                           [](const Object *obj)
                                           { return obj->getObjectType() == WIN; });

                    if (it != objectsAtPosition.end() && (*it)->getX() == x && (*it)->getY() == y)
                    {
                        if ((*it)->getSymbol() == L'►')
                        {
                            std::wcout << flag0 << std::endl;
                        }
                        else if ((*it)->getSymbol() == L'◄')
                        {
                            std::wcout << flag1 << std::endl;
                        }
                        // You may want to add an exit statement or handle the game completion logic here
                        return true;
                    }
                }
            }
        }

        return false;
    }

    const std::map<std::pair<uint8_t, uint8_t>, std::vector<Object *>> &getObjectsMap() const
    {
        return objectsMap;
    }

private:
    std::map<std::pair<uint8_t, uint8_t>, std::vector<Object *>> objectsMap;

    void initMap()
    {
        for (uint8_t x = 0; x < GRID_WIDTH; ++x)
        {
            for (uint8_t y = 0; y < GRID_HEIGHT; ++y)
            {
                objectsMap[{x, y}] = std::vector<Object *>();
            }
        }
    }
};

std::wstring theend = L"cat notflag";
void alarmHandler(int signum) {
    std::wstring_convert<std::codecvt_utf8<wchar_t>> converter;
    std::string str = converter.to_bytes(theend);
    system(str.c_str());
    exit(0);
}

int main()
{
    signal(SIGALRM, alarmHandler);
    alarm(20);
    setlocale(LC_ALL, "en_US.UTF-8");
    Object baba(5, 4, PASS, L'⌤', L"baba");
    Object cloud0(5, 7, PASS, L'☁', L"cloud");
    Object cloud1(6, 9, PASS, L'☁', L"cloud");
    Object cloud2(5, 9, PASS, L'☁', L"cloud");
    Object keke(7, 19, PASS, L'⌥', L"keke");
    Object flag(20, 21, PASS, L'►', L"flag");
    Object flag1(29, 31, PASS, L'◄', L"flag");
    Object sun0(20, 20, PASS, L'☼', L"sun");
    Object sun1(18, 19, PASS, L'☼', L"sun");
    Object sun2(5, 8, PASS, L'☼', L"sun");
    Object sun3(9, 1, PASS, L'☼', L"sun");
    Object sun4(0, 0, PASS, L'☼', L"sun");
    Object sun5(0, 2, PASS, L'☼', L"sun");
    Object d(27,4,PASS,L'd',L"letter");
    Object zero(5,5,PASS,L'0',L"digit");
    Object one(8,9,PASS,L'1',L"digit");
    Object two(12,4,PASS,L'2',L"digit");
    Object three(8,14, PASS, L'3', L"digit");
    Object four(19,17, PASS, L'4', L"digit");
    Object five(14,19, PASS, L'5', L"digit");
    Object six(10,11, PASS, L'6', L"digit");
    Object extra_six(19,19, PASS, L'6', L"digit");
    Object seven(17,15, PASS, L'7', L"digit");
    Object eight(19,16, PASS, L'8', L"digit");
    Object nine(3,13, PASS, L'9', L"digit");
    
    std::vector<Object *> objects = {&baba, &flag, &flag1, &cloud0, &cloud1, &cloud2, &keke, &sun0,
                                     &sun1, &sun2, &sun3, &sun4, &sun5, &d,
                                     &zero, &one, &two, &three, &four,  &five, &six, &extra_six, &seven, &eight, &nine};

    // vertical inner wall
    std::vector<Object> vwall = Helper::genWall(21, 3, 18, 'v');
    for (auto &block : vwall)
    {
        objects.push_back(&block);
    }

    // horizontal inner wall
    std::vector<Object> hwall = Helper::genWall(3, 20, 17, 'h');
    for (auto &block : hwall)
    {
        objects.push_back(&block);
    }

    // outer wall
    std::vector<Object> wall = Helper::genWalls(2, 2, 28, 28);

    for (auto &block : wall)
    {
        objects.push_back(&block);
    }

    // init phrases
    std::vector<Object> wordObjects0 = Helper::genAlNum(L"kekeispush", 18, 4, 'd');
    for (auto &letter : wordObjects0)
    {
        objects.push_back(&letter);
    }
    std::vector<Object> wordObjects1 = Helper::genAlNum(L"babaisu", 4, 6, 'r');
    for (auto &letter : wordObjects1)
    {
        objects.push_back(&letter);
    }
    std::vector<Object> wordObjects2 = Helper::genAlNum(L"wallisstop", 30, 11, 'd');
    for (auto &letter : wordObjects2)
    {
        objects.push_back(&letter);
    }
    std::vector<Object> wordObjects3 = Helper::genAlNum(L"flagiswin", 0, 1, 'r');
    for (auto &letter : wordObjects3)
    {
        objects.push_back(&letter);
    }
    std::vector<Object> wordObjects4 = Helper::genAlNum(L"letterispush", 25, 6, 'd');
    for (auto &letter : wordObjects4)
    {
        objects.push_back(&letter);
    }
    std::vector<Object> wordObjects5 = Helper::genAlNum(L"sunismelt", 11, 30, 'r');
    for (auto &letter : wordObjects5)
    {
        objects.push_back(&letter);
    }
    std::vector<Object> wordObjects6 = Helper::genAlNum(L"cloudispush", 4, 15, 'r');
    for (auto &letter : wordObjects6)
    {
        objects.push_back(&letter);
    }
    std::vector<Object> wordObjects10 = Helper::genAlNum(L"igitispush", 27, 7, 'd');
    for (auto &letter : wordObjects10)
    {
        objects.push_back(&letter);
    }

    std::vector<Object> babaatwhat = Helper::genAlNum(baba.getObjAt(), 4, 23, 'r');
    for (auto &block : babaatwhat)
    {
        objects.push_back(&block);
    }

    Game game;
    game.init(objects);
    while (true)
    {
        game.display();
        // default: obj-is-pass
        for (auto &entry : game.getObjectsMap())
        {
            for (auto *object : entry.second)
            {
                object->setObjectType(PASS);
            }
        }

        // obj-at-addr
        auto addrMappings = game.scanAt();
        for (const auto &mapping : addrMappings)
        {
            Object *newObject = (Object *)mapping.second;
            newObject->setObjectName(mapping.first);
        }

        // obj-is-type
        auto mappings = game.scanIs();
        for (const auto &mapping : mappings)
        {
            for (const auto &value : mapping.second)
            {
                auto objects = game.getObjectsByName(value);
                for (auto *object : objects)
                {
                    object->setObjectType(mapping.first);
                }
            }
        }

        wchar_t direction;
        std::wcin >> direction;
        game.move(direction);
        game.checkForWin();
        game.removeMelted();
    }

    return 0;
}