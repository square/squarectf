#!/bin/bash

docker build . -t hackerisu0
docker run --restart=always -e LANG=C.UTF-8 -d -p ${HOST_PORT}:8000 hackerisu0