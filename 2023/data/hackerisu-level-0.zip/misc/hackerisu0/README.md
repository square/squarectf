# solution

This is the first of a three part game challenge modelled after Baba Is You 

Solving the first level requires you to clip through the `sun` object right above the first flag. The challenge can be solved completely blind by experimenting with the objects on the grid. If one overlaps two `non-push` objects and then makes them both `push`, the resulting push movement results in the second object thrown across two blocks. This will allow the player to clip/leap over obstacles.

[![asciicast](https://asciinema.org/a/Lk4d0a3VpBFU2nIlMkpTozsVy.svg)](https://asciinema.org/a/Lk4d0a3VpBFU2nIlMkpTozsVy)