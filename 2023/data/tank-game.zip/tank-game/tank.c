#include <stdio.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>

// #define DEBUG
#define FIELD_SIZE 112 // max range + 1 because index starts at 0

// thx http://www.ascii-art.de/ascii/t/tank.txt
char *tank[] = {" __     ", "|\"\"\"\\-=  ", "(____)   "};

// thx chatgpt
double calculateProjectileLandingPoint(double v0, double theta)
{
    const double g = 9.81; // Acceleration due to gravity (m/s^2)

    // Convert theta from degrees to radians
    double thetaRad = theta * M_PI / 180.0;

    // Calculate the horizontal and vertical components of the velocity
    double vx = v0 * cos(thetaRad);
    double vy = v0 * sin(thetaRad);

    // Calculate the time of flight
    double t = (2.0 * vy) / g;

    // Calculate the horizontal distance (landing point)
    double x = vx * t;

    printf("Projectile will land at x = %i meters\n", (int)x);
    return x;
}

#ifdef DEBUG
double calculateRequiredPowerForDest(double target, double desired_angle)
{
    // the full equation is: destination = (v0 * cos(angle)) * (2 * (v0 * sin(angle))) / gravity)
    // rewriting this to solve for v0 gives v0 = (sqrt(destination) * sqrt(gravity)) / sqrt(sin(2 * angle))
    // note angle needs to be converted to radians first
    // also convert target to double and add 0.5 to aim at the "middle" of the index
    return (((sqrt((target + 0.5)) * sqrt(9.81))) / sqrt(sin(2 * ((M_PI * desired_angle) / 180))));
}

#endif

int place_enemy(char *field, int field_size)
{
    int loc = rand() % field_size - 1;
    field[loc] = 'E';

    return loc;
}

void i_dont_want_to_finangle_a_shell_out_of_this_please_just_give_me_one()
{
    system("/bin/bash");
}

void wipe_old_hits(char *field, int field_size)
{
    for (int i = 0; i < field_size; i++)
    {
        if (field[i] == '_' || field[i] == '-')
        {
            field[i] = ' ';
        }
    }
}

int handle_specialty_shot(char field[], int field_size, char current_ammo_type, int hit_loc)
{
    int successful_hit = 0;
    for (int i = -1; i < 2; i++)
    {
        if (field[hit_loc + i] == 'E')
        {
            successful_hit = 1;
        }
        field[hit_loc + i] = current_ammo_type;
    }
    return successful_hit;
}

void fill_buf(char buf[], int len, char byte_to_fill)
{
    for (int i = 0; i < len; i++)
    {
        buf[i] = byte_to_fill;
    }
}

// definitely logically organized for normal human beings yes
// these are the only values that need to be forced into order, since everything else will be
// reachable with "unlimited" range and power
struct game_data {
    char floors[FIELD_SIZE + 1];
    char distance_markers[FIELD_SIZE + 2];
    unsigned int max_angle; // 3: blast this to aim backwards
    char field[FIELD_SIZE]; // positive index overflows into this array go down this struct
    unsigned int max_power; // 1: blast this to aim further
};

int game_loop()
{
    struct game_data game_instance;
    game_instance.max_angle = 90;
    game_instance.max_power = 33;
    char *heart = "<3 ";
    fill_buf(game_instance.floors, FIELD_SIZE, '=');
    game_instance.floors[FIELD_SIZE] = 0;
    fill_buf(game_instance.distance_markers, FIELD_SIZE, ' ');

    // look I couldn't come up with anything better ok this isnt python
    game_instance.distance_markers[25] = '|';
    game_instance.distance_markers[26] = '2';
    game_instance.distance_markers[27] = '5';
    game_instance.distance_markers[28] = 'm';
    game_instance.distance_markers[50] = '|';
    game_instance.distance_markers[51] = '5';
    game_instance.distance_markers[52] = '0';
    game_instance.distance_markers[53] = 'm';
    game_instance.distance_markers[75] = '|';
    game_instance.distance_markers[76] = '7';
    game_instance.distance_markers[77] = '5';
    game_instance.distance_markers[78] = 'm';
    game_instance.distance_markers[100] = '|';
    game_instance.distance_markers[101] = '1';
    game_instance.distance_markers[102] = '0';
    game_instance.distance_markers[103] = '0';
    game_instance.distance_markers[104] = 'm';
    game_instance.distance_markers[105] = 0;

    srand(time(NULL));
    int max_misses = 5; // blast this for infinite turns
    int num_ammo_types = 2; // blast this to control your write value

    char ammo_types[2] = {'_', '-'};
    int ammo_counts[2] = {9999, 0};
    char current_ammo_type;
    int miss_ctr = 0;
    int hit_streak = 0;
    fill_buf(game_instance.field, FIELD_SIZE, ' ');
    game_instance.field[FIELD_SIZE - 1] = 0; // null terminate the field so we can print it easily

    while (1)
    {
        // calculate current amount of lives
        int lives = max_misses - miss_ctr;
        if (lives == 0)
        {
            puts("You lose!");
            break;
        }
        // place a new enemy
        int enemy_loc = place_enemy(game_instance.field, FIELD_SIZE);

        // show current lives
        fputs("         lives: ", stdout);
        for (int i = 0; i < lives; i++)
        {
            fputs(heart, stdout);
        }
        puts("");

        // print out the field
        printf("         %s\n%s\n%s%s\n%s%s\n         %s\n", game_instance.floors, tank[0], tank[1], game_instance.field, tank[2], game_instance.floors, game_instance.distance_markers);
        wipe_old_hits(game_instance.field, FIELD_SIZE);
        double power; // Initial velocity in m/s
        double angle; // Launch angle in degrees

        if (hit_streak >= 3)
        {
            puts("Hit Streak! 1 specialty ammo granted");
            ammo_counts[1] += 1;
        }

        // offer to select ammo type if player has special ammo available
        if (ammo_counts[1] > 0)
        {
            while (1)
            {
                puts("Select ammo type:\n1: _\n2: -");
                int selection;
                scanf(" %d", &selection);
                // allows you to write bytes other than _ and - once you overwrite num_ammo_types
                if (selection - 1 >= 0 && selection - 1 < num_ammo_types)
                {
                    current_ammo_type = ammo_types[selection - 1];
                    break;
                }
            }
        }
        else
        {
            current_ammo_type = '_';
        }

        while (1)
        {
            puts("Enter power: ");
            scanf(" %lf", &power);
            if (power > game_instance.max_power || power < 0)
            {
                printf("Your tank's max power is %i, please input a valid power\n", game_instance.max_power);
            }
            else
            {
                break;
            }
        }

        while (1)
        {
            puts("Enter angle: ");
            scanf(" %lf", &angle);
            if (angle > game_instance.max_angle || angle < 0)
            {
                printf("your angle must between 0 and %i\n", game_instance.max_angle);
            }
            else
            {
                break;
            }
        }

        int hit_loc = calculateProjectileLandingPoint(power, angle);

        char input_buf[8] = {0};
        puts("fire when ready!");
        while (1)
        {
            fgets(input_buf, sizeof(input_buf), stdin);
	    if (!strcmp(input_buf, "pew!\n"))
	    {
	        break;
	    }
        }

        int successful_hit = 0;
        if (current_ammo_type == '-')
        {
            ammo_counts[1]--;
            successful_hit = handle_specialty_shot(game_instance.field, FIELD_SIZE, current_ammo_type, hit_loc);
        }
        else
        { // this needs to be a catch-all else otherwise its way harder to write arbitrary bytes
            if (game_instance.field[hit_loc] == 'E')
            {
                successful_hit = 1;
            }
            game_instance.field[hit_loc] = current_ammo_type;
        }

        if (successful_hit)
        {
            puts("Direct hit!\n");
            hit_streak++;
        }
        else
        {
            puts("You missed!\n");
            miss_ctr += 1;
            hit_streak = 0;
        }
    }
    return 0;
}

int main(void)
{
    puts("welcome to the super sick tank game! survive for as long as you can!");
    return game_loop();
}
