#!/bin/bash

set -o errexit
set -o pipefail
set -o nounset

GIT_NAME="CTF Organizer"
GIT_EMAIL="ctforganizer@noreply.squarectf.com"

export GIT_AUTHOR_NAME="${GIT_NAME}"
export GIT_COMMITTER_NAME="${GIT_NAME}"
export GIT_AUTHOR_EMAIL="${GIT_EMAIL}"
export GIT_COMMITTER_EMAIL="${GIT_EMAIL}"

if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <PATH_TO_REPO>"
    exit 1
fi

REPO_PATH="$1"
cd "${REPO_PATH}"

commit() {
    go fmt . || true
    GIT_AUTHOR_DATE="$1" GIT_COMMITTER_DATE="$1" git commit -a -m "$2"
}

stage_1() {
cat > hello.go <<- EOF
package main

import "fmt"

func main() {
	fmt.Println("Hello, 世界")
}
EOF
git add hello.go
commit "$1" "$2"
}

stage_2() {
cat > go.mod <<- EOF
module ctf

go 1.21.3
EOF
git add go.mod
commit "$1" "$2"
}

stage_3() {
git mv hello.go main.go
cat > main.go <<- EOF
package main

import "fmt"

func main() {
	fmt.Print("Password: ")
}
EOF
commit "$1" "$2"
}

stage_4() {
cat > main.go <<- EOF
package main

import (
	"bufio"
	"fmt"
	"os"
)

func main() {
	fmt.Print("Password: ")

	scanner := bufio.NewScanner(os.Stdin)
	scanner.Scan()
}
EOF
commit "$1" "$2"
}

stage_5() {
cat > main.go <<- EOF
package main

import (
	"bufio"
	"fmt"
	"os"
)

func main() {
	fmt.Print("Password: ")

	scanner := bufio.NewScanner(os.Stdin)
	scanner.Scan()

	flag, _ := os.ReadFile("flag")
	fmt.Println(string(flag))
}
EOF
commit "$1" "$2"
}

stage_6() {
cat > main.go <<- EOF
package main

import (
	"bufio"
	"crypto/subtle"
	"fmt"
	"os"
)

func main() {
	fmt.Print("Password: ")

	scanner := bufio.NewScanner(os.Stdin)
	scanner.Scan()

	if subtle.ConstantTimeCompare(scanner.Bytes(), []byte("foo")) == 1 {
		flag, _ := os.ReadFile("flag")
		fmt.Println(string(flag))
	}
}
EOF
commit "$1" "$2"
}

stage_7() {
cat > main.go <<- EOF
package main

import (
	"bufio"
	"crypto/subtle"
	"fmt"
	"os"
	"time"
)

func main() {
	fmt.Print("Password: ")

	scanner := bufio.NewScanner(os.Stdin)
	scanner.Scan()

	time.Sleep(5 * time.Second)

	if subtle.ConstantTimeCompare(scanner.Bytes(), []byte("foo")) == 1 {
		flag, _ := os.ReadFile("flag")
		fmt.Println(string(flag))
	}
}
EOF
commit "$1" "$2"
}

stage_8() {
cat > main.go <<- EOF
package main

import (
	"bufio"
	"crypto/subtle"
	"fmt"
	"os"
	"time"
)

func main() {
	fmt.Print("Password: ")

	scanner := bufio.NewScanner(os.Stdin)
	scanner.Scan()

	time.Sleep(5 * time.Second)

	if subtle.ConstantTimeCompare(scanner.Bytes(), []byte("41156adeacb68c10705f9a6f50c8e9ef92de4e58")) == 1 {
		flag, _ := os.ReadFile("flag")
		fmt.Println(string(flag))
	}
}
EOF
commit "$1" "$2"
}

stage_9() {
cat > main.go <<- EOF
package main

import (
    "bufio"
    "crypto/subtle"
    "fmt"
    "os"
    "time"
)

func main() {
    fmt.Print("Password: ")

    scanner := bufio.NewScanner(os.Stdin)
    scanner.Scan()

    time.Sleep(5 * time.Second)

    if subtle.ConstantTimeCompare(scanner.Bytes(), []byte("41156adeacb68c10705f9a6f50c8e9ef92de4e589iUPN")) == 1 {
        flag, _ := os.ReadFile("flag")
        fmt.Println(string(flag))
    }
}
EOF
commit "$1" "$2"
}

git init

stage_1 "Wed Nov 1 09:36:47 2023 -0700" "Add hello example from https://go.dev/tour/welcome/1"

stage_2 "Wed Nov 1 09:47:39 2023 -0700" "I forgot how to run go code... go mod init ctf"

stage_3 "Wed Nov 1 10:09:11 2023 -0700" "Rename hello.go to main.go and update the prompt. Almost forgot about go fmt ."

stage_4 "Wed Nov 1 10:26:51 2023 -0700" "So many ways to read from stdin in go... create a bufio scanner and just call scanner.Scan() I guess? Also, simplify the imports since there are 3 now."

stage_5 "Wed Nov 1 10:43:07 2023 -0700" "Read the flag file and print it to stdout as a string. Who needs error handling, it's just a ctf!"

stage_6 "Wed Nov 1 11:05:29 2023 -0700" "Actually, only print the flag if the scanned bytes matches foo. Make sure to compare in constant time so we don't leak any info!"

stage_7 "Wed Nov 1 11:33:56 2023 -0700" "Add a sleep before the compare, this will be so hard to crack!"

stage_8 "Wed Nov 1 11:57:38 2023 -0700" "Replace foo with an actual password. How about the git tree hash? That should be random enough."

stage_9 "Wed Nov 1 12:32:27 2023 -0700" "Somehow people are guessing the password! Add some random letters and numbers at the end to make it really secure."
