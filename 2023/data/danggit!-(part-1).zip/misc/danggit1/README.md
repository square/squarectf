# danggit! (part 1)

### Setup

1. Generate the code and commit history:
    ```shell
    # generate the code
    mkdir -p /tmp/danggit1
    ./generate.sh /tmp/danggit1
    cd /tmp/danggit1

    # IMPORTANT! Go back one commit (for part 1)
    git reset --hard HEAD~1

    # generate the commit history
    git log > commit-history.txt

    # copy files into the challenge repo
    cp go.mod main.go <path/to/challenge/repo>
    cp commit-history.txt <path/to/challenge/repo/dist>
    ```
2. Build the challenge binary:
    ```shell
    cd <path/to/challenge/repo>
    ./build.sh
    ```
3. Build and run the docker image:
    ```shell
    ./run.sh
    ```

### Solution

See [./solution](./solution).
