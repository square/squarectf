#!/bin/bash

docker build . -t danggit1
docker run --restart=always -d -p ${HOST_PORT}:8000 danggit1
