#!/bin/bash

GOOS=linux GOARCH=amd64 go build -o danggit1-linux-amd64 .
