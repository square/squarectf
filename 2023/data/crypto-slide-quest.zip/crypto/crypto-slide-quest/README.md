# Crypto Slide Quest

## Description
> I lost my secret key and the flag while writing this challenge, can you help me out? Ciphertext base64: `LEs2fVVxNDMfNHEtcx80cB8nczQfJhVkDHI/Ew==`

## Solution
The astute reader will realize that we are doing multiple xors with a static key sliding across character by character  
With plaintext `flag{1}` and key `bat` the algorithm visualized would be:
```
flag{1}
bat
 bat
  bat
   bat
    bat

0: f ^ b
1: l ^ b ^ a
2: a ^ b ^ a ^ t
3: g ^ b ^ a ^ t
4: { ^ b ^ a ^ t
5: 1 ^ a ^ t
6: } ^ t
```

Since [crypto_slide_quest.c](./dist/crypto_slide_quest.c) is given, we know that the key length is 6 (sizeof(key) - null byte). The flag format is `flag{.*}`, so we can recover the key using the known 6 bytes. The first ciphertext character gives us the first key character which then tells us the second one.  
The same is true for the last ciphertext character and the last key character.
Then we can just redo the algorithm using the ciphertext and recovered key to get the plaintext flag.  

See [solver.py](./solver.py) for an example solution