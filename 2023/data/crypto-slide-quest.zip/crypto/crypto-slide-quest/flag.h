const char flag[] = "flag{1ts_t1m3_t0_g3t_fUnkee}";
const char key[] = "JmpM4n";
