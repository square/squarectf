from pwn import *

def xor_key(a,b,c="\x00",d="\00",e="\x00",f="\x00"):
    return chr(ord(a)^ord(b)^ord(c)^ord(d)^ord(e)^ord(f))

conn = process("./crypto_slide_quest")
ciphertext = conn.recv().decode()

key_len = 6 # sizeof - null_byte, from the source code
flag_len = len(ciphertext)

flag = list("flag{" + "?"*(flag_len-6) + "}")
key = list("?" * key_len)

# manually figure out the knowns aka "flag{" and "}" which conveniently gives us the key

key[0] = xor_key(ciphertext[0], flag[0])
key[1] = xor_key(ciphertext[1], flag[1], key[0])
key[2] = xor_key(ciphertext[2], flag[2], key[1], key[0])
key[3] = xor_key(ciphertext[3], flag[3], key[2], key[1], key[0])
key[4] = xor_key(ciphertext[4], flag[4], key[3], key[2], key[1], key[0])
key[-1] = xor_key(ciphertext[-1], flag[-1])

# now that we have the key, we can re the ciphertext

plaintext = list(ciphertext)
for i in range(0, len(ciphertext) - len(key) + 1):
    for j in range(0, len(key)):
        plaintext[i+j] = xor_key(plaintext[i+j], key[j])

print(''.join(plaintext))
